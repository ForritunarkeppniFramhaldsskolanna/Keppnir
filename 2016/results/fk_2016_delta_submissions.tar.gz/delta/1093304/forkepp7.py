fjoldi = input()
lina = input()
svar = 0
if int(lina[0:1]) == 1:
	replina = lina.replace(" ", "")
	svar = len(replina)-1
else:
	replina = lina.replace(" ", "")
	svar = len(replina)
print (svar)