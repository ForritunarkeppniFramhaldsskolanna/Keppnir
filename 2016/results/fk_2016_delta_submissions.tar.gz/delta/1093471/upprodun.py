n = input()
m = input()
a = [[] for x in range(n)]
for x in a:
    x.append("*"*((m-(m%n))/n))
for x in a[0:m%n]:
    x.append("*")
for x in a:
    print "".join(x)
