using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {

            string tala = Console.ReadLine();
            var tölur = tala.Split(' ').Select(Int32.Parse).ToArray();
            if (tölur[0] == 0 || tölur[1] == 0)
            {
                Console.WriteLine(tölur.Max());
            }
            else
            {
                Console.WriteLine((tölur[0] * tölur[1]));

            }
            Console.ReadKey();
        }
    }
}
