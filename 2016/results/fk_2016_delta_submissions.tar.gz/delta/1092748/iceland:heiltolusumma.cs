using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication9
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger sum = 0;
            BigInteger N = 0;
            N = BigInteger.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++)
            {
                sum = sum + i;
            }
            Console.WriteLine(sum);
        }
    }
}
