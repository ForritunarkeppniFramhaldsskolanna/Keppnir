tala = int(input("slaðu inn tölu: "))
heild = 0

for i in range(0,tala+1):
    heild = heild+i


print (heild)
