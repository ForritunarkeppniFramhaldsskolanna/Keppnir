print 400
