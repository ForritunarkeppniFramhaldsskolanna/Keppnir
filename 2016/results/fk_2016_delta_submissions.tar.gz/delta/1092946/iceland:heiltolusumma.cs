using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
            string NN = Console.ReadLine();
            BigInteger N = BigInteger.Parse(NN);
            int summa = 0;
            if (N < 1)
            {
                if (N == -1)
                {
                    summa = 0;
                }
                else
                {
                    for (int i = 1; i >= N; i--)
                    {
                        summa += i;
                    }
                    summa = summa - 1;
                }

            }
            else
            {
                for (int i = 1; i <= N; i++)
                {
                summa += i;
            }
        }
        Console.WriteLine(summa);
            Console.ReadKey();
        }
    }
}
