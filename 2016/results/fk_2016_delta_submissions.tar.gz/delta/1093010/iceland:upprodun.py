stofur = int(input(""))
fjoldi = int(input(""))


for i in range(0,stofur):
    if fjoldi % stofur == 0:
        print "*" * stofur
        fjoldi = fjoldi - stofur
        stofur = stofur - 1
    
