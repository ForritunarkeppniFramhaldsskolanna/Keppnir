arr=[]
for b in range(1,5000):
	arr.append(b)
tala=input()
tala=int(tala)
c=0
if tala<0:
	print("0")
elif tala>4999:
	print("0")
else:
	for i in range(tala):
		c=arr[i]+c
	print(c)