using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_first_Console_Project
{
    class Program
    {

        static void Main(string[] args)
        {
            UInt64 N;
            N = Convert.ToUInt64(Console.ReadLine());
            if (N % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else 
            {
                Console.WriteLine("Neibb");
            }


            Console.ReadLine();

        }
    }
}
