talan = int(input())
summa=0
if(talan>0):
    for i in range(1,talan+1):
        summa+= i
elif(talan<0):
    for y in range(talan,1):
        summa += y
    summa+=1

print(summa)
