using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Double derp = 0;
            derp = Convert.ToDouble(Console.ReadLine());
            
            if (derp % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
           
            else
            {
                Double gunnar = derp / 3;
                if (gunnar %3 == 0)
                {
                    Console.WriteLine("Jebb");
                
                }
                else
                {
                    Console.WriteLine("Neibb");
                }
                
            }          
        }
    }
}
