using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace DaemiI
{
	class Program
	{
		static void Main(string[] args)
		{
			int num = int.Parse(Console.ReadLine());
			long ans = 0;

			if (num == 0 || num == 1)
			{
				ans += 1;
			}
			else if (num > 1)
			{
				for (int i = num; i > 0; i--)
				{
					ans += i;
				}
			}
			else if (num < 1)
			{
				for (int i = num; i <= 1; i++)
				{
					ans += i;
				}
			}

			Console.WriteLine(ans);
			Console.ReadKey();
		}
	}
}