using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
            Int64 fjöldi = 0;
            fjöldi = Convert.ToInt64(Console.ReadLine());
            if (fjöldi %3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");
            }
            Console.ReadKey();





















        }
    }
}
