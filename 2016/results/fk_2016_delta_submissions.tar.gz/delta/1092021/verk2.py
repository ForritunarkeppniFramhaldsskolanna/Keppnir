tala=input()
tala=int(tala)
if (tala<=0):
	print("Neibb")
else:
	if (tala%3==0):
		print("Jebb")
	else:
		print("Neibb")