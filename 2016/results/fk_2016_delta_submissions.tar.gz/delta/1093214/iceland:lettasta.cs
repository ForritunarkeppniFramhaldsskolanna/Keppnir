using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = Convert.ToInt32(Console.ReadLine());
            int U = Convert.ToInt32(Console.ReadLine());
            string A = Console.ReadLine();
            string[] B = A.Split(' ');
            string[] Q;
            long[] J = new long[k];
            int hæs=0;
            for (int i = 0; i < U; i++)
            {
                Q = Console.ReadLine().Split(' ');
                for (int p = 0; p < k; p++)
                {
                    J[p] = J[p] + Convert.ToInt64(Q[p]);
                }
            }
            for (int i = 0; i < k; i++)
            {
                if (J[i]==J.Max())
                {
                    hæs = i;
                }
            }
            Console.WriteLine(B[hæs]);
        }
    }
}
