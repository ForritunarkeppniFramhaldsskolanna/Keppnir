using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiL
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			string lina = Console.ReadLine();
			string tmpLina = null;
			string output = null;
			int start = -1;
			int end = -1;
			int ans = 0;

			for (int i = 0; i < lina.Length; i++)
			{
				if (lina[i] != ' ')
				{
					tmpLina += lina[i];
				}
			}

			if (tmpLina.Contains("0"))
			{
				start = tmpLina.IndexOf('0');
				end = tmpLina.LastIndexOf('0');

				output = tmpLina.Substring(0, start);

				for (int i = start; i <= end; i++)
				{
					if (tmpLina[i] == '0')
					{
						output += '1';
					}
					else if (tmpLina[i] == '1')
					{
						output += '0';
					}
				}

				for (int i = 0; i < tmpLina.Length - end - 1; i++)
				{
					output += "1";
				}

				for (int i = 0; i < output.Length; i++)
				{
					if (output[i] == '1')
					{
						ans++;
					}
				}
			}
			else
			{
				ans = n - 1;
			}

			Console.WriteLine(ans);
			Console.ReadKey();
		}
	}
}