using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            long numerafkeppendum = 0;
            numerafkeppendum = Convert.ToInt64(Console.ReadLine());
            string temp = null;
            int teljariR = 0;
            int teljariA = 0;
            for (int i = 0; i < numerafkeppendum; i++)
            {
                Console.ReadLine();
                temp = Console.ReadLine();
                if (temp == "Reykjavik")
                {
                    teljariR++;
                }
                else if (temp == "Akureyri")
                {
                    teljariA++;
                }
            }
            if (teljariA > 0)
            {
                Console.WriteLine("Akureyri " + teljariA);
            }
            if (teljariR > 0)
            {
                Console.WriteLine("Reykjavik " + teljariR);
            }
            Console.ReadLine();

        }
    }
}