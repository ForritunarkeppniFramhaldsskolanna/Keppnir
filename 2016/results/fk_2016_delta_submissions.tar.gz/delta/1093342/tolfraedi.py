x = int(input(''))
listi=[]
listi2=[]
suma =0
avg = 0
for i in range (0,x):
    y, z= map(str,input().split())

    if z not in listi and x not in listi2:
        listi.append(z)
        listi2.append(y)
        mest = max(listi)
        minst = min(listi)
        suma=0
        for item in listi :
            suma = suma + int(item)
        avg = suma/len(listi)
        print(minst,mest,avg)
    else:
        listi.remove(z)
        listi2.remove(y)
        mest = max(listi)
        minst = min(listi)
        suma=0
        for item in listi :
            suma = suma + int(item)
        avg = suma/len(listi)
        print(minst,mest,avg)