import random
number = random.randrange(0, 101, 2)
print (number)