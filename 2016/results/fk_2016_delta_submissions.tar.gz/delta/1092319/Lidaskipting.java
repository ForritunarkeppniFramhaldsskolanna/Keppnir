import java.util.Scanner;

public class Lidaskipting {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long d1 = sc.nextLong();
        long d2 = sc.nextLong();
        long dsvar = sc.nextLong();
        dsvar = d1*d2;
   
   System.out.println(dsvar);
}
}