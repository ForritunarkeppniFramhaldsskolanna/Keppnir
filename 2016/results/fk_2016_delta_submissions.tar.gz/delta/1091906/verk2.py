nati = int(input(""))

einar = (nati/3)


if einar % 2 == 0:
    print ("jebb")
else:
    print ("neibb")
