n = int(raw_input())

numer = []

for i in range(n):
    numer.append(raw_input())

q = int(raw_input())

out = [0]*q

for i in range(q):
    request = raw_input()
    for fafa in numer:
        if request in fafa:
            out[i] += 1

print '\n'.join(map(str, out))
