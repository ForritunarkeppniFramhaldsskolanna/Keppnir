import java.util.*;
public class Akureyri
{
  public static void main (String[] args)
  { 
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    
    int fjoldi = Integer.parseInt(input);
    String baer;
    String nafn;
    
    String baeir[] = new String[fjoldi];
    int fjbaer[] = new int[fjoldi];
    for(int l=0; l<fjoldi; l++)
      fjbaer[l] = 0;
    int m = 0;
    
    for(int i=0; i<fjoldi; i++)
    {
    nafn = reader.nextLine();
    baer = reader.nextLine();
    
    for(int j=0; j<baeir.length; j++)
    {
    if(baer.equals(baeir[j]))
    {
      fjbaer[j]+=1;
    }
    }
    

      if(baeir[i] != baer)
      {
      baeir[m] = baer;
      fjbaer[m]++;
        m++;
      }
    
     
    }

    
    for(int k=0; k<baeir.length; k++)
    {
    System.out.println(baeir[k] + " " + fjbaer[k]);
    }
    
  }
}