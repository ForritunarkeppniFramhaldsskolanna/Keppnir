a = 0
text = input()
textlist = list(text)
positions = ([pos for pos, char in enumerate(textlist) if char == "<"])

for x in positions:
    del textlist[positions[a]]
    del textlist[positions[a]-1]
    a+=1
final = "".join(map(str, textlist))
print(final)
