N, K = map(int, input().split())
heild = N * K
print (heild)
 
