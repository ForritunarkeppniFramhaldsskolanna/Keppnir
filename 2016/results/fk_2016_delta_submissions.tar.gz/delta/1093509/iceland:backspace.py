listi = []
stafir = str(input("Skrifaðu setninu hérna: "))
stafir.lower()
for ord in stafir:
        for stafur in ord:
            if stafur != '<':
                listi.append(ord)
            else:
                losa = len(listi) - 1
                listi.pop(losa)
for i in listi:
    print(i, end ='')

