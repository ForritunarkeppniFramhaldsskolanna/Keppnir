using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiA
{
	class Program
	{
		static void Main(string[] args)
		{
			for (int i = 2; i <= 100; i++)
			{
				bool isPrime = true;

				for (int j = 2; j < i / 2 + 1; j++)
				{
					if (i % j == 0)
					{
						isPrime = false;
						break;
					}
				}

				if (isPrime)
				{
					Console.WriteLine(i);
				}
			}

			Console.ReadKey();
		}
	}
}