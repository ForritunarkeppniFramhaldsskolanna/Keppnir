using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjöldiKeppenda = 0;
            fjöldiKeppenda = Convert.ToInt32(Console.ReadLine());
            List<string> derp = new List<string>();

            for (int i = 0; i < fjöldiKeppenda; i++)
            {
                Console.ReadLine();
                derp.Add(Console.ReadLine());
            }

            var g = derp.GroupBy(i => i);

            foreach (var grp in g)
            {
                Console.WriteLine("{0} {1}", grp.Key, grp.Count());
            }
            Console.ReadKey();

        }
    }
}
