A1 = int(input('Stofu: '))
A2 = map(int,input('Keppendur: '))


print(A2)
