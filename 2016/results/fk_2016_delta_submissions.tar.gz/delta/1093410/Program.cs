using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    class Program
    {
        static void Main(string[] args)
        {
            string input1 = Console.ReadLine();
            string input2 = Console.ReadLine();
            string input3 = Console.ReadLine();
            string input4 = Console.ReadLine();
            string input5 = Console.ReadLine();
            string input6 = Console.ReadLine();
            string input7 = Console.ReadLine();

            Console.WriteLine("Frumtölur");
            Console.ReadKey();
        }
    }
}
