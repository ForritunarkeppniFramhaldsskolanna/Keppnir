using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            string k = Console.ReadLine();
            List<char> C = new List<char>();
            for (int i = 0; i < k.Length; i++)
            {
                C.Add(k[i]);
                if (C[C.Count-1]=='<')
                {
                    C.Remove(C[C.Count-1]);
                    if (C.Count>1)
                    {
                        C.Remove(C[C.Count - 1]);
                    }
                }
            }
            for (int i = 0; i < C.Count-1; i++)
            {
                Console.Write(C[i]);
            }
            Console.WriteLine(C[C.Count-1]);
        }
    }
}
