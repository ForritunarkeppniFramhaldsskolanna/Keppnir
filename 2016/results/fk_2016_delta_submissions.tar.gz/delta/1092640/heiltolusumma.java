import java.util.Scanner;
import java.math.BigInteger;


public class heiltolusumma
{
  public static void main(String [] args)
  {
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    //BigInteger tala = new BigInteger(input);
    long tala = Long.parseLong(input);
    
    
    int summa = 0;
    if(tala>0)
    {
    for(int i = 1; i<=tala; i++)
    {summa = summa+i;}
    System.out.println(summa);
    }
    if(tala<0)
    {
      for(int i = 1; i>=tala; i--)
      {summa = summa + i;}
      System.out.println(summa);
    }
    
  }
}