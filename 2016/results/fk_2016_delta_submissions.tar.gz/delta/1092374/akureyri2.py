import collections
names = [];
places = [];
pairs = int(input()) * 2

while(pairs>0):
    name = input()
    place = input()
    names.append(name)
    places.append(place)
    pairs = pairs-2
i = 0
for a in places:
    print(places[i], end=" ")
    print(places.count(places[i]))
    places[:] = [x for x in places if x != places[i]]
    i+=1
