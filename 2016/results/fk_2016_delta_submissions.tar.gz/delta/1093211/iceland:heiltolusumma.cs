using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace heildarsumma
{
    class Program
    {
        static void Main(string[] args)
        {
            long tala = 0;
            List<long> listi = new List<long>();
            tala = Convert.ToInt64(Console.ReadLine());
            if (tala > 0)
            {
                for (int i = 0; i < tala; i++)
                {
                    listi.Add(i + 1);
                }
            }
            else
            {
                for (int i = 0; i > tala; i++)
                {
                    listi.Add(i + 1);
                }
            }

            Console.WriteLine(listi.Sum());
            Console.ReadKey();
        }
    }
}
