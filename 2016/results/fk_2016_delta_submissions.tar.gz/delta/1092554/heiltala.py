x =int(input(''))
z=0
y = x+1
for i in range(1,y):
    z = z + i
print(z)