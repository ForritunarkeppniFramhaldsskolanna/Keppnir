x = input()
x = x.split(" ")
print(int(x[0]) * int(x[1]))
