using System;

namespace Heiltolsmma
{
	class MainClass
	{
		public static void Main (string[] args)
		{ 
			Console.Clear();
			Int64 N, Summa = 0;
			N = Convert.ToInt64(Console.ReadLine());
			if (N < 1)
			{
				for (Int64 i = N; i <= 1; i++)
				{
					Summa = Summa + i;
				}
			}
			else if (N > 1)
			{
				for (Int64 i = N; i >= 1; i--)
				{
					Summa = Summa + i;
				}
			}
			else
			{
				Summa = 1;
			}
			Console.WriteLine (Summa);
			Console.ReadKey ();
		}
	}
}
