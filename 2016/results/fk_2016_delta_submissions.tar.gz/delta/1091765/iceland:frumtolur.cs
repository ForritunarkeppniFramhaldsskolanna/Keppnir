using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(2);
            Console.WriteLine(3);
            Console.WriteLine(5);
            Console.WriteLine(7);
            Console.WriteLine(11);
            Console.WriteLine(13);
            Console.WriteLine(17);
            Console.WriteLine(19);
            Console.WriteLine(23);
            Console.WriteLine(29);
            Console.WriteLine(31);
            Console.WriteLine(37);
            Console.WriteLine(41);
            Console.WriteLine(43);
            Console.WriteLine(47);
            Console.WriteLine(53);
            Console.WriteLine(59);
            Console.WriteLine(61);
            Console.WriteLine(67);
            Console.WriteLine(71);
            Console.WriteLine(73);
            Console.WriteLine(79);
            Console.WriteLine(83);
            Console.WriteLine(89);
            Console.WriteLine(97);
            Console.WriteLine(101);
            Console.WriteLine(103);
            Console.WriteLine(107);
            Console.WriteLine(109);
            Console.WriteLine(113);
            Console.WriteLine(127);
            Console.WriteLine(131);
            Console.WriteLine(137);
            Console.WriteLine(139);
            Console.WriteLine(149);
            Console.WriteLine(151);
            Console.WriteLine(157);
            Console.WriteLine(163);
            Console.WriteLine(167);
            Console.WriteLine(173);
            Console.WriteLine(179);
            Console.WriteLine(181);
            Console.WriteLine(191);
            Console.WriteLine(193);
            Console.WriteLine(197);
            Console.WriteLine(199);
            Console.WriteLine(211);
            Console.WriteLine(223);
            Console.WriteLine(227);
            Console.WriteLine(229);
            Console.WriteLine(233);
            Console.WriteLine(239);
            Console.WriteLine(241);
            Console.WriteLine(251);
            Console.WriteLine(257);
            Console.WriteLine(263);
            Console.WriteLine(269);
            Console.WriteLine(271);
            Console.WriteLine(277);
            Console.WriteLine(281);
            Console.WriteLine(283);
            Console.WriteLine(293);
            Console.WriteLine(307);
            Console.WriteLine(311);
            Console.WriteLine(313);
            Console.WriteLine(317);
            Console.WriteLine(331);
            Console.WriteLine(337);
            Console.WriteLine(347);
            Console.WriteLine(349);
            Console.WriteLine(353);
            Console.WriteLine(359);
            Console.WriteLine(367);
            Console.WriteLine(373);
            Console.WriteLine(379);
            Console.WriteLine(383);
            Console.WriteLine(389);
            Console.WriteLine(397);
            Console.WriteLine(401);
            Console.WriteLine(409);
            Console.WriteLine(419);
            Console.WriteLine(421);
            Console.WriteLine(431);
            Console.WriteLine(433);
            Console.WriteLine(439);
            Console.WriteLine(443);
            Console.WriteLine(449);
            Console.WriteLine(457);
            Console.WriteLine(461);
            Console.WriteLine(463);
            Console.WriteLine(467);
            Console.WriteLine(479);
            Console.WriteLine(487);
            Console.WriteLine(491);
            Console.WriteLine(499);
            Console.WriteLine(503);
            Console.WriteLine(509);
            Console.WriteLine(521);
            Console.WriteLine(523);
            Console.WriteLine(541);

        }
    }
}