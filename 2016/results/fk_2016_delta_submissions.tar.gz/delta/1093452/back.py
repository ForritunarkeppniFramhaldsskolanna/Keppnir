line = raw_input()

out = []

linelen = len(line)

for i in list(line):
    if i != "<":
        out.append(i)
    else:
        del out[-1]

print ''.join(out)
