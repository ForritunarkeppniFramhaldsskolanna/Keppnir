A = []

for a0 in range(int(input())):
	v = input().split()
	a,b = v[0],int(v[1])
	if a == 'A':
		A.append(b)
	elif a == 'R':
		if b in A:
			A.remove(b)
	if not A:
		print(-1, -1, -1)
	else:
		print(min(A), max(A), (sum(A) / len(A)))