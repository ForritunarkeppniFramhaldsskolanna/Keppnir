using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace símanúmer
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiSimanumer = 0;
            int[] simanumer;
            int fjoldiFyrirspurna = 0;
            int[] fyrirspurnir;
            int[] teljarar;

            fjoldiSimanumer = Convert.ToInt32(Console.ReadLine());
            simanumer = new int[fjoldiSimanumer];
            for (int i = 0; i < simanumer.Length; i++)
            {
                simanumer[i] = Convert.ToInt32(Console.ReadLine());
            }
            fjoldiFyrirspurna = Convert.ToInt32(Console.ReadLine());
            fyrirspurnir = new int[fjoldiFyrirspurna];
            teljarar = new int[fjoldiFyrirspurna];
            for (int i = 0; i < fyrirspurnir.Length; i++)
            {
                fyrirspurnir[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < fjoldiFyrirspurna; i++)
            {
                for (int x = 0; i < fjoldiFyrirspurna; i++)
                {
                    if (simanumer[x].ToString().Contains(fyrirspurnir[i].ToString()))
                    {
                        teljarar[i]++;
                    }
                }
            }
            for (int i = 0; i < teljarar.Length; i++)
            {
                Console.WriteLine(teljarar[i]);
            }
            Console.ReadKey();
        }
    }
}
