inp = list(raw_input())
while 1==1:
    if "<" in inp:
        del inp[inp.index("<")-1:inp.index("<")+1]
    else:
        break
print "".join(inp)
