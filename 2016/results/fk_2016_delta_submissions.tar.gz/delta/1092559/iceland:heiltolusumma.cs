using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Forkepni
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger N = BigInteger.Parse(Console.ReadLine());
            BigInteger sum = 0;

            for (int i = 0; i <= N; i++)
            {
                
                sum = i + sum;
            }

            Console.Write(sum);
            Console.ReadLine();
           

        }
    }
}