global numbers
global lowest
global highest
global average
global number_of

numbers = []
lowest = 123123123213123
highest = 0
average = 0
number_of = input("")
def math():
    global numbers
    global lowest
    global highest
    global average
    global number_of
    #math
    #lowest
    for x in numbers:
        if x <= lowest:
            lowest = x
    #highest
    for x in numbers:
        if x > highest:
            highest = x
    #average
        Average = 0
    for x in numbers:
        Average += x
        average = Average/ len(numbers)
    print(str(lowest) + " " + str(highest) + " " + str(average))


for x in range(0, int(number_of)):
    times = input("")
    action = times[0]
    age = ""
    for xxx in range(2, len(times)):
        age += times[xxx]
    numbers.append(int(age))
    math()
