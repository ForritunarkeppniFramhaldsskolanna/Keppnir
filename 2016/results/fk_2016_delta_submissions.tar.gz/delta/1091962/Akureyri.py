x = int(input(""))
check = ""
stadir = []
stadir2 = []
for i in range (0,x):
    y = str(input(""))
    u = str(input(""))
    stadir.append(u)

count = 0
stadir2.append(stadir[0])
for item in stadir:
    if item not in stadir2:
        stadir2.append(item)
    else:
        x = 0
for i in range (0,len(stadir2)):
    print(stadir2[i],stadir.count(stadir2[i]))



