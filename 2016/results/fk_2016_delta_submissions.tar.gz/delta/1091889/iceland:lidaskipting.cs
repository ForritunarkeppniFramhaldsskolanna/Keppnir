using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace DaemiB
{
	class Program
	{
		static void Main(string[] args)
		{
			BigInteger input = BigInteger.Parse(Console.ReadLine());

			if (input % 3 == 0)
			{
				Console.WriteLine("Jebb");
			}
			else
			{
				Console.WriteLine("Neibb");
			}

			Console.ReadKey();
		}
	}
}