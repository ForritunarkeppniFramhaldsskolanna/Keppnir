bill = str(input(""))

a = "<"
b = [""]
c = []
b.append(bill)
count = 0
tala = 0
for x in b:
    for i in x:
        count = count + 1
        c.append(i)
        if i == a:
            tala = count


tala1 = (tala - 1)
tala2 = (tala - 2)

c[tala1] = ""
c[tala2] = ""

d = []
for i in c:
    for dildo in i:
        print (dildo, end="")
        
