keppendur = int(input())
nafnlisti = []
stadir = {}

for i in range(0,keppendur):
    nafn = input()
    stadur = input()

    if not(stadur in stadir):
        stadir[stadur]=1
    else:
        stadir[stadur]+=1

for y,x in stadir.items():
    print(y,x)
