using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForritunarkeppniMenntakólanna
{
    class Lidur1
    {
        static void Main(string[] args)
        {
            string innslattur = Console.ReadLine();
            string[] texti = new string [innslattur.Count()];
            for (int i = 0; i < innslattur.Length; i++)
            {
                texti[i] = Convert.ToString(innslattur[i]);
            }
            List<string> utkomma = new List<string>();
            for (int i = 0; i < innslattur.Length; i++)
            {
                if (innslattur[i] == '<')
                {
                    texti[i - 1] = "";
                    texti[i] = "";
                }
                else
                {
                    utkomma.Add(texti[i]);
                }
            }
            for (int i = 0; i < utkomma.Count; i++)
            {
                Console.Write(utkomma[i]);
            }
            Console.ReadLine();
        }
    }
}