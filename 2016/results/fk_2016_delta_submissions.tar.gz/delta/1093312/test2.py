heild = 0
einar = int(input(""))
for i in range(1,einar+1):
    heild = heild + i
summa = print("",heild,)