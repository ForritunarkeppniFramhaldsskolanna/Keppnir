using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Liðaskipting
{
    class Program
    {
        static void Main(string[] args)
        {
            int keppa = 0;
            Console.WriteLine("hversu margir  ætla ad keppa?");
            keppa = Convert.ToInt32(Console.ReadLine());
            keppa = keppa % 3;
            if (keppa <= 3)
            {
                Console.WriteLine("jebb");
            }
            else
            {
                Console.WriteLine("neibb");
            }

            Console.ReadKey();
        }
    }
}
