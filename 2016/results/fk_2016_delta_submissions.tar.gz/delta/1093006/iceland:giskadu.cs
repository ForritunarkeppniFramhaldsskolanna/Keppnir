using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dæmi2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int tala = 0;


            tala = rand.Next(1, 400);

            Console.WriteLine(tala);
        }

    }
}