using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiK
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			string[] simanumer = new string[n];

			for (int i = 0; i < n; i++)
			{
				simanumer[i] = Console.ReadLine();
			}

			int q = int.Parse(Console.ReadLine());
			string[] fyrirspurnir = new string[q];

			for (int i = 0; i < q; i++)
			{
				fyrirspurnir[i] = Console.ReadLine();
			}

			for (int i = 0; i < q; i++)
			{
				int tmp = 0;

				for (int j = 0; j < n; j++)
				{
					if (simanumer[j].Substring(0, fyrirspurnir[i].Length) == fyrirspurnir[i])
					{
						tmp++;
					}
				}

				Console.WriteLine(tmp);
			}

			Console.ReadKey();
		}
	}
}