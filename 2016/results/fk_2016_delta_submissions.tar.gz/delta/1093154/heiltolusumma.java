import java.util.Scanner;
import java.math.BigInteger;


public class heiltolusumma
{
  public static void main(String [] args)
  {
    long summa = 0;
    
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    long tala = Long.parseLong(input);
    /*
    BigInteger summa = new BigInteger("0");
    BigInteger tala = new BigInteger(input);
    BigInteger tala2 = new BigInteger("1");
    BigInteger nullid = new BigInteger("0");
    BigInteger einn = new BigInteger("1");
      
     int athugun = tala.compareTo(nullid);
    if(athugun == 1)
    {
      int skilyrdi = tala.compareTo(tala2);
      while(skilyrdi == 1)
    { 
      summa = summa.add(tala2);
      tala2 = tala2.add(einn);
                                    
      }   
      System.out.println(summa);
     } */
   
    
                  
    
    
 
    if(tala>0)
    {
    for(long i = 1; i<=tala; i++)
    {summa = summa+i;}
    System.out.println(summa);
    }
    if(tala<0)
    {
      for(long i = 1; i>=tala; i--)
      {summa = summa + i;}
      System.out.println(summa);
    } 
    
  }
}