a = input()
print a*(a+1)/2
