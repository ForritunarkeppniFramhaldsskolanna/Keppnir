x =int(input(''))
y = x+1
if x > 0:
    z = (x*y)/2
    print(int(z))
else:
    print(0)