tolur = input()
tala1 = int(tolur[0])
tala2 = int(tolur[2])
print (tala1 * tala2)