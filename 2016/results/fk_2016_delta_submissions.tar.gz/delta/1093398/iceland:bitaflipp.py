input()

nums = [int(x) for x in input().split()]

if all(x for x in nums if x == 1):
	print(sum(nums)-1)