herb  = int(input())
coord=[herb.split(' ')]

if(coord[0] == 1 or coord[1]):
    print((coord[0]+coord[1])*2)

elif(coord[0]%2==0 or coord[1]%2==0):
    print(herbB*herbL)

else:
    print(coord[0]*coord[1]+coord[1]-1)
