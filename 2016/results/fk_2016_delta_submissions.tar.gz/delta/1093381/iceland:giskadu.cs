using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GayAssShit
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 500;
            Random rand = new Random();
            x = rand.Next(0, 1000);
            if (x % 2 == 0)
            {
                Console.WriteLine(x);
            }
            Console.ReadKey();
        }
    }
}
