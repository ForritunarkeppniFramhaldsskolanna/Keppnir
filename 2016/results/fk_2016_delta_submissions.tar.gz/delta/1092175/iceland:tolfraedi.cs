using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            int Q = 0;
            List<double> listi = new List<double>();
            Q = Convert.ToInt32(Console.ReadLine());


            for (int i = 0; i < Q; i++)
            {
                string[] lina = null;
                lina = Console.ReadLine().Split(' ');

                if (lina[0] == "A")
                {
                    int aldur = Convert.ToInt32(lina[1]);

                    listi.Add(aldur);
                }
                else if (lina[0] == "R")
                {
                    int aldur = Convert.ToInt32(lina[1]);

                    listi.Remove(aldur);
                }
                Console.WriteLine(listi.Min()+ " "+listi.Max() +" " +listi.Average());

            }
            Console.ReadLine();
        }
    }
}
