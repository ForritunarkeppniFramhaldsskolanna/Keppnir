using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            ulong keppendur = 0;

            keppendur = Convert.ToUInt64(Console.ReadLine());
            if (keppendur % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");
            }

        }
    }
}