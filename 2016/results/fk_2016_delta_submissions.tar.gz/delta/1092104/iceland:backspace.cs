using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForritunarkeppniMenntakólanna
{
    class Lidur1
    {
        static void Main(string[] args)
        {
            string innslattur = Console.ReadLine();
            string[] texti = new string [innslattur.Count()];
            string[] utkomma = new string[100];
            for (int i = 0; i < innslattur.Length; i++)
            {
                if (innslattur[i] == '<')
                {
                    innslattur = innslattur.Remove(i);
                }
                else
                {
                    for (int y = 0; y < utkomma.Length; y++)
                    {
                        utkomma[y] = texti[i];
                    }
                }
            }
            Console.WriteLine(texti);
            Console.ReadLine();
        }
    }
}