tala = int(input())
stadsettningArray = []
while tala > 0 :
	keppandi = input()

	stadsetning = input()
	stadsettningArray.append(stadsetning)

	tala -= 1
final = {i:stadsettningArray.count(i) for i in stadsettningArray}
final2 = str(final)
final2 = final2.replace("{'", "")
final2 = final2.replace("':", "")
final2 = final2.replace(",", "\n")
final2 = final2.replace("}", "")
final2 = final2.replace(" '", "")
print (final2)
	