using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backspace_Symbol
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = null;
            input = Console.ReadLine();
            input = input.Remove(input.IndexOf("<") + 1);

            List<char> stafalisti = new List<Char>();

            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] != '<')
                {
                    stafalisti.Add(input[i]);
                }
                else
                {
                    stafalisti.RemoveAt(i - 1);
                }

            }

            foreach (var item in stafalisti)
            {
                Console.Write(item);
            }
            Console.ReadKey();

        }//end main
    }//end class
}