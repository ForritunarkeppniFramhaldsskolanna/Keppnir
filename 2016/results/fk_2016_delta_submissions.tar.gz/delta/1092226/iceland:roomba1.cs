using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiE
{
	class Program
	{
		static void Main(string[] args)
		{
			string[] inn = Console.ReadLine().Split(' ');
			int r = int.Parse(inn[0]);
			int d = int.Parse(inn[1]);
			int ans = 0;

			ans = r * d;

			if (ans % 2 != 0)
			{
				ans++;
			}
			
			Console.WriteLine(ans);
			Console.ReadKey();
		}
	}
}