using System;

namespace Forritunarkeppni
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			string S;
			int N;
			int P;
			int intFjoldi = 0;

			S = Console.ReadLine ();
			N = S.Length;

			for (int i = 0; i < S.Length; i++) {
				if (S.Substring (i, 1) == "<") {
					intFjoldi++;
				}
			}

			for (int i = 0; i < intFjoldi; i++) {
				P = S.IndexOf ("<");

				if (P < 0) {
					P = 0;
					S = "";
				} else {
					S = S.Replace ((S.Substring ((P - 1), 2)), "  ");
					S = S.Replace ("  ", "");
				}
			}

			Console.WriteLine (S);
			Console.ReadLine ();
		}
	}
}
