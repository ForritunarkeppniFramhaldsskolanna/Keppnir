a = int(input("hversu margir ætla að keppa?: "))

if (3%a == 0):
    print("jebb")
else:
    print("neibb")
