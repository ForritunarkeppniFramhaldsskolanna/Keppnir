tala=input()
tala=int(tala)
if (tala<0):
	print("0")
else:
	for i in range(tala):
		i+=i
	print(i)