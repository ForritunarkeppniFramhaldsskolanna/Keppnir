tala=input("hve margir?")
tala=int(tala)
if (tala%3==0):
	print("jebb")
else:
	print("neibb")