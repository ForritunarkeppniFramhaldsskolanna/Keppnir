using System;

namespace Heiltolsmma
{
	class MainClass
	{
		public static void Main (string[] args)
		{ 
			Console.WriteLine ("100");
		}
	}
}
