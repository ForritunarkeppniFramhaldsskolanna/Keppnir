import java.util.Scanner;
public class upprodun
{
  public static void main(String[] args)
  {
   Scanner hlutur = new Scanner(System.in);
   String fjoldi = hlutur.nextLine();
   int stofur = Integer.parseInt(fjoldi);
   String fjoldi2 = hlutur.nextLine();
   int nemendur = Integer.parseInt(fjoldi2);
   int nidurstada = (nemendur/stofur);
   
   if((nemendur % stofur) == 0)
   {
   for(int j = 0; j<stofur;j++)
     {
   for(int i = 0; i<nidurstada; i++)
   {
     System.out.print("*");
   }
   System.out.println("");
   }
   
   }
   else if(stofur == 1)
   {
    for(int k = 0; k<nemendur; k++)
   {
     System.out.print("*");
   }
   }
   else
   {
   int deiling = nemendur/stofur;
   int auka = nemendur-(deiling*stofur);
   for(int h=0; h<stofur ; h++)
   {
   if(h<auka)
   {
     for(int m = 0; m<deiling+1; m++)
     {
        System.out.print("*");
     }
     System.out.println("");
    
   }
   else 
   {
    for(int t = 0; t<deiling; t++)
     {
        System.out.print("*");
     }
    System.out.println("");
    
   }
   }
   }
   }
   
   
   
   
  }
