using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dæmi2
{
    class Program
    {
        static void Main(string[] args)
        {
            UInt64 innslatur = 0;

            innslatur = Convert.ToUInt64(Console.ReadLine());

            if (innslatur % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }

            else
            {
                Console.WriteLine("Neibb");
            }
            Console.ReadKey();
        }
    }
}
