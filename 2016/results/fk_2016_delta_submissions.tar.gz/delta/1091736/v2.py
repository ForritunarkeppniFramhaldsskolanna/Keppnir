keppendur = int(input('sladu inn fjolda keppenda: '))
if(keppendur%3 == 0):
    print('jebb')
else:
    print('neibb')
