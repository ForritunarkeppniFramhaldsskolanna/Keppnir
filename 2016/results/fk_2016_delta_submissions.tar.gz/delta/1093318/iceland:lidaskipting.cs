using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Liðaskipting
{
    class Liðaskipting
    {
        static void Main(string[] args)
        {

                BigInteger N = 0;

                BigInteger number = BigInteger.Parse(N.ToString());
                number = Convert.ToInt64(Console.ReadLine());
                if (number % 3 == 0)
                {
                    Console.WriteLine("Jebb");
                }
                else
                {
                    Console.WriteLine("Neibb");



                }
        }
    }
}