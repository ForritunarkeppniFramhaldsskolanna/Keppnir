using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace keppni
{
    class Program
    {
        static void Main(string[] args)
        {
            List<ulong> A = new List<ulong>();
            string output = null;

            ulong a0 = Convert.ToUInt64(Console.ReadLine());
            for (ulong a1 = 0; a1 < a0; a1++)
            {
                string[] v = Console.ReadLine().Split();
                string a = v[0];
                ulong b = UInt64.Parse(v[1]);

                if (a == "A")
                {
                    A.Add(b);
                }
                else if (a == "R")
                {
                    A.Remove(b);
                }
                if (A.Count() == 0)
                {
                    output += "-1 -1 -1\n";
                }
                else
                {
                    ulong sum = 0;
                    foreach(ulong n in A)
                    {
                        sum += n;
                    }
                    sum /= ulong.Parse(A.Count().ToString());
                    output += A.Min() + " " + A.Max() + " " + (Math.Round((double) sum, 6).ToString(".000000")) + "\n";
                }
            }
            Console.WriteLine(output);
            Console.ReadKey();
        }
    }
}
