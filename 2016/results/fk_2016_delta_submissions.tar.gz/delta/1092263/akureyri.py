x = input("")
dic = {}
places = [""]
for i in range(0,int(x)):
    name = input("")
    place = input("")
    for y in places:
        if y.lower() == place.lower():
            exists = True
        else:
            exists = False
    if exists:
        dic[place.lower()] += 1
    else:
        places.append(place.lower())
        dic[place.lower()] = 1
for x in dic:
    print (x.title() + " " + str(dic[x]))
