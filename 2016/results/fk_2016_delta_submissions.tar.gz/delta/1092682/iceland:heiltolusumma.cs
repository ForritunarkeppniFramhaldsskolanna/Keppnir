using System;

namespace Heiltolsmma
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			double N, Summa = 0;
			N = Convert.ToDouble(Console.ReadLine());
			if (N < 1)
			{
				for (double i = N; i <= 1; i++)
				{
					Summa = Summa + i;
				}
			}
			else if (N > 1)
			{
				for (double i = N; i >= 1; i--)
				{
					Summa = Summa + i;
				}
			}
			else
			{
				Console.WriteLine ("1");
			}
			Console.WriteLine (Summa);
			Console.ReadKey ();
		}
	}
}
