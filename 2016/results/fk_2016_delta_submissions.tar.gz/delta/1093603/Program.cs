using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;


namespace Heiltalaaaa
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger heiltala = BigInteger.Parse(Console.ReadLine());
            BigInteger count = 0;

            if (heiltala > 0)
            {
                for (BigInteger i = 1; i <= heiltala; i++)
                {
                    count += i;
                }
                Console.WriteLine(count);
            }
            else
            {
                for (BigInteger i = 1; i <= heiltala; i++)
                {
                    count += i;
                }
                Console.WriteLine(count);

            }
            Console.ReadKey();
        }
    }
}
