public class Program{
  public static void main(String arg[]){

    Scanner sc = new Scanner(System.in);
    dsvar = sc.nextLong();

  if ((dsvar % 3) == 0)
   {
   System.out.println("Jebb");
   }
   else
   {
    System.out.println("Neibb");
   }
  }
}