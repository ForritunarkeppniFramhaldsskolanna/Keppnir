using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiJ
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			int m = int.Parse(Console.ReadLine());
			string daemi = Console.ReadLine();
			List<string> stigList = new List<string>();
			List<int> stig = new List<int>();

			for (int i = 0; i < m; i++)
			{
				stigList.Add(Console.ReadLine());
			}

			for (int i = 0; i < n; i++)
			{
				int tmp = 0;

				for (int j = 0; j < m; j++)
				{
					tmp += int.Parse(stigList[j].Split(' ')[i]);
				}

				stig.Add(tmp);
			}

			int maxIndex = stig.IndexOf(stig.Max());
			Console.WriteLine(daemi.Split(' ')[maxIndex]);
			Console.ReadKey();
		}
	}
}