s = list(input())

while '<' in s:
	for i in range(0,len(s)-1):
		if s[i+1] == '<':
			del s[i]
			del s[i]
			break
print(''.join(s))