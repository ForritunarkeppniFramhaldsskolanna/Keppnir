using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiC
{
	class Program
	{
		static void Main(string[] args)
		{
			int inn = int.Parse(Console.ReadLine());
			List<string> nofn = new List<string>();
			List<string> baeir = new List<string>();
			List<string> baeirUt = new List<string>();
			int i = 0;

			while (i < inn)
			{
				nofn.Add(Console.ReadLine());
				baeir.Add(Console.ReadLine());
				i++;
			}

			for (int j = 0; j < baeir.Count; j++)
			{
				if (!baeirUt.Contains(baeir[j]))
				{
					baeirUt.Add(baeir[j]);
				}
			}

			int[] numIBae = new int[baeirUt.Count];

			for (int j = 0; j < nofn.Count; j++)
			{
				numIBae[baeirUt.IndexOf(baeir[j])]++;
			}

			for (int j = 0; j < baeirUt.Count; j++)
			{
				Console.WriteLine(baeirUt[j] + " " + numIBae[j]);
			}

			Console.ReadKey();
		}
	}
}