for frumtala in range(2,547):
    for i in range(2,frumtala):
        if (frumtala % i==0):
            break
    else:
        print(frumtala)