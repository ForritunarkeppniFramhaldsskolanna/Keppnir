print 700
