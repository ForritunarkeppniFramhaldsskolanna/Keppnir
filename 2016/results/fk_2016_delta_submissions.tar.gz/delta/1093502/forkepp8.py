stofur = input()
nemendur = input()
stofur1 = int(stofur)
nemendur1 = int(nemendur)
teljari = 0
reikn = nemendur1/stofur1
for i in range(stofur1):
	for o in range(round(reikn)):
		teljari += 1
		if teljari <= nemendur1:
			print ("*", end="")
	print ("")
