using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
           
            double derp = 0;
            derp = Convert.ToDouble(Console.ReadLine());
            
            if (derp % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
           
            else
            {                                                      
                try
                {
                    Convert.ToUInt64(derp);
                    Console.WriteLine("Jebb");
                }     
                catch (OverflowException)
                {
                    Console.WriteLine("Neibb");
                }
            }          
Console.ReadKey();
        }
    }
}
