using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            long simi = Convert.ToInt64(Console.ReadLine());
            string[] simar = new string[simi];
            for (int i = 0; i < simi; i++)
            {
                simar[i] = Console.ReadLine();
            }
            long spur = Convert.ToInt64(Console.ReadLine());
            string[] spurn = new string[spur];
            for (int i = 0; i < spur; i++)
            {
                spurn[i] = Console.ReadLine();
            }
            int tel = 0;
            int tul = 0;
            for (int i = 0; i < spur; i++)
            {
                tul = 0;
                for (int k = 0; k < simi; k++)
                {
                    tel = 0;
                    for (int u = 0; u < spurn[i].Length; u++)
                    {
                        if (spurn[i][u]==simar[k][u])
                        {
                            tel++;
                        }
                    }
                    if (tel==spurn[i].Length)
                    {
                        tul++;
                    }
                }
                Console.WriteLine(tul);
            }
        }
    }
}
