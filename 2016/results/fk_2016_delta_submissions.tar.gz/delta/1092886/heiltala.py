x =int(input(''))
z=0
y = x+1
if z > 0
    z = (x*y)/2
    print(int(z))
else:
    print(0)