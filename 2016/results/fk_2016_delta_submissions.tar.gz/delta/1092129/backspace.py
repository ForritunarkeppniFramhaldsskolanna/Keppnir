x = str(input(""))
count = 0
listi = []
for i in x:
    listi.append(i)

for item in listi:
    if item == '<':
        listi.remove(listi[count])
        count2 = count -1
        listi.remove(listi[count2])
    count +=1
for item in listi:
    print(item)




