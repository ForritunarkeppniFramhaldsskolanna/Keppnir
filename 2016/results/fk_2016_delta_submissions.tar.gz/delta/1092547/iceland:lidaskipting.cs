using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var N = new BigInteger(0);
            var K = new BigInteger(06);

            N = Convert.ToInt32(Console.ReadLine());

            K = N % 3;
            if (K == 0)
            {
                Console.WriteLine("Jebb");
            }
            else if (K != 0)
            {
                Console.WriteLine("Neibb");
            }

            Console.ReadKey();
        }
    }
}
