print 1
print 1000
