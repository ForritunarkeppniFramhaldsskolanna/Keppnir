using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keppni
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = 0;
            int i = 2;

            while (teljari < 100)
            {
                bool isvalid = true;
                for(int j = 2; j < Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        isvalid = false;
                        break;
                    }
                }
                if (isvalid)
                {
                    Console.WriteLine(i);
                    teljari++;
                }
                i++;
            }
            Console.ReadKey();
        }
    }
}
