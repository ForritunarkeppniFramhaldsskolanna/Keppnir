using System;

namespace Forritunarkepni
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			double r, d, lausn;
			int lengd, strlengd;
			string str;

			str = Console.ReadLine ();
			strlengd = str.Length;
			if (str.Substring (1, 1) == " ")
			{
				r = Convert.ToDouble(str.Substring(0, 1));
				lengd = 2;
			}
			else
			{
				if (str.Substring (2, 1) == " ") {
					r = Convert.ToDouble (str.Substring (0, 2));
					lengd = 3;
				}
				else
				{
					r = Convert.ToDouble (str.Substring (0, 3));
					lengd = 4;
				}
			}
			if (strlengd-lengd == 1) 
			{
				d = Convert.ToDouble(str.Substring (lengd, 1));
			}
			else
			{
				if (strlengd-lengd == 2) {
					d = Convert.ToDouble (str.Substring (lengd, 2));
				} 
				else
				{
					d = Convert.ToDouble (str.Substring (lengd, 3));
				}
			}
			if (r / 2 != Math.Round (r / 2, 0) && d / 2 != Math.Round (d / 2, 0)) {
				lausn = d * r;
				if (d < r) {
					lausn = lausn + d;
				} else {
					lausn = lausn + r;
				}
			}
			else
			{
				lausn = d * r;
			}
			Console.WriteLine (lausn);
			Console.ReadKey ();
		}
	}
}
