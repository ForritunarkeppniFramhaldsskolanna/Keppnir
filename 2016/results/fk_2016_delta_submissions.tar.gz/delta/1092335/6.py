# import decimal

# decimal.getcontext().prec = 5
# d = lambda x: decimal.Decimal(x)

q = int(raw_input())

people = 0
ageList = []
totalAge = 0

# def makelong(x):
#     x = list(str(x))
#     index = 0
#     try:
#         index = x.index(".")
#     except ValueError:
#         x.append(".")
#         index = x.index(".")

#     if len(x[index:]) < 6:
#         out = ''.join(x + ["0"]*(5-len(x[:index+1])))
#         return out

# def add(x):
#     out = 0
#     for i in x:
#         out += i
#     return out

for i in range(q):
    state, age = raw_input().split(" ")
    age = int(age)
    if state == "A":
        people += 1
        ageList.append(age)
        totalAge += age
    else:
        people -= 1
        ageList.remove(age)
        totalAge -= age
    if ageList == []:
        print "-1 -1 -1"
    else:
        print '%i %i %.6f' % (min(ageList), max(ageList), (float(totalAge) / float(people)))
