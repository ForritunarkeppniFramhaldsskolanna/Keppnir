using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {

            int tala = 0;
            tala = Convert.ToInt32(Console.ReadLine());
            string[] stafur = new string[tala];
            int[] tölur = new int[tala];
            int[] min = new int[tala];
            int[] max = new int[tala];
            double[] avg = new double[tala];
            double meðatal = 0;
            int hirðmenn = 0;
            
            
            for (int i = 0; i < tala; i++)
            {
                
                string gagga = Console.ReadLine();
                var stengur = gagga.Split(' ');
                stafur[i] = stengur[0];
                tölur[i]=Int32.Parse(stengur[1]);
                if (stafur[i] == "A")
                {
                    meðatal += tölur[i];
                    if (min.Min() <= tölur[i])
                    {
                        min[i] = tölur[i];
                    }
                    else
                    {
                        min[i] = min[i - 1];
                    }
                    if (max.Max() <= tölur[i])
                    {
                        max[i] = tölur[i];
                    }
                    else
                    {
                        max[i] = max[i - 1];
                    }
                    hirðmenn++;
                    avg[i] = meðatal/(hirðmenn);
                    
                }
                else
                {
                    meðatal -= tölur[i];
                    if (min.Min() < tölur[i])
                    {
                        min[i] = tölur[i];
                    }
                    else
                    {
                        min[i] = min[i - 1];
                    }
                    if (max.Max() < tölur[i])
                    {
                        max[i] = tölur[i];
                    }
                    else
                    {
                        max[i] = max[i - 1];
                    }
                    hirðmenn--;
                    avg[i] = meðatal / (hirðmenn);
                }
                
                
               
            }
            for (int i = 0; i < tala; i++)
            {
                Console.WriteLine(min[i]+" "+max[i]+" "+avg[i].ToString("n5"));
            }
            Console.ReadKey();
            
        }
    }
}
