inp = list(raw_input())
"""
for x in range(len(inp)):
    if inp[x] == "<":
        del inp[inp.index(x)-1:inp.index(x)+1]
"""
while 1==1:
    if "<" in inp:
        del inp[inp.index("<")-1:inp.index("<")+1]
    else:
        break
print "".join(inp)
