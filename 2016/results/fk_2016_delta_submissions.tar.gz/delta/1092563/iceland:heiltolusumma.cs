using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace heiltolusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            int heiltala = Convert.ToInt32(Console.ReadLine());
            int count = 0;

            if (heiltala > 0)
            {
                for (int i = 1; i <= heiltala; i++)
                {
                count += i;
                }
                Console.WriteLine(count);
            }
            else
            {
                for (int i = 1; i <= heiltala; i--)
                {
                    count += i;
                }
                Console.WriteLine(count);
            }
            
        }
    }
}