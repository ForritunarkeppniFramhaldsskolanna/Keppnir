a = input()
b = [int(x) for x in raw_input().split()]
if 0 in b:
    i = b.index(0)+1
else:
    i = 0
j = len(b) - b[::-1].index(1)-1
m = b[i-1:j]
if 0 in b:
    print j-i+b.count(1)-m.count(1)
else:
    print a-1
