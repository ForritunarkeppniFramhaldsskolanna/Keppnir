rod = int(input("rod: "))
keppendur = int(input("keppendur"))
kepp = keppendur
margir = int(keppendur/rod)
passing = margir
for i in range(1,keppendur+1):
    if passing > 1:
        passing -= 1
        print ("*",end ="")
    else:
        print("*")
        passing = margir
