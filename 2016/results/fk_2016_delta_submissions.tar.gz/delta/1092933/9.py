n = int(raw_input())

out = 0

if n > 0:
    print sum(range(1, n+1))
else:
    print sum(range(n, 2))
