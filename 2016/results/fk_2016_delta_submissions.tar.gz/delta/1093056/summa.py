N = int(input())
A = range(N + 1)
print (sum(A))
