using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Lidaskipting
{
    class Program
    {
        static void Main(string[] args)
        {
            string stringToParse = String.Empty;
                BigInteger tala = BigInteger.Parse(Console.ReadLine());
                if (tala % 3 == 0)
                {
                    Console.WriteLine("Jebb");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Neibb");
                    Console.ReadKey();
                }

        }
    }
}
