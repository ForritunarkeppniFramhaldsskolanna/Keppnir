import random

S1 = random.randint(0, 1000)

print(S1)
