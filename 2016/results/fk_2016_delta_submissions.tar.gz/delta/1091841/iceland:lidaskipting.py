N = int(raw_input(""))

if num % 3 == 0:
    print("Jebb")
else:
    print("neibb")
    