using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Liðaskipting
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = 0;
            int reikn = 0;

            Console.WriteLine("hversu margir  ætla ad keppa?");
            N = Convert.ToInt32(Console.ReadLine());
            reikn = N % 3;
            if (N <= 3)
            {
                Console.WriteLine("jebb");
            }
            else
            {
                Console.WriteLine("neibb");
            }
            Console.ReadKey();
            Console.Clear();


            Console.ReadKey(); // Bremmsa
        }
    }
}
