using System;
using System.Collections.Generic;
using System.Text;

namespace SoftwareAndFinance
{
    class Math
    {

        static bool IsPrimeNumber(int num)
        {
            bool bPrime = true;
            int factor = num / 2;

            int i = 0;

            for (i = 2; i <= factor; i++)
            {
                if ((num % i) == 0)
                    bPrime = false;
            }
            return bPrime;
        }

        static void Main(string[] args)
        {

            Console.WriteLine("List of prime numbers between 0 - 1000");
            for (int i = 0; i < 100; i++)
            {
                if (IsPrimeNumber(i) == true)
                    Console.Write("{0,8:n}\t", i);
            }
            Console.WriteLine();
            Console.ReadKey();
        }
        
    }
}