b = int(input(""))
result = 0
for i in range(1,b+1):
  if i%1 == 0:
    result += i
print result
