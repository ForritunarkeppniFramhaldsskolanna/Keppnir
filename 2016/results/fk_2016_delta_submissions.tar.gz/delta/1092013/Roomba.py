r = input("");
d = input("");
d = int(d)
r = int(r)
if r < 101 and r > 0 and d < 101 and d > 0:
    print (int(r) * int(d));
