hird = []
minTala = 100
maxTala = 0
medal = 0
fjoldib = int(input("Fjöldi breytinga: "))
for i in range(1, fjoldib + 1):
    bætaEðaReka = str(input("A eða R: "))
    aldur = int(input("Aldur: "))
    if (bætaEðaReka == 'A'):
        hird.append(aldur)
    elif(bætaEðaReka == 'R'):
        hird.remove(aldur)
        
for aldurinn in hird:
    if(aldurinn > maxTala):
        maxTala = aldurinn
    if(aldurinn < minTala):
        minTala = aldurinn

medal = (minTala+maxTala)/2
if len(hird) == 0:
    print("-1 -1 -1")
else:
    print(minTala,maxTala,medal, end='')
