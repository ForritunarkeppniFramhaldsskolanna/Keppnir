using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            Random rand = new Random();
            Console.WriteLine(rand.Next(1, 1001));
            Console.ReadLine();
            
        }
    }
}