inputs = input("")
final = ""
for x in inputs:
    if x == "<":
        if final != "":
            final = final[:-1]
    else:
        final += x
if final != "":
    print (final)
