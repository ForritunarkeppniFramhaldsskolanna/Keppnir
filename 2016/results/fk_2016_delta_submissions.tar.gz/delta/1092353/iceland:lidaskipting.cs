using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string fjöldi = null;
            fjöldi = Console.ReadLine();
            decimal BIGGER = 0;

            BIGGER = Convert.ToDecimal(fjöldi);
            if (BIGGER % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");
            }
            Console.ReadKey();

        }
    }
}