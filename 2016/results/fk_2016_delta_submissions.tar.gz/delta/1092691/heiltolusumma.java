import java.util.Scanner;
public class heiltolusumma
{
  public static void main (String[] args)
  {
    int nedri, efri, sum = 0;
    Scanner scanner = new Scanner(System.in);
    nedri = 1;
    efri = scanner.nextInt();
    
    
    
    if(efri < 0 )
    {
      while(efri <= nedri) 
      {
        sum = sum + efri;
    
      efri++;
      }
    }
      else
      {
     while (nedri <= efri)
     {  
      sum = sum + nedri;
    
      nedri++;
     }
      }
     System.out.println(sum);
      scanner.close();
    
  }
 }

    