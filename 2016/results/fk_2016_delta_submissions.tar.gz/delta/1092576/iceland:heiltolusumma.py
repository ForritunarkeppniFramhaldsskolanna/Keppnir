tala = int(input("veldu tolu: "))
suma = 0
for i in range(1,tala+1):
    suma += i
print(suma)