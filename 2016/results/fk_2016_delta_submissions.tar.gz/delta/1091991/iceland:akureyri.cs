using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] stadir;
            List<string> U = new List<string>();
            int N = Convert.ToInt32(Console.ReadLine());
            stadir = new string[N];
            for (int i = 0; i < N; i++)
            {
                Console.ReadLine();
                stadir[i] = Console.ReadLine();
            }
            for (int i = 0; i < stadir.Length; i++)
            {
                if (!U.Contains(stadir[i]))
                {
                    U.Add(stadir[i]);
                }
            }
            int tel = 0;
            for (int i = 0; i < U.Count; i++)
            {
                tel = 0;
                for (int k = 0; k < stadir.Length; k++)
                {
                    if (stadir[k]==U[i])
                    {
                        tel++;
                    }
                }
                Console.WriteLine(U[i]+" "+tel);
                
            }
        }
    }
}
