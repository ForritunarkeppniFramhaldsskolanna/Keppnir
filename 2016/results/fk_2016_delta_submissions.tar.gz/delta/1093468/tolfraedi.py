x = int(input(''))
listi=[]
listi2=[]
suma =0
avg = 0
for i in range (0,x):
    y, z= map(str,input().split())

    if y != 'R':
        listi.append(z)
        listi2.append(y)
        mest = max(listi)
        minst = min(listi)
        suma=0
        for item in listi :
            suma = suma + int(item)
        avg = suma/len(listi)
        avg =round(avg,6)
        if len(listi) != 0:
            print(minst,mest,avg)
        else :
            print(-1,-1,-1)
    else:
        listi.remove(z)



        if len(listi) != 0:
            mest = max(listi)
            minst = min(listi)
            suma=0
            for item in listi :
                suma = suma + int(item)
            avg = suma/len(listi)
            avg =round(avg,6)
            print(minst,mest,avg)
        else :
            print(-1,-1,-1)