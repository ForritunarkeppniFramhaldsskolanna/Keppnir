using System;
class problem_g {
  static void Main () {
  Console.WriteLine (842);
  }
}