public class giskaduRett
{
  public static void main(String[] args)
  {
   int r = (int) (Math.random() * (1000 - 0)) + 0;
   System.out.println(r);
    }
  }
