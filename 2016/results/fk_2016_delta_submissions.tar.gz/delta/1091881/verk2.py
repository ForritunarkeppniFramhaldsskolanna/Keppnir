N = int(input(""))
N = N / 3
Nint = int(N)
if (N == Nint):
    print("Jebb")
else:
    print("Neibb")
