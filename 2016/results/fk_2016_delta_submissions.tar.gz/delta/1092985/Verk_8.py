a = int(input())
b = int(input())

c = a % b 

print(c)

if(a == 1):
    for x in range(a):
        print()
        for i in range(b):
            print('*', end='')
else:
    for x in range(a):
        print()
        for i in range(c):
            print('*', end='')    


'''
for i in range(c):
    print(c * '*')
    for x in range(c):
 #       print('*',end='')
        print()
       


for i in range(c):
    print(end='')
    for x in range(c):
        print('*', '\n', end='')

for i in range(b):
    print('+', end='')
    while(a)
        if(i == a):
            print('\n')
'''
