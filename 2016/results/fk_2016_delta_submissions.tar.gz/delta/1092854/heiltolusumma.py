a = input()
b = (x for x in range(1,a+1))
c = 0
for x in b:
    c += x
print c
