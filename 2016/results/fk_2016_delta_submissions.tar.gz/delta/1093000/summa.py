N = int(input('Tala: '))
A = range(N + 1)
print (sum(A))
