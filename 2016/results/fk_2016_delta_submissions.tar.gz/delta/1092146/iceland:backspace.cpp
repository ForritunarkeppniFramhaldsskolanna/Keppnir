#include <iostream>
#include <vector>
#include <algorithm>

int main() {
	std::string str;
	std::cin >> str;
	std::vector<char> chars(str.begin(), str.end());
	
	while (std::find(chars.begin(), chars.end(), '<') != chars.end())
	{
		for(int i = 0; i < chars.size(); i++)
		{
			if (chars[i+1] == '<')
			{
				chars.erase(chars.begin() + i);
				chars.erase(chars.begin() + i);
				break;
			}
		}
	}
	std::string n;
	for(int i = 0; i < chars.size(); i++)
	{
		n += chars[i];
	}
	std::cout << n;
	return 0;
}