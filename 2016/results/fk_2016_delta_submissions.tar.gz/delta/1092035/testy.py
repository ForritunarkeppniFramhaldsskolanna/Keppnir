string= input("input: ")
string2 = string.replace("<", "\b")

print(string2)