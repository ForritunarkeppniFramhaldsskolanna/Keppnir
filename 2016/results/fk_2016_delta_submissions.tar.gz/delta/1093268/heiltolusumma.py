x = int(input(''))
y = 0
d = 0

for i in range(0,100000000000000000000000000):
    if i < x:
        d += 1
        y += d
    else:
        break

print (y)