texti = input()
for i in range(0,len(texti)):
    if(texti[i] == '<'):
        texti = texti.replace(texti[i],'')
        texti = texti.replace(texti[i-2],'')

        print(texti)
