using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dæmi3
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = 0;
            string texti = null;
            texti = Console.ReadLine();
            string[] fylki = new string[texti.Length];
            foreach (char x in texti)
            {
                fylki[teljari] = x.ToString();
                teljari++;
            }
            for (int i = 0; i < fylki.Length; i++)
            {
                if (fylki[i] == "<")
                {
                    if (fylki[i-1] == null)
                    {
                        if (fylki[i - 2] == null)
                        {
                            if (fylki[i - 3] == null)
                            {
                                if (fylki[i - 4] == null)
                                {

                                }
                                else
                                {
                                    fylki[i - 4] = null;
                                }
                            }
                            else
                            {
                                fylki[i - 3] = null;
                            }
                        }
                        else
                        {
                            fylki[i - 2] = null;
                        }
                    }

                    else
                    {
                        fylki[i - 1] = null;
                    }
                    fylki[i] = null;
                }
            }
            for (int i = 0; i < fylki.Length; i++)
            {
                Console.Write(fylki[i]);
            }
            Console.ReadLine();
        }
    }
}
