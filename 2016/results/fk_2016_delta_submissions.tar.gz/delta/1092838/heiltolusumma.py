a = input()
print sum(range(1,a+1))
