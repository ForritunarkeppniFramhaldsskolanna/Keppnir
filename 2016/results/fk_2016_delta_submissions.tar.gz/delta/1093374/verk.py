a = input()
b = input()
c = int(b)
while c%a!=0:
    c += 1

i = c/a
k= (c-(i*(b%a)))/(c-b)

for x in range(b%a):
    print ("*"*i)

for x in range(c-b):
    print "*"*k


