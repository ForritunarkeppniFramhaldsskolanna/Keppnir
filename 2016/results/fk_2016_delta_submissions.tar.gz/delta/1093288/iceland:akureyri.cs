using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Akureyri");
            Console.WriteLine("Reykjavík");
            
            Console.WriteLine("Akureyri");
            Console.WriteLine("Reykjavík");
            
            Console.WriteLine("Akureyri " 2);
            Console.WriteLine("Reykjavík " 2);
        }
    }
}
