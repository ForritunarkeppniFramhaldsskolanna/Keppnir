import java.util.*;
public class tolfraedi
{
  public static void main (String[] args)
  { 
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    
    int fjoldi = Integer.parseInt(input);
    double summa = 0;
    double medalaldur =0;
    int max = 0;
    int min = 100;
    int x=0;
    
    //int ar[] = new int[];
    
    for(int i=0; i<fjoldi; i++)
    {
    String breyting = reader.nextLine();
    String[] inputList = breyting.split(" ");
    int aldur = Integer.parseInt(inputList[1]);
    
   
      //ar[i] = aldur;
    
    summa= summa + aldur;
    medalaldur = summa/(i+1);
    
    
   /* if(breyting == r)
    {
      ar[i] = 0;
      x--;
    summa=-aldur;
    medalaldur = summa/x;
    }
    */
    if(aldur>max)
    {
    max = aldur;
    }
    
    if(aldur<min)
    {
    min = aldur;
    }
    
    System.out.println(min + "  " +  max + "  " + medalaldur);
    }
    
   
  }
}