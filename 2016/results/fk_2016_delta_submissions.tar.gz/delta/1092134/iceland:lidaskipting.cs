using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_first_Console_Project
{
    class Program
    {

        static void Main(string[] args)
        {
            double N;
            N = Convert.ToDouble(Console.ReadLine());
            N = Math.Round(N, 0);
            if (N % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else 
            {
                Console.WriteLine("Neibb");
            }

            Console.ReadLine();

        }
    }
}
