n = int(raw_input())

place = []
count = []

for i in range(n * 2):
    a = raw_input()
    if (i + 1) % 2 == 0:
        if a not in place:
            place.append(a)
            count.append(1)
        else:
            count[place.index(a)] += 1

i = 0
while i < len(place):
    print place[i] + " " + str(count[i])
    i += 1
