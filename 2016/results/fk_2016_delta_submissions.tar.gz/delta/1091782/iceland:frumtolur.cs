using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keppni
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = 4;
            int i = 8;

            while (teljari < 101)
            {
                bool isvalid = true;
                if (i % 2 == 0 || i % 3 == 0 || i % 5 == 0 || i % 7 == 0)
                {
                    isvalid = false;
                }
                if (isvalid)
                {
                    Console.WriteLine(i);
                    teljari++;
                }
                i++;
            }
            Console.ReadKey();
        }
    }
}
