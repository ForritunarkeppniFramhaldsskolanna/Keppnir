using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Liðaskipting
{
    class Liðaskipting
    {
        static void Main(string[] args)
        {
            BigInteger N = 0;

            
            N = Convert.ToInt32(Console.ReadLine());
            if (N % 3 == 0)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");



            }
            Console.ReadKey();
        }
    }
}