using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int a = 2; a < 544; a++)
            {

                bool prime = true;
                for (int i = 2; i < a; i++)
                {
                    if (a % i == 0)
                    {
                        prime = false;
                    }
                }

                if (prime == true)
                {
                    Console.WriteLine(a);
                }
            }

            Console.ReadKey();
        }
    }
}
