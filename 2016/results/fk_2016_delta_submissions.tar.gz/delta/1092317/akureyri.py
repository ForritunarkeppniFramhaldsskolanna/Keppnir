x = input("")
dic = {}
places = [""]
for i in range(0,int(x)):
    name = input("")
    place = input("")
    place = place.lower()
    for y in places:
        if y == place:
            exists = True
            break
        else:
            exists = False
    if exists:
        dic[place] += 1
    else:
        places.append(place)
        dic[place] = 1
    exists = False
for x in dic:
    print (x.title() + " " + str(dic[x]))
