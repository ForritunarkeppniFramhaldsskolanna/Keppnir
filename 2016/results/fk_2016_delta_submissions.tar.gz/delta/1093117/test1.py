tala=int(input(""))
from random import randint

x=True
while x==True:
   gummi = (randint(1,1000))

   if tala == gummi:
      print(gummi)
      x = False

   else:
      x = True