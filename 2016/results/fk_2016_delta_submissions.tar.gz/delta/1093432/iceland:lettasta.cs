using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int N = 0;
            N = Convert.ToInt32(Console.ReadLine());
            int M = 0;
            M = Convert.ToInt32(Console.ReadLine());
            int[] fylki1 = new int[M];
         
            String[] daemi = null;
            daemi = Console.ReadLine().Split(' ');
            for (int i = 0; i < N; i++)
            {
                string[] score = null;
                score = Console.ReadLine().Split(' ');
                fylki1[0] += Convert.ToInt32(score[0]);
                fylki1[1] += Convert.ToInt32(score[1]);
                fylki1[2] += Convert.ToInt32(score[2]);



            }
            if (fylki1[0] == fylki1.Max())
            {
                Console.WriteLine(daemi[0]);
            }
            else if (fylki1[1] == fylki1.Max())
            {
                Console.WriteLine(daemi[1]);
            }
            else if (fylki1[2] == fylki1.Max())
            {
                Console.WriteLine(daemi[2]);
            }


        }
    }
}
