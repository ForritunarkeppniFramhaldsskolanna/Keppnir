print 1000
