keppendur = int(input())
stadsettningArray = []
while keppendur > 0 :
	keppandi = input()

	stadsetning = input()
	stadsettningArray.append(stadsetning)

	keppendur -= 1
final = {i:stadsettningArray.count(i) for i in stadsettningArray}
final2 = str(final)
final2 = final2.replace("{'", "").replace("':", "").replace(",", "\n").replace("}", "").replace(" '", "")
print (final2)



