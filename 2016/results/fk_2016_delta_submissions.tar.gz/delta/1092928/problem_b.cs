using System;
class Problem_B {
  static void Main() {
      int fjoldi = Convert.ToInt32(Console.ReadLine());
      bool lid = true;
        if(fjoldi % 3 == 0) {
          lid = false;
        }
      if (lid)
        Console.WriteLine("Neibb");
      else
        Console.WriteLine("Jebb");
  }
}
