inputs = input("");
part = 0
d = ""
r = ""
for x in inputs:
    if x == " ":
        part += 1
    else:
        if part == 0:
            d += x
        else:
            r += x

d = int(d)
r = int(r)
if r < 101 and r > 0 and d < 101 and d > 0:
    print (int(r) * int(d));
