using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Forkeppnirykgsuga
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            double sum = 0;
            string[] parts = s.Split(' ');


            double r = Convert.ToDouble((parts[0]));
            double d = Convert.ToDouble((parts[1]));

            
            if (d % 2 != 0 && r % 2 != 0)
            {
                sum = (r * d) + (r - 2);
            }
            else if (d % 2 != 0)
            {
                sum = (r * d) + d;
            }
            else if (r % 2 != 0)
            {
                sum = (r * d) + r;
            }
            else
            {
                sum = r * d;
            }



            Console.Write(sum);
            Console.ReadLine();

        }
    }
}