frumtolur = [1,3]
allartolur = []
count = 0
for i in range(2,101):
    allartolur.append(i)
#print(allartolur)
for i in range(2,101):
    for tala in allartolur:
        if tala < i:
            if float(i/tala) == int(i/tala):
                count += 1
    if count == 0:
        print(i)
        count = 0
    else:
        count = 0