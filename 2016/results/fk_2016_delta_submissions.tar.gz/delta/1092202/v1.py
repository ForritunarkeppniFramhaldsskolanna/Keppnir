listi = []
frumtolur = []
for i in range(1,100):
    if(len(listi)==2):
        frumtolur.append(i-1)

    listi=[]
    for y in range(1,100):
        if(i%y==0):
            listi.append(y)

for x in frumtolur:
    print(x)
