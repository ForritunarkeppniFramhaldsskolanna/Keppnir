a = ["kari"]

for i in a:
    for x in i:
        print (x)
        b = []
        b.append(x)
print (b)
    
