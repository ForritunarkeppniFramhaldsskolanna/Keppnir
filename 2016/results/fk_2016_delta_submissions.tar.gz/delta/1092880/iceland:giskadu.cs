using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ruma
{
    class Program
    {
        static void Main(string[] args)
        {

            Random number = new Random();
            for (int i = 0; i < 1001; i++)
            {
            int rndnumber = number.Next(0, 1000);
            Console.WriteLine(rndnumber);
            }

        }
    }
}