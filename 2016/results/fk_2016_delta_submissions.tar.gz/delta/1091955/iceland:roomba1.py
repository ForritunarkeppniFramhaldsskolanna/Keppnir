tolur = [float(x) for x in input().split()]

a,b = tolur[0],tolur[1]

print(a*b)