using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            string k = Console.ReadLine();
            List<char> C = new List<char>();
            int tel = 0;
            for (int i = 0; i < k.Length; i++)
            {
                C.Add(k[i]);
                if (C[tel]=='<')
                {
                    C.Remove(C[tel]);
                    tel--;
                    if (tel>=0)
                    {
                        C.Remove(C[tel]);
                        tel--;
                    }
                }
                tel++;
            }
            for (int i = 0; i < C.Count; i++)
            {
                Console.Write(C[i]);
            }
            Console.ReadLine();
        }
    }
}
