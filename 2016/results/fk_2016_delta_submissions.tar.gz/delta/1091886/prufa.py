x = int(input(""))
check = ""
stadir = []
keppandi = []
for i in range (0,x):
    y = str(input(""))
    u = str(input(""))
    stadir.append(u)
    keppandi.append(y)
count = 0
check = stadir[0]
check2=0
check3=0
check4=0
for item in stadir:
    if item == check:
        count += 1
    elif check2 == 0:
        check2 = item
        count2 =1
    elif item == check2:
        count2 += 1
    elif check3 == 0:
        check3 = item
        count3 =1
    elif item == check3:
        count3 += 1
    elif check4 == 0:
        check4 = item
        count4 =1
    elif item == check4:
        count4 += 1
if check4 != 0:
    print(check,count)
    print(check2,count2)
    print(check3,count3)
    print(check4,count4)
elif check3 != 0:
    print(check,count)
    print(check2,count2)
    print(check3,count3)
elif check2 != 0:
    print(check,count)
    print(check2,count2)
else:
    print(check,count)