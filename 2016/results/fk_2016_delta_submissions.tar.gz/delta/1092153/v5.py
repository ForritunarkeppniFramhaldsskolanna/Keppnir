herbL  = int(input())
herbB  = int(input())

if(herbL == 1 or herbB==1):
    print((herbB+herbL)*2)

elif(herbL%2==0 or herbB%2==0):
    print(herbB*herbL)

else:
    print(herbB*herbL+herbL-1)
