stofa = int(input('stofur: '))
nem = int(input(' nemendur: '))


def upside_down_asterisk_triangle(nem, stofa):
     """
     takes an integer n and then returns a backwards
     asterisk triangle consisting of (n) many lines
     """
     a = nem % stofa
     while (x < a):
          print("*" * (a-x))
     x = x + 1
     return

upside_down_asterisk_triangle(a)
