n = int(raw_input())
m = int(raw_input())

names = raw_input().split(' ')

points = [0]*n

for i in range(m):
    ina = map(int, raw_input().split(' '))
    for a in range(n):
        points[a] += ina[a]

print names[points.index(max(points))]
