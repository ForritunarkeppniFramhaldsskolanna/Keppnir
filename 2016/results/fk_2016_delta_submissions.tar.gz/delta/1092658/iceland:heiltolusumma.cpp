#include <iostream>

int main() {
	int sum = 0;
	int n;
	std::cin >> n;
	if (n > 0)
	{
		for(int i = 1; i <= n; i++)
		{
			sum += i;
		}
	}
	else
	{
		for(int i = 1; i >= n; i--)
		{
			sum += i;
		}
	}
	std::cout << sum;
	return 0;
}