using System;

namespace Forritunarkeppni
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			// Breytur
			int N;
			int M;

			N = Convert.ToInt32 (Console.ReadLine ());
			M = Convert.ToInt32 (Console.ReadLine ());

			if (M % N == 0) {
				for (int y = 0; y < N; y++) {
					for (int x = 0; x < (M / N); x++) {
						Console.Write ("*");
					}
					Console.WriteLine ();
				}
			} else 
			{
				for (int y = 0; y < (N - 1); y++) {
					for (int x = 0; x < M / N; x++) {
						Console.Write ("*");
					}

					Console.WriteLine ();
				}
				for (int i = 0; i < (M % N); i++) {
					Console.Write ("*");
				}
			}

			Console.ReadLine ();
		}
	}
}
