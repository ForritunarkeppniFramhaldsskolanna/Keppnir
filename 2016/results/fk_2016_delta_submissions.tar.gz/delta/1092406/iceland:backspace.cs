using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace daemi4
{
    class Program
    {
        static void Main(string[] args)
        {
            string lina = Console.ReadLine();

            lina = lina.Replace("<", "");

            Console.WriteLine(lina);

        }
    }
}