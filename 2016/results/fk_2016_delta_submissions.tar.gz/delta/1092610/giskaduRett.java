public class giskaduRett
{
  public static void main(String[] args)
  {
   int r = (int) (Math.random() * (1100)) +101;
   System.out.println(r);
    }
  }
