using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Forkeppnirykgsuga
{
    class Program
    {
        static void Main(string[] args)
        {

            BigInteger r = BigInteger.Parse(Console.ReadLine());
            BigInteger d = BigInteger.Parse(Console.ReadLine());

            BigInteger sum = r * d;

            Console.Write(sum);
            Console.ReadLine();

        }
    }
}