import random
random = random.randint(0,1000)
print(random)
