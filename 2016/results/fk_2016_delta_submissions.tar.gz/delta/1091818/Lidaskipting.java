import java.applet.Applet;
import java.awt.*;
//
// 
// 
//
public class Lidaskipting extends Applet
{
 TextField t1, tsvar;
 Button bplus;
 Label a1;
 Double D1;
 double d1, dsvar;

 public void init()
 {
  t1 = new TextField(10);
  tsvar = new TextField(15);
  bplus = new Button("+");
  a1 = new Label("fjöldi");
  
  this.add(a1); this.add(t1);
  this.add(bplus); this.add(tsvar);
 }

 public boolean action(Event e, Object o)
 {
  if (e.target == bplus)
  {
   D1 = new Double(t1.getText());
   d1 = D1.doubleValue();
   dsvar = d1;
   if ((dsvar % 3) == 0)
   {
   tsvar.setText("Jebb");
   }
   else
   {
     tsvar.setText("Neibb");
   }
   return true;
  }
  return false;
 }
}
