tala=input()
tala=int(tala)
arr=[]
kalli=tala+5
for b in range(1,kalli):
	arr.append(b)
c=0
if tala<0:
	print("0")
else:
	for i in range(tala):
		c=arr[i]+c
	print(c)