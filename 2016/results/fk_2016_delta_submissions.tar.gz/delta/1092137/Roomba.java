import java.util.Scanner;

public class Roomba {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int x = input.nextInt();
		int y = input.nextInt();
		
		if (x % 2 == 0 || y % 2 == 0) {
			System.out.println(x * y);
		}
		else {
			System.out.println((x * y) + 1);
		}
	}

}
