using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiF
{
	class Program
	{
		static void Main(string[] args)
		{
			int Q = int.Parse(Console.ReadLine());
			string[] inn = new string[Q];
			string[] ut = new string[Q];
			List<int> aldur = new List<int>();
			int laegst = 0;
			int haest = 0;
			int fjoldi = 0;
			double medal = 0.0;

			for (int i = 0; i < inn.Length; i++)
			{
				string[] tmpInput = Console.ReadLine().Split(' ');

				if (tmpInput[0] == "A")
				{
					fjoldi++;
					aldur.Add(int.Parse(tmpInput[1]));
				}
				else if (tmpInput[0] == "R")
				{
					fjoldi--;

					int tmpIndex = aldur.LastIndexOf(int.Parse(tmpInput[1]));
					aldur.RemoveAt(tmpIndex);
				}

				if (fjoldi > 0)
				{
					laegst = aldur.Min();
					haest = aldur.Max();
				}

				int sumAldur = aldur.Sum();
				medal = (double)sumAldur / fjoldi;

				if (fjoldi == 0)
				{
					ut[i] = "-1 -1 -1";
				}
				else
				{
					ut[i] = laegst + " " + haest + " " + medal.ToString("F6");
				}
			}

			for (int i = 0; i < ut.Length; i++)
			{
				Console.WriteLine(ut[i]);
			}

			Console.ReadKey();
		}
	}
}