tala = input("")
final = []
lokasvar = 0
if int(tala) > 0:
    for x in range(0, int(tala)+1):
        final.append(x)
else:
    for x in range(int(tala), 2):
        final.append(x)
for y in final:
    lokasvar += y


print (lokasvar)
