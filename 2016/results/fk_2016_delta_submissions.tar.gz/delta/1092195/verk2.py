nati = int(input(""))
einar = nati//3

if einar % 2 == 1:
    print ("Jebb")
else:
    print ("Neibb")


