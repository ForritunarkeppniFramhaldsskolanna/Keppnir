S = 400
X = S + 100
S = 100 - X
print(X)
