x = input("")
dic = {}
places = [""]
for i in range(0,int(x)):
    name = input("")
    place = input("")
    for y in places:
        if y == place:
            exists = True
        else:
            exists = False
    if exists:
        dic[place] += 1
    else:
        places.append(place)
        dic[place] = 1
for x in dic:
    print (x + " " + str(dic[x]))
