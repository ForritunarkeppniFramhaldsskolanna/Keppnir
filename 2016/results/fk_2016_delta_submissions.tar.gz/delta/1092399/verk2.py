strengur = input()
strengur = str(strengur)

h = strengur.replace("<","\b")
print(h)
