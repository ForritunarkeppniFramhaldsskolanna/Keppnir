using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {

            int input = Convert.ToInt32(Console.ReadLine());
            int summa = 0;

            if (input > 0)
            {
                for (int i = 1; i <= input; i++)
                {
                    summa += i;
                }
            }

            if (input < 0)
            {
                for (int i = 1; i >= input; i--)
                {
                    summa += i;
                }
            }
            Console.Clear();
            Console.Write(summa);
            Console.ReadKey();
        }
    }
}
