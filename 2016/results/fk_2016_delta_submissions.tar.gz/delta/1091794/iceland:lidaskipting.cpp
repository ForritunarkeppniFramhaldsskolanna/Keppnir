using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Int64 N = 0, K=0;

            N = Convert.ToInt64(Console.ReadLine());

            K = N % 3;
            if (K==0)
            {
                Console.WriteLine("Jebb");
            }
            else if (K!=0)
            {
                Console.WriteLine("Neibb");
            }


        }
    }
}
