r, d = map(int, raw_input().split(" "))

down = False

moves = [(r * d) - 1, (r * d) - 1]

def up():
    global moves, r, d
    pos = [0, 0]
    if d % 2 != 0:
        pos[0] = r - 1
        # pos[2] = d-1
    # else:
    pos[1] = d - 1
    moves[1] += pos[1] + pos[0]

def right():
    global moves, r, d
    pos = [0, 0]
    if r % 2 != 0:
        pos[1] = d - 1
    pos[0] = r - 1
    moves[0] += pos[1] + pos[0]

up()
right()
moves.append(r * d)
print min(moves)

# while posu[0] != r-1 or posu[1] != d-1:
#     if posu[0] == r-1 and not down:
#         moves += 1
#         posu[1] += 1
#         down = True
#     elif down:
#         moves += 1
