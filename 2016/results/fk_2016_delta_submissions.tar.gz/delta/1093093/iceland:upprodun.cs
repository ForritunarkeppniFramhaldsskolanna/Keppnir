using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rodun
{
    class Program
    {
        static void Main(string[] args)
        {
            int radir = Convert.ToInt32(Console.ReadLine());
            int nemendur = Convert.ToInt32(Console.ReadLine());

            int einrod = nemendur / radir;
            int lel = radir - 1;
            int seinasta = nemendur % radir;

            if (seinasta == 0)
            {

            
            for (int i = 1; i < radir; i++)
            {
                for (int e = 0; e < einrod; e++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            }
            else
            {
                for (int i = 1; i < lel; i++)
                {
                    for (int e = 0; e < einrod; e++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }
                for (int i = 0; i < seinasta; i++)
                {
                    Console.Write("*");
                }
            }

        }
    }
}