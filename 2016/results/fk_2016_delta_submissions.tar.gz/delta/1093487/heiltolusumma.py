a = input()
if a<0:
    print -(a*(a-1)/2)+1
elif a>0:
    print a*(a+1)/2
else:
    print 0
