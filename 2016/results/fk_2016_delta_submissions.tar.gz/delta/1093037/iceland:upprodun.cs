using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal A = Convert.ToInt64(Console.ReadLine());
            decimal B = Convert.ToInt64(Console.ReadLine());
            decimal C = B % A;
            decimal D = Math.Floor(B/A);
            for (int i = 0; i < A; i++)
            {
                if (C>0)
                {
                    D = Math.Floor(B / A) + 1;
                    C--;
                }
                else
                {
                    D = Math.Floor(B / A);
                }
                for (int k = 0; k < D-1; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("*");
            }
        }
    }
}
