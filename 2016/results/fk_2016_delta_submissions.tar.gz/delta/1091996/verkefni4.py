a = [int(x) for x in raw_input().split()]
if a[0] != 1 and a[1] != 1 and (a[0]%2==0 or a[1]%2==0):
    print a[0]*a[1]
elif a[0] != 1 and a[1] != 1:
    print a[0]*a[1]+min(a)-2
else:
    print (a[0]*a[1])*2-2
