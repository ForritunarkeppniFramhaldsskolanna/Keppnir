for i in range(2,545):
    if all(i%y!=0 for y in range(2,i)):
       print (i)