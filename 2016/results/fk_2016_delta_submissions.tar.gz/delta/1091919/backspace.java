import java.util.Scanner;

public class backspace
{
  public static void main (String[] args)
  {  
   Scanner hlutur = new Scanner(System.in);
   String fjoldi = hlutur.nextLine();
   while (fjoldi.contains("<"))
   {
    fjoldi = fjoldi.replaceAll("^<+|[^<]<", "");
   
   }
   System.out.println(fjoldi);
  // System.out.println(fjoldi.replaceAll("^<+|.<+", ""));
  } 
}
