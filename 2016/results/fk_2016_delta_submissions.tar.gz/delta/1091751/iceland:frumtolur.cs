using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiA
{
	class Program
	{
		static void Main(string[] args)
		{
			int numPrimes = 0;
			int i = 2;

			while (numPrimes < 100)
			{
				bool isPrime = true;

				for (int j = 2; j < i / 2 + 1; j++)
				{
					if (i % j == 0)
					{
						isPrime = false;
						break;
					}
				}

				if (isPrime)
				{
					numPrimes++;
					Console.WriteLine(i);
				}

				i++;
			}

			Console.ReadKey();
		}
	}
}