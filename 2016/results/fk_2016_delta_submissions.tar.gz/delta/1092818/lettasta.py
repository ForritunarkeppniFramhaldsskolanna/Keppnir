a = input()
b = input()
daemi = raw_input().split()
stig = [0 for x in range(a)]
for x in range(b):
    c = [int(x) for x in raw_input().split()]
    for x in range(len(stig)):
        stig[x] += c[x]
print daemi[stig.index(max(stig))]
