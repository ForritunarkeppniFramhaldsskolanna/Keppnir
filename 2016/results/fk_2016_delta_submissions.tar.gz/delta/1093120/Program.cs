using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simanumer
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldinr;
            fjoldinr = Convert.ToInt32(Console.ReadLine());
            int fyrirspurnir;
            int simanumer;
            int counter =0;
            int fyrirspurn;
            List<int> numer = new List<int>();
            List<int> fnumer = new List<int>();
            for (int i = 0; i < fjoldinr; i++)
            {
                simanumer = Convert.ToInt32(Console.ReadLine());
                simanumer.ToString();
                if (simanumer.ToString().Length == 7)
                {
                    numer.Add(simanumer);
                }
                
            }
            fyrirspurnir = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < fyrirspurnir; i++)
            {
                    fyrirspurn = Convert.ToInt32(Console.ReadLine());
                    fnumer.Add(fyrirspurn);
            }

            for (int i = 0;  i < fyrirspurnir; i++)
            {
                foreach (int k in fnumer)
                {
                    foreach (int  h in numer)
                    {
                        if (h.ToString().Contains(k.ToString()) )
                        {
                            counter++;
                        }

                    }
                }
                Console.WriteLine(counter);
                Console.ReadKey();
            }
        }
    }
}
