using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            int u = 9999;
            int tel = 0;
            bool t = true;
            for (int i = 1; i < u; i++)
            {
                t = true;
                for (int b = 2; b < i; b++)
                {
                    for (int k = 2; k < i; k++)
                    {
                        if (b*k==i)
                        {
                            t = false;
                        }
                    }
                }
                if (t)
                {
                    Console.WriteLine(i);
                    tel++;
                }
                if (tel==100)
                {
                    u = 0;
                }
            }        
        }
    }
}
