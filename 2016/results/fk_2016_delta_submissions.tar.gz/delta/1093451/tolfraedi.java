import java.util.*;
import java.math.BigInteger;
import java.math.BigDecimal;
public class tolfraedi
{
  public static void main (String[] args)
  { 
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    
    int fjoldi = Integer.parseInt(input);
    //BigInteger fjoldi = new BigInteger("fj");
    double summa = 0;
    double medalaldur = 0;
    int max = 1;
    int min = 100;
    //int x=0;

    
    //int ar[] = new int[];
    
    for(long i=0; i<fjoldi; i++)
    {
    String breyting = reader.nextLine();
    String[] inputList = breyting.split(" ");
    String breyt = inputList[0];
    int aldur = Integer.parseInt(inputList[1]);
    
   
      //ar[i] = aldur;
  // if(breyt == "A") 
   
     //x++;
     summa = summa+aldur;
    medalaldur = summa/(i+1);
   
    
    /*if(breyt == "R")
    {
      x--;
    summa=-aldur;
    medalaldur = summa/x;
    }*/
    
    if(max<aldur)
    {
    max = aldur;
    }
    
    if(aldur<min)
    {
    min = aldur;
    }
    
    System.out.println(min + " " +  max + " " + medalaldur);
    }
    
   
  }
}