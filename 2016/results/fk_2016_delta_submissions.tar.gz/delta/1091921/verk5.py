var1, var2 = raw_input("").split(' ')

print int(var1) * int(var2)