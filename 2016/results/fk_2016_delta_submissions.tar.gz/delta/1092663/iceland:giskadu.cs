using System;

namespace Forritunarkeppni
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			// Breytur
			Random rnd = new Random();
			int rettTala;
			int giskTala;
			int X;
			int S;

			rettTala = rnd.Next (1, 1001);
			giskTala = Convert.ToInt32 (Console.ReadLine ());
			X = rettTala - giskTala;

			if (X < 0) {
				X *= (-1);
			}

			S = 100 - X;

			if (S < 0) {
				S = 0;
			}

			Console.WriteLine (S);

			Console.ReadLine ();
		}
	}
}
