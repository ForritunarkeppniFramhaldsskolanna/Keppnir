using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Forkeppnirykgsuga
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();

            string[] parts = s.Split(' ');
            
            
            double r = Convert.ToDouble((parts[0]));
            double d = Convert.ToDouble((parts[1]));

            if (r > d)
            {
                double sum = (r * d) + (d - 2);
                Console.Write(sum);
            }
            else
            {
                double sum = (r * d) + (r - 2);
                Console.Write(sum);
            }
            

            

            
            Console.ReadLine();

        }
    }
}