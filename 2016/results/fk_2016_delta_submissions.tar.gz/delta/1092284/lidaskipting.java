import java.util.Scanner;
import java.math.BigInteger;
import java.math.*;

public class lidaskipting
{
  public static void main (String[] args)
  {  
   Scanner hlutur = new Scanner(System.in);
   String fjoldi = hlutur.nextLine();
   //int x = Integer.parseInt(fjoldi);
   BigInteger stor = new BigInteger(fjoldi);
   String y = "3";
   BigInteger deiltMed = new BigInteger(y);
   //BigInteger deiling = stor.divide(deiltMed); 
   String z = "0";
   BigInteger nullid = new BigInteger(z);
   BigInteger bi3 = stor.mod(deiltMed);

   
   if(bi3.equals(nullid))

   {
     System.out.println("Jebb");
   }
   else
   {
     System.out.println("Neibb");
   }
  } 
}
