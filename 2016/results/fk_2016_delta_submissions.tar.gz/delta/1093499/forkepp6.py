a = input()
teljari = int(a)
tala = 0
for i in range(int(a)):
	tala = tala + teljari
	teljari = teljari - 1
print (tala)