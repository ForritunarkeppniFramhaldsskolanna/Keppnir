using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int S = 0;

            S = random.Next(1, 1000);
            Console.WriteLine(S);
        }
    }
}
