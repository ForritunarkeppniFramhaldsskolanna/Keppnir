using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni_H
{
    class Program
    {
        static void Main(string[] args)
        {
            int Stofa = 0;
            int Nemandi = 0;
            int utkoma = 0;
            int afgangur = 0;

            Stofa = Convert.ToInt32(Console.ReadLine());

            Nemandi = Convert.ToInt32(Console.ReadLine());

            utkoma = Nemandi / Stofa;
            afgangur = Nemandi % Stofa;

            for (int i = 1; i <= Stofa; i++)
            {

                for (int K = 1; K <= utkoma; K++)
                {
                    Console.Write("*");
                }
                
                Console.WriteLine("");
            }
            for (int t = 0; t < afgangur; t++)
            {
                Console.WriteLine("*");
            }

            Console.ReadKey();
        }
    }
}