x =int(input(''))
z=0
y = x+1

z = (x*y)/2
print(z)
