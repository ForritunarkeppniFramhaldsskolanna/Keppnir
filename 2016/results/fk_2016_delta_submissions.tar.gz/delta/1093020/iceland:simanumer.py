s = []

for a0 in range(int(input())):
	s.append(input())
	
for a0 in range(int(input())):
	q = input()
	counter = 0
	
	for d in s:
		if d[0:len(q)] == q:
			counter += 1
	print(counter)