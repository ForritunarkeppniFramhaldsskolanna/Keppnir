r = input("");
d = input("");
d = int(d)+1
r = int(r)+1
if r < 102 and r > 0 and d < 102 and d > 0:
    print (int(r) * int(d));
