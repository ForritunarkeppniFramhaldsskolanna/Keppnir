#include <iostream>
#include <vector>
#include <string>

int main() {
    long long a0;
    std::cin >> a0;
    std::vector<std::string> s;
    std::string output;
    for (long long i = 0; i < a0; i++)
    {
        std::string d;
        std::cin >> d;
        s.push_back(d);
    }
    long long a1;
    std::cin >> a1;
    for(long long i = 0; i < a1; i++)
    {
        std::string q;
        std::cin >> q;
        long long counter = 0;
        
        for(long long j = 0; j < s.size(); j++)
        {
            if (s[j].substr(0,q.length()) == q)
            {
                counter++;
            }
        }
        output += std::to_string(counter) + "\n";
    }
    std::cout << output;
    
    return 0;
}