print 1
