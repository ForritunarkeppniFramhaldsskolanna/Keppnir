import java.util.Scanner;

public class roomba
{
    public static void main( String [] args)
    {
      int talning = 0;
       Scanner hlutur = new Scanner(System.in);
       String setning = hlutur.nextLine();
       String[] inputList = setning.split(" ");
       int r = (Integer.parseInt(inputList[0]));
       int d = (Integer.parseInt(inputList[1]));
      
      boolean [] [] golf = new boolean[r][d];
      
      if(r%2 == 0)
      {
        
      for(int i = 0; i<r; i++)
      {
        golf[i][0] = true;
        talning++;
      }
      for(int k=1; k<=r; k++)
      {
        if((r-k)%2 != 0)
        {
      for(int j=1; j<d; j++)
      {
        golf[r-k][j] = true;
        talning++;
      }
        }
        if((r-k)%2 == 0)
{
      for(int j=d-1; j>0; j--)
      {
       golf[r-k][j] = true;
       talning++;
      }
}
      
        }
      }
      
      if(r%2 != 0 && d%2 == 0)
      {
        
        for(int i = 0; i<r; i++)
      {
        golf[i][0] = true;
        talning++;
      }
        for(int k = 1; k<d; k++)
        {
          if(k%2!=0)
          {
        for(int i = 1; i<r; i++)
        {
          golf[i][k] = true;
          talning++;
        }
          }
          if(k%2==0)
          {
            for(int i = r-1; i>0; i--)
        {
          golf[i][k] = true;
          talning++;
          }
        }
        }
        
        for(int j = d-1; j>0; j--)
        {
         golf[0][j] = true;
         talning++;
        }
        
        
        
      }
      if(r%2!=0 && d%2!= 0)
      {
        talning = r*d+1;
      }
      for(int i = 0; i<r; i++)
      {
        for(int j = 0; j<d; j++)
        {
          System.out.print(golf[i][j]);
        }
        System.out.println();
      } 
      System.out.println(talning);
      
      
      
      
      
    }
}