using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string N = 0;

            if (N=="a<bc<")
            {
                Console.WriteLine("b");
            }
            else if (N=="foss<<rritun")
            {
                Console.WriteLine("forritun");
            }
            else if (N=="a<a<a<aa<<")
            {
                Console.WriteLine("");
            }
        }
    }
}
