import java.util.Scanner;
public class lidaskipting
{
  public static void main (String[] args)
  {
    int tala;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Hva� eru margir ��tttakendur?");
    tala = scanner.nextInt();
    
    if(tala <= 0 )
    {
      System.out.println("talan �arf a� vera j�kv��");
      scanner.close();
      return;
    }
    else if((tala%3)==0)
    {
      System.out.println("jebb");
    }
    else
    {
      System.out.println("neibb");
    }
    scanner.close();
  }
}
   
    