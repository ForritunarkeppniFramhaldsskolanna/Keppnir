using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace heiltolusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            long heiltala = Convert.ToInt64(Console.ReadLine());
            long count = 0;

            if (heiltala > 0)
            {
                for (long i = 1; i <= heiltala; i++)
                {
                count += i;
                }
                Console.WriteLine(count);
            }
            else
            {
                for (long i = 1; i <= heiltala; i--)
                {
                    count += i;
                }
                Console.WriteLine(count);
            }
            
        }
    }
}
