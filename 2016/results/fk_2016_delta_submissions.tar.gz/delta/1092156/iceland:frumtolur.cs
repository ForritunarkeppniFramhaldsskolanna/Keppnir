using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int H = 1;
            for (int i = 2; i <= 541; i++)
            {
                int isPrime = 0;
                for (int n = 1; n < i; n++)
                {
                    if (i % n == 0)
                        isPrime++;

                    if (isPrime == 2) break;
                }
                if (isPrime != 2)
                    Console.WriteLine(i);

                isPrime = 0;
            }
            Console.ReadKey();
        }
    }
}
