using System;

namespace Lidaskipting
{ 
	class Programs
	{        
		static void Main(string[] args)
		{

			Console.WriteLine("");
			ulong intDiv3 = Convert.ToUInt64( Console.ReadLine());
			if (intDiv3 % 3 == 0)
			{
				Console.WriteLine("Jebb", intDiv3);
			}
			else
			{
				Console.WriteLine("Neibb", intDiv3);
			}

			Console.ReadLine();
		}        
	}    
}