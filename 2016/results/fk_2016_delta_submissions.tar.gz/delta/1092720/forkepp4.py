import random
number = random.randrange(250, 261, 2)
print (number)