print 350
