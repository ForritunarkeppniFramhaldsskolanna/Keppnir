using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Backspace_Symbol
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = null;
            input = Console.ReadLine();

            input = Regex.Replace(input, "<", "\b");
            Console.WriteLine(input);

        }//end main
    }//end class
}