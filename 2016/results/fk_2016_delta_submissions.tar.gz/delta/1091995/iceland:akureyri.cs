using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace daemi3
{
    class Program
    {
        static void Main(string[] args)
        {

            int numer = Convert.ToInt32(Console.ReadLine());
            int count = 0; int count2 = 0;

            for (int i = 0; i < numer; i++)
            {
                string name = Console.ReadLine();
                string place = Console.ReadLine();
                if (place == "Reykjavik")
                {
                    count++;
                }

                else if (place == "Akureyri")
                {
                    count2++;
                }
            }
                Console.WriteLine("Reykjavik " +count);
                Console.WriteLine("Akureyri " +count2);

            Console.ReadKey();

        }
    }
}