using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keppni
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] s = Console.ReadLine().ToCharArray();
            List<char> n = new List<char>(s);
            while (n.Contains('<'))
            {
                for (int i = 0; i < n.Count()-1; i++)
                {
                    if (n[i+1] == '<')
                    {
                        n.RemoveAt(i);
                        n.RemoveAt(i);
                        i--;
                    }   
                }
            }
            Console.WriteLine(String.Join("", n));
            Console.ReadKey();
        }
    }
}
