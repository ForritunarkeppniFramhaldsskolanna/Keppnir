hird = []
ut = []
for x in range(input()):
    a = raw_input().split()
    if a[0] == "A":
        hird.append(int(a[1]))
    if a[0] == "R":
        hird.remove(int(a[1]))
    if len(hird)==0:
        ut.append((-1, -1, -1))
    else:
        ut.append((min(hird), max(hird), "%.6f" % (float(float(sum(hird))/float(len(hird))))))

for x in ut:
    a = []
    for y in x:
        a.append(str(y))
    print " ".join(a)
