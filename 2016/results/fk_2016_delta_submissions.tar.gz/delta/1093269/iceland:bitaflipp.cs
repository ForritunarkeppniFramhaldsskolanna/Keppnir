using System;

namespace Heiltolsmma
{
	class MainClass
	{
		public static void Main (string[] args)
		{ 
			string runa;
			int FJ, reit = 0, heild = 0, fyrrHeild = 0;
			FJ = Convert.ToInt32 (Console.ReadLine ());
			runa = Console.ReadLine ();
			int[] EN = new int[FJ];
			for (int i = 0; i < FJ; i++)
			{
				EN [i] = Convert.ToInt32(runa.Substring (reit, 1));
				reit += 2;
			}
			for (int i = 0; i < FJ; i++)
			{
				for (int j = 0; j < (FJ - i); j++)
				{
					for (int k = 0; k <= j; k++)
					{
						if (EN [i + k] == 0)
						{
							EN [i + k] = 1;
						}
						else
						{
							EN [i + k] = 0;
						}
					}
					for (int k = 0; k < FJ; k++)
					{
						if (EN [k] == 1)
						{
							heild++;
						}
					}
					if (heild > fyrrHeild)
					{
						fyrrHeild = heild;
					}
					reit = 0;
					heild = 0;
					for (int y = 0; y < FJ; y++)
					{
						EN [y] = Convert.ToInt32(runa.Substring (reit, 1));
						reit += 2;
					}
				}
			}
			Console.WriteLine (fyrrHeild);
			Console.ReadKey ();
		}
	}
}
