print(270)
