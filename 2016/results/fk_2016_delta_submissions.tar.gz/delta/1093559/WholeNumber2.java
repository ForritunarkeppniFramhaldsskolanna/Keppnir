import java.util.Scanner;

public class WholeNumber2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		long number = input.nextInt();
		long out = 0;
		if (number > 0) {
			for (long i = 0; i <= number; i++) {
				out = out + i;
			}
		}
		else {
			for (long i = number; i <= 1; i++) {
				out = out + i;
			}
		}
		
		System.out.println(out);
	
	}
}
