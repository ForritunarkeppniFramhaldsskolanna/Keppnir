import random
number = random.randrange(275, 301, 2)
print (number)