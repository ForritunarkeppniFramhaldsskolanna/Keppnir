import random
number = random.randrange(200, 251, 2)
print (number)