import random
print(random.randint(-1000,0))