using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] splitarray = input.Split(' ');
            int tala1 = Convert.ToInt32(splitarray[0]);
            int tala2 = Convert.ToInt32(splitarray[1]);
            Console.Clear();
            Console.WriteLine(tala1 * tala2);
            Console.ReadKey();
        }
    }
}
