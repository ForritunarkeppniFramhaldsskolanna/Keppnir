using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {

            Int64 inntak = Convert.ToInt64(Console.ReadLine());
            Int64 reikningur = 0;
            reikningur = (inntak * (inntak + 1)) / 2;
            Console.WriteLine(reikningur);
            Console.ReadLine();

        }
    }
}
