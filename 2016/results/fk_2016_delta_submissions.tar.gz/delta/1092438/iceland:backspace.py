listi = []
stafir = str(input("Skrifaðu setninu hérna: "))
stafir.lower()
for orð in stafir:
    for stafur in orð:
        if stafur != '<':
            listi.append(orð)
        else:
            losa = len(listi) - 1
            listi.pop(losa)
for i in listi:
    print(i,end='')
