using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] inntak = (Console.ReadLine().Split(' '));
            int[] eintak = new int[2];
            int tala = 0;
            for (int i = 0; i < 2; i++)
            {
                eintak[i] = Convert.ToInt32(inntak[i]);
            }
            tala = eintak[0] * eintak[1];
            Console.WriteLine(tala);

        }
    }
}