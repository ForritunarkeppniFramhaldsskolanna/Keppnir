x = int(input())
listi=[]



for i in range(0,x):

    z= str(input())
    listi.append(z)

x = int(input())
for i in range(0,x):
    z= str(input())
    count =0
    for item in listi:
        if z in item:
            count += 1
    print(count)


