using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forkeppniprim
{
    class Program
    {
        static bool IsPrimeNumber(int num)
        {
            bool bPrime = true;
            int factor = num / 2;

            int i = 0;

            for (i = 2; i <= factor; i++)
            {
                if ((num % i) == 0)
                    bPrime = false;
            }
            return bPrime;
        }


        static void Main(string[] args)
        {

            for (int i = 2; i < 545; i++)
            {
                if (IsPrimeNumber(i) == true)
                    Console.Write(i + "\n");
            }
            Console.ReadLine();
            

        }
    }
}