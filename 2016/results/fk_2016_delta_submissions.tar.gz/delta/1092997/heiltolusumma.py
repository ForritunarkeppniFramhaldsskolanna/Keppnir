a = input()
if a<0:
    print -(a*(a+1)/2)+1+a
else:
    print a*(a+1)/2
