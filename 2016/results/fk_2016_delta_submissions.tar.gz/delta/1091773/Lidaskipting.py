n = int(input())

if n % 3 == 0:
    print ("Jebb")
else:
    print ("Neibb")