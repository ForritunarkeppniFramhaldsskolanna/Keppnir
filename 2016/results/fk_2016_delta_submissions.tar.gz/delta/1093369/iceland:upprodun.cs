using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keppnaleppni
{
    class Program
    {
        static void Main(string[] args)
        {
            int total = 0, divider= 0;

            divider = Convert.ToInt32(Console.ReadLine());
            total = Convert.ToInt32(Console.ReadLine());

            List<int> test = DistributeInteger(20, 3).ToList();

            test.ForEach(Console.WriteLine);



            Console.ReadKey();

        }//end main
        public static IEnumerable<int> DistributeInteger(int total, int divider)
        {
            if (divider == 0)
            {
                yield return 0;
            }
            else
            {
                int rest = total % divider;
                double result = total / (double)divider;

                for (int i = 0; i < divider; i++)
                {
                    if (rest-- > 0)
                    {
                        yield return (int)Math.Ceiling(result);
                    }
                    else
                    {
                        yield return (int)Math.Floor(result);
                    }
                }
            }
        }//end class
    }
}
