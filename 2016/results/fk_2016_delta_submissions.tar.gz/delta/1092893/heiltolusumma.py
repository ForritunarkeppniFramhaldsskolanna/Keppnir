a = input()
counter = 1
summa = 0
while counter <= a:
    summa += counter
    counter += 1
print summa
