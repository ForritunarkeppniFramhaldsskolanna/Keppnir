using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaemiH
{
	class Program
	{
		static void Main(string[] args)
		{
			int stofur = int.Parse(Console.ReadLine());
			int keppendur = int.Parse(Console.ReadLine());
			int tmp = keppendur / stofur;
			int tmpLeft = keppendur % stofur;
			
			for (int i = 0; i < stofur; i++)
			{
				for (int j = 0; j < tmp; j++)
				{
					Console.Write("*");
				}

				if (tmpLeft > 0)
				{
					Console.Write("*");
					tmpLeft--;
				}

				Console.WriteLine();
			}

			Console.ReadKey();
		}
	}
}