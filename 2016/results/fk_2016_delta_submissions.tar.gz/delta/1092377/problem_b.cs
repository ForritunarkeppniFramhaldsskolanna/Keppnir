using System;
class Problem_B {
  static void Main() {
      int fjoldi = Convert.ToInt32(Console.ReadLine());
      int i=3;
      bool lid = true;
      while (lid && i<fjoldi) {
        if (fjoldi%i++ == 0) {
          lid = false;
        }
      }
      if (lid)
        Console.WriteLine("Jebb");
      else
        Console.WriteLine("Neibb");
  }
}
