using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Forkepni
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            
            
            Console.Write(r.Next(220, 226));

            
        }
    }
}