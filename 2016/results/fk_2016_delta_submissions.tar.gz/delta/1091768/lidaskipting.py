x = input("")
if int(x) % 3 == 0:
    print("Jebb")
else:
    print("Neibb")
