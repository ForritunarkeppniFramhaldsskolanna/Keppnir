public class frumtolur2
{
  public static void main(String [] args)
  {
    int talning = 0;
    boolean [] erfrumtala = new boolean[542];
    for(int i = 2; i<542; i++)
    {
      erfrumtala[i] = true;
    }
    for(int i= 2; i*i<542; i++)
    {
      if(erfrumtala[i])
      {
       for(int j = i; i*j<542; j++)
       {
         erfrumtala[i*j] = false;
       }
      }
    }
    for(int i = 2; i<542; i++)
    {
      /*if(erfrumtala[i])
      {
        talning++;
        if(talning==100)
        {break;}
      } */
}
    for(int i = 2; i<542; i++)
    {
    if(erfrumtala[i])
    {System.out.print(i + " ");}
    }
    
    
  }
}
  