using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vrumtolur
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;

            for (int i = 1; i <= 100; i++)
            {
                for (int j = 2; j <= 100; j++)
                {

                    if (i != j && i % j == 0)
                    {
                        flag = false;
                        break;
                    }

                }

                if (flag)
                {
                    Console.WriteLine(i);
                }

                flag = true;
            }

            Console.ReadKey();
        }
    }
}

