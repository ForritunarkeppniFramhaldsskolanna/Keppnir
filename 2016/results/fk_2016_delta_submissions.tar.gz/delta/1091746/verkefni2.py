def team(n):
    if n%3==0:
        print "Jebb"
    else:
        print "Neibb"

print team(input())

