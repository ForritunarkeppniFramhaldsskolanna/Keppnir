using System;

namespace Forritunarkeppni
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			// Breytur
			int intFjoldi;
			int intIbuar = 0;
			int intTeljari = 0;

			// Lesa inn fjölda keppenda
			intFjoldi = Convert.ToInt32 (Console.ReadLine ());

			// Búa til array yfir alla staðina
			string[] strStadir = new string[intFjoldi];

			// Lesa inn alla staðina
			for (int i = 0; i < intFjoldi; i++) {
				Console.ReadLine ();
				strStadir [i] = Console.ReadLine ();
			}

			// Hlaupa í gegnum array-ið og leita að fjölda strengja sem eru eins
			for (int i = 0; i < strStadir.Length; i++) {
				for (int b = 0; b < strStadir.Length; b++) {
					if (strStadir [i].ToString() == strStadir [b].ToString()) {
						intTeljari++;
					}
				}
			}

			intTeljari = intTeljari / 2;
			Console.WriteLine (intTeljari);

			Console.ReadLine ();
		}
	}
}
