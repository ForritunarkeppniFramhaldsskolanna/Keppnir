using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emty2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] text;
            List<long> L = new List<long>();
            string A;
            string[] B;
            int fjoldi = Convert.ToInt32(Console.ReadLine());
            text = new string[fjoldi];
            for (int i = 0; i < fjoldi; i++)
            {
                text[i] = Console.ReadLine();
            }
            for (int i = 0; i < fjoldi; i++)
            {
                A = text[i];
                B = A.Split(' ');
                if (B[0]=="A")
                {
                    L.Add(Convert.ToInt64(B[1]));
                }
                else if (B[0]=="R")
                {
                    L.Remove(Convert.ToInt64(B[1]));
                }
                if (L.Count<1)
                {
                    Console.WriteLine("-1 -1 -1");
                }
                else
                {
                    Console.WriteLine(L.Min() + " " + L.Max() + " " + L.Average().ToString("N6"));
                }
            }
            Console.ReadLine();
        }
    }
}
