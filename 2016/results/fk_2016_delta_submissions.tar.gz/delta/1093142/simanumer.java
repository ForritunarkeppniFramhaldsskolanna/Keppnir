import java.util.*;
public class simanumer
{
  public static void main (String[] args)
  { 
    Scanner reader = new Scanner(System.in);
    String input = reader.nextLine();
    int fjoldinr = Integer.parseInt(input);
    String simanr[] = new String[fjoldinr];
    int nr[] = new int[fjoldinr];
    
    for(int i=0; i<fjoldinr; i++)
    {
    simanr[i] = reader.nextLine();
    nr[i] = Integer.parseInt(simanr[i]);
    }
    
    String q = reader.nextLine();
    int n = Integer.parseInt(q);
    String fyrirspurn;
    int count = 0;
    double brot = 0;
    int fyrir = 0;
    double brot2 = 0;
    int brot3 = 0;
    
    for(int j = 0; j<n; j++)
    {
    fyrirspurn = reader.nextLine();
    fyrir = Integer.parseInt(fyrirspurn);
    
    int lengd = fyrirspurn.length();
    System.out.println(lengd);
    int veldi = 7-lengd;
    
    for(int k = 0; k<lengd; k++)
    {
    
    //for(int l=0; l<lengd; l++)
    
    brot = (nr[k]/Math.pow(10, veldi));
    brot2 = Math.floor(brot);
    brot3 = (int) brot2;
    System.out.println(brot3);
    
    
    if(brot3 == fyrir)
      count++;
    }
      System.out.println(count);
      count = 0;
    }
    
  }
}