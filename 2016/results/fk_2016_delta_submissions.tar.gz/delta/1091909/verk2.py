nati = int(input(""))

einar = (nati/3)


if einar % 2 == 0:
    print ("Jebb")
else:
    print ("Neibb")
