a = [int(x) for x in raw_input().split()]
if a[0] != 1 and a[1] != 1:
    print a[0]*a[1]
else:
    print (a[0]*a[1])*2-2
