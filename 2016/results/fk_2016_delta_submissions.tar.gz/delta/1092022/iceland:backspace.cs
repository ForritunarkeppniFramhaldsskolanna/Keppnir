using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForritunarkeppniMenntakólanna
{
    class Lidur1
    {
        static void Main(string[] args)
        {
            string texti = Console.ReadLine();
            for (int i = 0; i < texti.Length; i++)
            {
                if (texti[i] == '<')
                {
                    texti = texti.Remove(i - 1);
                    texti = texti.Remove('<');
                }
            }
            Console.WriteLine(texti);
        }
    }
}