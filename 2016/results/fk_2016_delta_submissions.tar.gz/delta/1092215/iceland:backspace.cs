using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            string inntak = Console.ReadLine();
            List<char> eintak = new List<char>();
            for (int i = 0; i < inntak.Length; i++)
            {
                eintak.Add(inntak[i]);
            }
            string eintak2 = null;
            for (int i = 0; i < eintak.Count; i++)
            {
                if (eintak[i] == '<')
                {
                    eintak.RemoveAt(i);
                    eintak.RemoveAt(i-1);
                    i = i - 2;
                }
            }
            for (int i = 0; i < eintak.Count; i++)
            {
                eintak2 += eintak[i];
            }
            Console.WriteLine(eintak2);


        }
    }
}