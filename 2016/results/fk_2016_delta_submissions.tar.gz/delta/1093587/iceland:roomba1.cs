using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PLS HALP I DONT KNOW HOW TO CODE!!!!");
            Console.Beep(5000, 14000);
            Console.WriteLine("ERROR 404 coding skills not found");
            Console.ReadKey();
        }
    }
}
