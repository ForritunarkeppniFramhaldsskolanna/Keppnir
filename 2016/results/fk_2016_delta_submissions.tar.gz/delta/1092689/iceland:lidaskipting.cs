using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger N = 0;
            BigInteger K = 0;

            N = Convert.ToInt32(Console.ReadLine());

            K = N % 3;
            if (K == 0)
            {
                Console.WriteLine("Jebb");
            }
            else if (K != 0)
            {
                Console.WriteLine("Neibb");
            }

            Console.ReadKey();
        }
    }
}
