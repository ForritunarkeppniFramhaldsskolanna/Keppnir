using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isPrime = true;
            
            for (int i = 2; i <= 541; i++)
            {
                for (int N = 2; N <= 100; N++)
                {

                    if (i != N && i % N == 0)
                    {
                        isPrime = false;
                        break;
                    }

                }
                if (isPrime)
                {
                    Console.WriteLine(i);
                }
                isPrime = true;
            }
            Console.ReadKey();
        }
    }
}
