import sys
import itertools
import math

n = int(sys.stdin.readline().replace("\n", ""))

x = []
y = []

for k in range(0,n):
    inp = sys.stdin.readline().replace("\n", "").split(" ")
    x.append(int(inp[0]))
    y.append(int(inp[1]))

if sum(abs(i) for i in x) == 0:
    y.append(0)
    print(2 * (max(y) - min(y)))

else:
    length = 10**30

    for l in list(itertools.permutations(list(range(0, n)))):
        templength = 0
        
        last_x = 0
        last_y = 0

        for p in l:
            templength += math.sqrt((x[p] - last_x)**2 + (y[p] - last_y)**2)

            last_x = x[p]
            last_y = y[p]

        templength += math.sqrt((0 - last_x)**2 + (0 - last_y)**2)

        if templength < length:
            length = templength

    print(length)
