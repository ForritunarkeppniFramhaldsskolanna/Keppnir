import sys

n = int(sys.stdin.readline().replace("\n", ""))

s = []

for x in range(0,n):
    temp = sys.stdin.readline().replace("\n", "").split(" ")

    if temp[0] == "R":
        s.remove(int(temp[1]))

    elif temp[0] == "A":
        s.append(int(temp[1]))

    if len(s) == 0:
        print("-1 -1 -1")

    else:
        print(str(max(s)) + " " + str(min(s)) + " " + str(sum(s) / float(len(s))))
