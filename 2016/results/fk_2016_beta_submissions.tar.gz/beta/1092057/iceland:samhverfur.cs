using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritun
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i < 101; i++)
            {
                Console.WriteLine(pal(i));
            }
            Console.ReadKey();
        }
        public static string pal(int num)
        {
            string biggest = null;
            for (int i = (int)Math.Sqrt(PowerOfTwo(num)); i <= PowerOfTwo(num); i++)
                if (IsPalindrome(i.ToString()))
                    biggest = i.ToString();
            return biggest;
        }
        static int PowerOfTwo(int power)
        {
            return 1 << power;
        }
        public static bool IsPalindrome(string s)
        {
            return s == new string(s.Reverse().ToArray());
        }
    }
}
