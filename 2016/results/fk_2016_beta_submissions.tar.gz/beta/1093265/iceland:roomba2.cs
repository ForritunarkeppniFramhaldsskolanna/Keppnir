using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tokens = Console.ReadLine().Split();
            int a = int.Parse(tokens[0]);
            int b = int.Parse(tokens[1]);
            int j = 0;
            int i = 0;
            bool back = false;
            bool down = false;
            bool final = false;
            if (a == 1 && b == 1)
            {
                
            }
            if (b == 1)
            {
                for (int k = 0; k < a; )
                {
                    if (down == false && k != a)
                    {
                        Console.WriteLine(k + " " + j);
                        k++;

                    }
                    if (down == true)
                    {
                        if (k != 0)
                        {
                            k--;
                            Console.WriteLine(k + " " + j);

                        }
                    }
                    if (k == a)
                    {
                        down = true;
                        k--;
                    }
                }
            } 
            if (a == 1)
            {
                for (int k = 0; k < b;)
                {
                    if (down == false && k != b)
                    {
                        Console.WriteLine(i + " " + k);
                        k++;

                    }
                    if (down == true)
                    {
                        if (k != 0)
                        {
                            k--;
                            Console.WriteLine(i + " " + k);
                            
                        }
                    }
                    if (k ==b)
                    {
                        down = true;
                        k--;
                    }
                }
            }   
            if (a % 2 == 1 && b != 1)
            {
                do
                {
                    
                    if (back == true && down == false)
                    {
                        do
                        {
                        Console.WriteLine(i + " " + j);
                        i--;
                        if (i == 0)
                        {
                            back = false;
                            Console.WriteLine(i + " " + j);
                            j++;
                        }
                        } while (i != 0);
                    }

                    else if (i != a - 1 && down == false)
                    {
                        Console.WriteLine(i + " " + j);
                        i++;
                        back = false;
                        
                    }
                    if (i == a - 1 && j != b - 1 && back == false && down == false)
                    {
                        i--;
                        j++;
                        back = true;
                    }
                    if (j == b - 1 && down == false)
                    {
                        down = true;
                    }
                    if (down == true)
                    {

                        if (final == true)
                        {
                             i--;
                            if (i == 0)
                            {
                                // do nothing
                            }
                            else
                            {
                                i--;
                                Console.WriteLine(i + " " + j);
                            }
                            
                            
                            
                        }
                        if (i != a && final == false)
                        {
                            Console.WriteLine(i + " " + j);
                            i++;   
                        }
                        if (i == a && j != 0)
                        {
                            j--;
                            Console.WriteLine(i-1 + " " + j);
                            
                        }
                        if (j == 0)
                        {
                            final = true;
                        }
                    }
                } while (i != 0 || j != 0 && down == false);
            }
            if (a % 2 == 0 && b != 1 && down == false)
            {


                do
                {
                    if (down == true)
                    {
                        Console.WriteLine(i + " " + j);
                        i--;
                    }
                    if (back == true && down != true)
                    {
                        j--;
                    }
                     if (i != a && j != b && down != true)
                    {
                        Console.WriteLine(i + " " + j);
                    }
                     
                    if (j != b && back != true & down != true )
                     {
                         j++;
                     } 
                    if (j == 1 && down != true)
                    {
                        back = false;
                    }

                    if (j == 1 && down == false && i != 0)
                    {
                        i++;
                    }
                     if (j == b && down != true)
                    {
                        i++;
                        back = true;

                    }
                     if (i >= a - 1 && j == 2)
                     {
                         j--;
                         Console.WriteLine(i + " " + j);
                         down = true;
                         j--;
                     }
                } while (i != 0 || j != 0);
            }
            Console.WriteLine(i + " " + j);
            Console.ReadKey();
        }   
    }
}
