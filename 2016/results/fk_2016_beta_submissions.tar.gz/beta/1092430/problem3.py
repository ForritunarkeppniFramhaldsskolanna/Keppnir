import sys

n = int(sys.stdin.readline().replace("\n", ""))

s = []

for x in range(0,n):
    temp = sys.stdin.readline().replace("\n", "").split(" ")

    if x==0:
        hasta = int(temp[1])
        minnsta = int(temp[1])
        summa = 0

    if temp[0] == "R":
        s.remove(int(temp[1]))

        summa = summa - int(temp[1])
        
        if hasta < int(temp[1]) and len(s) != 0:
            hasta = max(s)

        elif len(s) == 0:
            hasta = 0

        if minnsta > int(temp[1]) and len(s) != 0:
            minnsta = min(s)

        elif len(s) == 0:
            minnsta = 10**10


    elif temp[0] == "A":
        s.append(int(temp[1]))

        summa = summa + int(temp[1])
        
        if hasta < int(temp[1]):
            hasta = int(temp[1])
        
        if minnsta > int(temp[1]):
            minnsta = int(temp[1])

    if len(s) == 0:
        print("-1 -1 -1")

    else:
        print(str(minnsta) + " " + str(hasta) + " " + str(summa / len(s)) + "00000")
