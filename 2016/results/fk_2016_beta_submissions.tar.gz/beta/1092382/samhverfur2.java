public class samhverfur2{
  public static void main(String[] args){
    for (int k = 1;k<38;k++){
      
      long big = (long)Math.pow(2,k);
      
      //String talan = ""+big;
      //System.out.println(talan);
      //BigInteger m = new BigInteger(""+1);
      //BigInteger curr = new BigInteger(""+big);
      //System.out.println(curr.bitCount());
      while (true){
        big--;
        String currS = ""+big;
        //System.out.println(curr);
        String rev = ""; 
        for (long i = currS.length()-1;i>-1;i--){
          rev = rev+currS.charAt((int)i);
        }
        if (currS.equals(rev)){
          System.out.println(k+" "+rev);
          break;
        }
        if (big==0)
          break;
      }
      
      
    }
    
    
  }
}