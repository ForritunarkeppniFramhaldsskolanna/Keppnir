import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * @author Alexander
 * @version 1.0
 */

public class Backspace {

	public static void main(String[] args) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s = br.readLine();
			String out = "";
			for(int i = 0; i < s.length(); i++) {
				char letter = s.charAt(i);
				if(letter == '<') {
					out = out.substring(0, out.length() - 1);
				} else {
					out += letter;
				}
			}
			System.out.println(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
