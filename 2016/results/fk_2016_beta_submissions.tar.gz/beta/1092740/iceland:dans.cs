using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ');
            int peopleCount = Convert.ToInt32(input[0]);
            int iterations = Convert.ToInt32(input[1]);
            string[] transformString = Console.ReadLine().Split(' ');
            int[] transform = new int[transformString.Length];
            int[] people = new int[peopleCount];

            for (int i = 0; i < transformString.Length; i++)
            {
                int tempTransform = Convert.ToInt32(transformString[i]);

                transform[tempTransform - 1] = i + 1;
            }

            for (int i = 0; i < peopleCount; i++)
            {
                people[i] = i + 1;
            }

            for (int i = 0; i < iterations; i++)
            {
                int[] transformCopy = new int[transform.Length];
                Array.Copy(transform, transformCopy, transform.Length);
                Array.Sort(transformCopy, people);
            }

            string output = "";

            for (int i = 0; i < people.Length; i++)
            {
                output += people[i] + " ";
            }

            output.Remove(output.Length - 1);

            Console.WriteLine(output);

            Console.ReadKey();
        }
    }
}
