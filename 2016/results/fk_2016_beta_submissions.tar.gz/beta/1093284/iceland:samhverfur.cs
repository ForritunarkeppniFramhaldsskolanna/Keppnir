using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 1; i <= 60; i++)
            {
                for (long j = Convert.ToInt64(Math.Pow(2, i)); j > 0; j--)
                {
                    float a = (float)j;
                    if (a.ToString() == ReverseString(a.ToString()))
                    {
                        Console.WriteLine(i + " " + a);
                        break;
                    }
                }
            }
            Console.ReadKey();
        }
        static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}