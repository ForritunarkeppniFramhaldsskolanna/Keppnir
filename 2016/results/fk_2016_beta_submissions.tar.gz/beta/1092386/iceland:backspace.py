import re

s = input()
backspaces = s.count("<")
for i in range(backspaces):
    s = re.sub(r'[a-z][<]{1}', '', s)
s = s.split("<")
string = ""
for a in s:
    string += a
print(string)