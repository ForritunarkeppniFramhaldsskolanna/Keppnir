n = int(raw_input())
r = []
s = {}
for i in range(0, n):
    r.append(raw_input().split())

for i in range(0, n):
    c = r[i][0]
    if c == "INNTAK":
        v = False
        if r[i][2] == "SATT":
            v = True
        s[r[i][1]] = v
    elif c == "UTTAK":
        n = r[i][1]
        if(s[n]):
            print "{0} SATT".format(n)
        else:
            print "{0} OSATT".format(n)
    elif c == "OG":
        n = r[i][3]
        i1 = r[i][2]
        i2 = r[i][1]
        if(s[i1] and s[i2]):
            s[n] = True
        else:
            s[n] = False
    elif c == "EDA":
        n = r[i][3]
        i1 = r[i][2]
        i2 = r[i][1]
        if(s[i1] or s[i2]):
            s[n] = True
        else:
            s[n] = False
    elif c == "EKKI":
        n = r[i][2]
        b = s[r[i][1]]
        s[n] = not b
