#include <iostream>
#include <algorithm>

using namespace std;

const int Capacity = 5000;

int main() {
	char arr[Capacity] = { 0 };

	cin >> arr;
	int count = 0;
	char *tmp_arr = new char[Capacity];
    for(int i = 0; i < Capacity; i++)
    {
        if(arr[i] == '<')
        {
            // do nothing
        }
        else if(arr[i+1] == '<')
        {
            //do nothing
        }
        else
        {
            tmp_arr[count] = arr[i];
            count++;
        }

        if(arr[i] == ' ' && arr[i+1] == ' ' && arr[i+2] == ' ')
        {

            for(int k = 0; k < Capacity; k++)
            {
                tmp_arr[i] = arr[i];
            }
        }
    }
    for(int i = 0; i < count; i++)
    {
        cout << tmp_arr[i];
    }

	return 0;
}
