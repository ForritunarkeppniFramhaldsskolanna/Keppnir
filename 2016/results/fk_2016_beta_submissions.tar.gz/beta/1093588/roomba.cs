using System;
class roomba{
	static void Main(){
		string input = Console.ReadLine();
		string[] inputArray = input.Split(' ');
		long x = Convert.ToInt64(inputArray[0]);
		long y = Convert.ToInt64(inputArray[1]);
		Hnit[] hnit = new Hnit[x*y];
		Hnit coOrd = new Hnit(1,0)
		Console.WriteLine("0 0");
		while(coOrd.x*coOrd.y != 0){
			if(co)
		}
	}
}
class Hnit{
	int x,y;
	Hnit(int a,int b){
		x = a;
		y = b;
	}
}