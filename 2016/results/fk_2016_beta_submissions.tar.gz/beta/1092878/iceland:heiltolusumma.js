using System;
using System.Linq;

namespace SumAndAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            long input = Convert.ToInt64(Console.ReadLine());
            long sum = 0;
            if (sum > 0)
            {
                for (int i = 0; i <= input; i++)
                {
                    sum += i;
                }
            }
            else if (sum < 0)
            {
                for (long i = input; i <= 1; i++)
                {
                    sum += i;
                }
            }
            else
            {
                sum = 1;
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}