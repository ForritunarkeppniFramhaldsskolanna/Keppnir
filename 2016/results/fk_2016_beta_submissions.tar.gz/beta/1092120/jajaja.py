Q = int(input(""))
x = 0;
aldur = []
for x in range(0,Q):
    var = input("")
    if var[0] == "A":
        var = int(var[1:])
        aldur.insert(x, var)
        minnst = min(aldur)
        elst = max(aldur)
        avg = float(sum(aldur)/len(aldur))
        print (minnst , elst , avg)
    elif var[0] == "R":
            var = int(var[1:])
            aldur.remove( var)
            if(len(aldur) == 0):
                print ("-1 , -1 , -1")
            else:
                minnst = min(aldur)
                elst = max(aldur)
                avg = float(sum(aldur)/len(aldur))
                print (minnst , elst , avg)
    else:
        print("Skrifa R eða A")
        x = x - 1;
