using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inp = Console.ReadLine().Split(' ');
            int y = Convert.ToInt32(inp[0]);
            int z = Convert.ToInt32(inp[1]);
            int stepDown = y - 1;

            List<string> framm = new List<string>();
            List<string> aftur = new List<string>();
            for (int i = 0; i < z - 1; i++)
            {
                framm.Add(Convert.ToString(i + 1));
            }
            
            for (int i = 0; i < y; i++)
            {
                Console.WriteLine(i.ToString() + " " + "0");
            }


            for (int i = 1; i < y; i++)
            {
                foreach (string item in framm)
                {
                    Console.WriteLine(Convert.ToString(stepDown) + " " + item);
                }
                framm.Reverse();
                stepDown = stepDown - 1;
            //    Console.WriteLine("y is " + stepDown.ToString());
                
            }
            foreach (string item in framm)
            {
                Console.WriteLine(Convert.ToString(stepDown) + " " + item);
            }
            Console.WriteLine("0 0");
            //Console.ReadLine();
            
        }
    }
}
