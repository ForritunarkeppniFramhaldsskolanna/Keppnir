using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tokens = Console.ReadLine().Split();
            int a = int.Parse(tokens[0]);
            int b = int.Parse(tokens[1]);
            int j = 0;
            int i = 0;
            bool back = false;
            bool down = false;
            if (a % 2 == 0 && b != 1)
            {


                do
                {
                    if (down == true)
                    {
                        Console.WriteLine(i + " " + j);
                        i--;
                    }
                    if (back == true && down != true)
                    {
                        j--;
                    }
                     if (i != a && j != b && down != true)
                    {
                        Console.WriteLine(i + " " + j);
                    }
                     
                    if (j != b && back != true & down != true )
                     {
                         j++;
                     } 
                    if (j == 1 && down != true)
                    {
                        back = false;
                    }

                    if (j == 1 && down == false && i != 0)
                    {
                        i++;
                    }
                     if (j == b && down != true)
                    {
                        i++;
                        back = true;

                    }
                     if (i >= a - 1 && j == 2)
                     {
                         j--;
                         Console.WriteLine(i + " " + j);
                         down = true;
                         j--;
                     }
                } while (i != 0 || j != 0);
            }
            Console.WriteLine(i + " " + j);
            Console.ReadKey();
        }   
    }
}
