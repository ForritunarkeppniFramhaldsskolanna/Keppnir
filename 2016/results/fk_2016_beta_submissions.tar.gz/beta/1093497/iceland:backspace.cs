using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace dæmi1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = ReadLine();
            string newstring = null;

            foreach (char c in input)
            {
                if (c != '<')
                {
                    newstring += c;
                }
                else
                {
                    if (newstring.Length == 0)
                    {
                    }
                    else
                    {
                        newstring = newstring.Substring(0, newstring.Length - 1);
                    }
                }
            }
            Console.WriteLine(newstring);
            Console.ReadKey();
        }
        private static string ReadLine()
        {
            Stream inputStream = Console.OpenStandardInput(1000001);
            byte[] bytes = new byte[1000001];
            int outputLength = inputStream.Read(bytes, 0, 1000001);
            //Console.WriteLine(outputLength);
            char[] chars = Encoding.UTF7.GetChars(bytes, 0, outputLength);
            return new string(chars);
        }
    }
}
