#include <iostream>
using namespace std;
int main() {
	long long n;
	cin >> n;
	long long su = 0;
	if (n < 0) {
		su = 0;
	} else {
		if (n >  500000000){
			su = 125000000250000000
			for (long long i = 500000001; i < n+1; ++i)
			{
				su += i;
			}
		}
		else if (n > 100000000)
		{
			su = 5000000050000000;
			for (long long i = 100000001; i < n+1; ++i)
			{
				su += i;
			}
		} else {
			for (long long i = 0; i < n+1; ++i)
			{
				su += i;
			}
		}
	}
	cout << su << endl;
}