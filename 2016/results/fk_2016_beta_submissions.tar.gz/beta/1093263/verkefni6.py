tala = input()
summa = 0
for x in range(tala):
    summa += x
if tala > 0:
    print(summa)
else:
    print(0)