using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_A_Backspace
{
    class Program
    {
        static void Main(string[] args)
        {


            

            String value = Console.ReadLine();
            string[] a = value.Select(c => c.ToString()).ToArray();
            for (int i = 0; i < a.Length; i++)
            {
                if (i > 0 && a[i] == "<")
                {
                    a[i] = null;
                    a[i - 1] = null;
                }
            }
            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
            }



            /*string nyjastreng = null;
            String[] substrings = value.Split(delimiter);
            foreach (var info in substrings)
            {

                Console.WriteLine(info);




            }*/







        }
    }
}