def main():
    import sys
    string = ""
    for line in sys.stdin:
        line = line.strip()
        for letter in line:
            if letter == "<":
                string = string[:-1]
            else:
                string += letter
    print(string)


main()