n = int(input())
if n < -1:
    s = 0
    n = abs(n)
    summa = (n * (n + 1)) // 2
    print(-1 * summa + 1)
else:
    summa = (n * (n + 1)) // 2
    print(summa)
