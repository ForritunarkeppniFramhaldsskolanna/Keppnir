<?php

fscanf(STDIN, '%d', $number);
$count = 0;

while ($number > $count) {
  fscanf(STDIN, '%s', $value[$count]);
  $count++;
}

fscanf(STDIN, '%d', $numberleit);
$count2 = 0;

while ($numberleit > $count2) {
  fscanf(STDIN, '%s', $value2[$count2]);
  $count2++;
}

foreach ($value2 as $gildi2) {
  $teljari2 = 0;
    $lengd = strlen($gildi2);
    $tala = $gildi2;

    foreach ($value as $gildi) {
      $cuttad = substr($gildi, 0, $lengd);
      // echo $cuttad . "." $gildi2;
      if ($cuttad == $tala) {
        $teljari2++;
      }

    }
    fprintf(STDOUT, "%d\n", $teljari2);
}

?>
