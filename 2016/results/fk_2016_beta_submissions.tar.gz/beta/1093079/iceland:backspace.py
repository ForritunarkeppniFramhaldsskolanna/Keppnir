N = str(input())

def checkLine(line):
	if '<' not in line:
		return line
	elif '<' in line:
		newLine = ''
		for char in range(0,len(line),1):
			if line[char] != '<':
				newLine += line[char]
			elif line[char] == '<':
				newLine = newLine[:-1] 
				continue
		return(newLine)
print(checkLine(N))

		