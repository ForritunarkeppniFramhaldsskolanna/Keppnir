import sys

n = int(sys.stdin.readline().replace("\n", ""))

numer = []

for i in range(0, n):
    temp = int(sys.stdin.readline().replace("\n", ""))

    numer.append(temp)

q = int(sys.stdin.readline().replace("\n", ""))

rett = [0] * q

for i in range(0, q):
    gisk = sys.stdin.readline().replace("\n", "")


    if n <= 100 and q <= 100:
        for k in range(0, n):
            if str(numer[k])[:len(gisk)] == gisk:
                rett[i] += 1
    
    else:
        for k in range(0, n):
            if (numer[k] - int(gisk) * 10000) < 10000:
                rett[i] += 1

for i in range(0, len(rett)):
    print(rett[i])
