import java.util.Scanner;

public class Turing
{
  public static void main(String[] args)
  {
    
    Scanner scan = new Scanner(System.in);
    
    int n = scan.nextInt();
    
    int numbers[] = new int[n];
    
    for (int i= 0; i < n; i++)
    { 
      numbers[i] = scan.nextInt();
    }
    
    int max = 0;
    
    for (int i = 0; i < n; i++)
    {
      for (int k = 0; k < i; k++)
      {
        int null_oftar_en_einn = oft(numbers, 0, k, i) - oft(numbers, 1, k, i);
        if (null_oftar_en_einn > max)
        {
          max = null_oftar_en_einn;
        }
      }
    }
    
    if (n == 1 && numbers[0] == 0) {System.out.println(1);}
    //else {System.out.println(max);}
    
    
    int fjoldi_asa = oft(numbers, 1, 0, n-1);
    
    
   
    System.out.println(fjoldi_asa+max);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    scan.close();
    
  }
  
  
  
  
  public static int oft(int[] x, int a, int b, int c)
  {
    int summa = 0; 
    
    for (int i = 0; i < (c-b+1); i++)
    {
      if (x[b+i] == a) {summa++;}
    } 
    
    return summa;
    
    
  }      
  
  
  
}