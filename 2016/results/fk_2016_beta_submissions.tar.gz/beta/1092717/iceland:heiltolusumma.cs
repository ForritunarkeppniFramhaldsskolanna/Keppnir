using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace heiltolusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            long inp = Convert.ToInt32(Console.ReadLine());
            int svar = 0;
            for (int i = 1; i < inp + 1; i++)
            {
                svar += i;
            }
            Console.WriteLine(svar);
            
        }
    }
}
