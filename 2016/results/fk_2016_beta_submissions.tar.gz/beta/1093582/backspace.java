import java.util.*;

public class backspace{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    String s = sc.nextLine();
    int len = s.length();
    boolean[] stafir = new boolean[len];
    int i = 0;
    while( i < len ){
      int j = 1;
      while( i+j-1 < len && s.charAt(i+j-1) == '<' ){
        stafir[i+j-1] = true;
        j++;
        if( i-j+1 >=0 )
          stafir[i-j+1] = true;
        else break;
      }
      i+=j;
    }
    for( int k = 0; k < len ; k++ ){
      if( !stafir[k] ) System.out.print(s.charAt(k));
    }
  }
}
