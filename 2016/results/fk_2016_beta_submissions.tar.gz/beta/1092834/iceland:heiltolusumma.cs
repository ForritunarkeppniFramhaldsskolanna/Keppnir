using System;
using System.Linq;

namespace SumAndAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            long input = Convert.ToInt64(Console.ReadLine());
            long sum = 0;
            for (int i = 0; i <= input; i++)
            {
                sum += i;
            }
            Console.WriteLine(sum);
        }
    }
}