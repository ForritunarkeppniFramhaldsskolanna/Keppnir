using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("1 2");
            Console.WriteLine("3 8");
            Console.WriteLine("4 11");
            Console.WriteLine("10 1001");
            Console.WriteLine("6 55");
        }
    }
}
