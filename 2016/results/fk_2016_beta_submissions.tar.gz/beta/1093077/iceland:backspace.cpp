#include <iostream>
#include <string>
using namespace std;
int main(){
	string inthing;
	cin >> inthing;
	for (long i = 0; i < inthing.length(); ++i)
	{
		if (inthing[i] == '<' && inthing[i +1] == '<')
		{
			inthing.erase(i -2, 4);
			i -= 4;
		}
		else if(inthing[i] == '<'){
			inthing.erase(i -1, 2);
			i -= 2;
		}
	}
	if (inthing.length() > 0)
	{
		cout << inthing << endl;
	}
}