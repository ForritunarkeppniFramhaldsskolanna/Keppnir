using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            int inputCount = int.Parse(Console.ReadLine());
            List<long> nums = new List<long>();

            for (int i = 0; i < inputCount; i++)
            {
                string[] input = Console.ReadLine().Split(' ');

                if (input[0][0] == 'A')
                    nums.Add(long.Parse(input[1]));
                else
                    nums.Remove(long.Parse(input[1]));

                Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
            }
        }
    }
}
