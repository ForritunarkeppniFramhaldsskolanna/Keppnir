N= int(input())

def gauss(num):
	sum = 0
	if num < 0:
		for x in range(-num,num,1):
			sum += x	
	elif num > 0:
		sum = num
		for x in range(0,num,1):
			sum += x
	return sum

print(gauss(N))