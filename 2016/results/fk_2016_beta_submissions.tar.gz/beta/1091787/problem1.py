import sys

inn = sys.stdin.readline().replace("\n", "")
ut = ""

pos = 0

for i in range(0, len(inn)):
    for j in range(0, len(inn)):
        if j >= len(inn):
            break
        elif j==0 and inn[j] == "<":
            inn = inn[1:]
            break
        elif inn[j] == "<":
            inn = inn[:(j-1)] + inn[(j+1):]
            break

    if i >= len(inn):
        break

print(inn)
