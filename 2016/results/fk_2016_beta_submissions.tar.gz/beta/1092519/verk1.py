#!/usr/bin/python
import math
var = input("")
backspace = "\b \b"
var = var.replace("<", backspace)
print(var)
