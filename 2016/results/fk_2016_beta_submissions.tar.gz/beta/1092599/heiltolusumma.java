import java.util.*;

public class heiltolusumma{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    int n = Integer.parseInt(sc.nextLine());
    long summa;
    if( n >= 1 ) summa = n*(n+1)/2;
    else{
      summa = (2-n)*(n + 1)/2;
    }
    System.out.println(summa);
  }
}
