#include <iostream>
using namespace std;
int main() {
	long long n;
	cin >> n;
	long long su = 0;
	if (n < 0) {
		su = 0
	} else {
		for (long long i = 0; i < n+1; ++i)
		{
			su += i;
		}
	}
	cout << su << endl;
}