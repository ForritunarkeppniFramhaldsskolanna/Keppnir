using System;
class verkefni1{
	static void Main(){
		string input = Console.ReadLine();
		string output = null;
		for(int i = 0; i<input.Length; i++){
			if(input[i].Equals('<') == false){
				output += input[i]; 
			}
			if(input[i].Equals('<')&&output != null){
				output = output.Remove(output.Length-1);
			}
		}
		Console.WriteLine(output);
	}
}