using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("1 2");
            Console.WriteLine("2 4");
            Console.WriteLine("3 8");
            Console.WriteLine("4 11");
            Console.WriteLine("5 22");
            Console.WriteLine("6 55");
            Console.WriteLine("7 121");
            Console.WriteLine("8 252");
            Console.WriteLine("9 505");
            Console.WriteLine("10 1001");
            Console.WriteLine("11 2002");
            Console.WriteLine("12 4004");
            Console.WriteLine("13 8118");
            Console.WriteLine("14 16361");
            Console.WriteLine("15 32723");
            Console.WriteLine("16 65456");
            Console.WriteLine("17 130031");
            Console.WriteLine("18 261162");
            Console.WriteLine("19 523325");
            Console.WriteLine("20 1048401");
            Console.WriteLine("21 2096902");
            Console.WriteLine("22 4193914");
            Console.WriteLine("23 8387838");
            Console.WriteLine("24 16766761");
            Console.WriteLine("25 33544533");
            Console.WriteLine("26 67100176");
            Console.WriteLine("27 134212431");
            Console.WriteLine("28 268434862");
            Console.WriteLine("29 536868635");
            Console.WriteLine("30 1073663701");
            Console.WriteLine("31 2147447412");
            Console.WriteLine("32 4294884924");
            Console.WriteLine("33 8589889858");
            Console.WriteLine("34 17179797171");
            Console.WriteLine("35 34359695343");
            Console.WriteLine("36 68719391786");
            Console.WriteLine("37 137438834731");
            Console.WriteLine("38 274877778472");
            Console.WriteLine("39 549755557945");
            Console.WriteLine("40 1099511159901");
            Console.WriteLine("41 2199023209912");
            Console.WriteLine("42 4398046408934");
            Console.WriteLine("43 8796092906978");
            Console.WriteLine("44 17592177129571");
            Console.WriteLine("45 35184366348153");
            Console.WriteLine("46 70368733786307");
            Console.WriteLine("47 140737484737041");
            Console.WriteLine("48 281474969474182");
            Console.WriteLine("49 562949949949265");
            Console.WriteLine("50 1125899889985211");
            Console.WriteLine("51 2251799779971522");
            Console.WriteLine("52 4503599559953054");
            Console.WriteLine("53 9007199229917009");
            Console.WriteLine("54 18014398489341081");
            Console.WriteLine("55 36028796969782063");
            Console.WriteLine("56 72057593939575027");
            Console.WriteLine("57 144115187781511441");
            Console.WriteLine("58 288230375573032882");
            Console.WriteLine("59 576460752257064675");
            Console.WriteLine("60 1152921504051292511");
            Console.WriteLine("61 2305843009003485032");
            Console.WriteLine("62 4611686018106861164");
        }
    }
}