import java.util.*;

public class roknet1
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    int N = Integer.parseInt(sc.nextLine());
    String inntak = "INNTAK";
    String uttak = "UTTAK";
    String satt = "SATT";
    String osatt = "OSATT";
    String og = "OG";
    String eda = "EDA";
    String ekki = "EKKI";
    boolean sanngildi = true;
    String[] hlutur1 = new String[N];
    String[] hlutur2 = new String[N];
    for(int i=0;i<N;i++)
    {
      String inntaks = sc.nextLine();
      String[] splittari = inntaks.split(" ");
      if(splittari[0].equals(inntaks))
      {
        hlutur1[i] = splittari[1];
        hlutur2[i] = splittari[2];
      }
      else if(splittari[0].equals(uttak))
      {
        for(int j=0;j<N;j++)
        {
          if(splittari[1] == hlutur1[j])
          {
            System.out.println(splittari[1] + " " + hlutur2[j]);
          }
        }
      }
    }
  }
}