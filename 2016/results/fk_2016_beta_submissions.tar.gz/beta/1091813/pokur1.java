import java.util.Scanner;

public class pokur1
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    int n = scan.nextInt();
    int numbers[] = new int[n];
    int x;
    int max = 0;
    int min = 0;
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
      x = scan.nextInt();
      numbers[i] = x;
     
      if (i == 0)
       {min = numbers[i];
        max = numbers[i];}
      
    
    
    
    
    }
    
    for (int i = 0; i < n; i++)
    { if (numbers[i] < min) {min = numbers[i];}
      if (numbers[i] > max) {max = numbers[i];}
      
    }
    
    for (int i = 0; i < n; i++)
    { sum += numbers[i];
      
     
    }
    
    double medaltal = sum / (n + 0.0);
    
    System.out.println(min);
    System.out.println(max);
    System.out.println(medaltal);
    
    scan.close();
  }
}