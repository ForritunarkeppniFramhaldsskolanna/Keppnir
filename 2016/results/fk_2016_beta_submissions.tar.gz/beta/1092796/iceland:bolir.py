fjoldi = input()
bolir = []
bolastaerd = []
checker = 0
for x in range(0, fjoldi):
    bolir.append(map(int, raw_input().split(" ")))
bolastaerd = map(int, raw_input().split(" "))
for y in range(0, fjoldi):
    for i in range(0, len(bolastaerd)):
       if bolir[y][0] <= bolastaerd[i] <= bolir[y][1]:

           checker += 1
           bolastaerd.remove(bolastaerd[i])
           break
print checker
if checker == fjoldi:
    print "Jebb"
else:
    print "Neibb"