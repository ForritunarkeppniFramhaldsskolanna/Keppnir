line = input()
newline = ""
for x in range(len(line)):
	if line[x] != '<':
		newline += line[x]
	else:
		newline = newline[:-1]
print(newline)