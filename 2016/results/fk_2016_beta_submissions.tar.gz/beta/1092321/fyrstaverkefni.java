import java.util.*;

public class fyrstaverkefni
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    String radirs = sc.nextLine();
    int radir = Integer.parseInt(radirs);
    String dalkars = sc.nextLine();
    int dalkar = Integer.parseInt(dalkars);
    boolean radirslett = false;
    boolean dalkarslett = false;
    boolean slett = true;
    if((dalkar%2) == 0)
      dalkarslett = true;
    if((radir%2) == 0)
      radirslett = true;
    int k=0;
    int[][] stadsetning = new int[radir][dalkar];
    System.out.println(0 + " " + 0);
    if(radirslett)
    {
      while(k<radir)
      {
        if(slett)
        {
          for(int j=1; j<dalkar;j++)
          {
            System.out.println(j + " " + k);
          }
          slett = false;
          k++;
        }
        else if(slett != true)
        {
          for(int j=1;j<dalkar;j++)
          {
            System.out.println((dalkar-j) + " " + k);
          }
          slett = true;
          k++;
        }
      }
      for(int i=1;i<(radir+1);i++)
      {
        System.out.println(0 + " " + (radir-i));
      }
    }
    else if(radirslett != true && dalkarslett == true)
    {
      while(k<dalkar)
      {
        if(slett)
        {
          for(int j=1; j<radir;j++)
          {
            System.out.println(j + " " + k);
          }
          slett = false;
          k++;
        }
        else if(slett != true)
        {
          for(int j=1;j<radir;j++)
          {
            System.out.println((radir-j) + " " + k);
          }
          slett = true;
          k++;
        }
      }
      for(int i=1;i<(dalkar+1);i++)
      {
        System.out.println(0 + " " + (dalkar-i));
      }
    }
    else
    {
      for(int i=1;i<radir;i++)
      {
        System.out.println(0 + " " + i);
      }
      while(k<(radir-2))
      {
        if(slett == true)
        {
          for(int j=1; j<dalkar;j++)
          {
            System.out.println(j + " " + (radir-(k+1)));
          }
          slett = false;
          k++;
        }
        else if(slett != true)
        {
          for(int j=1;j<dalkar;j++)
          {
            System.out.println((dalkar-j) + " " + (radir-(k+1)));
          }
          slett = true;
          k++;
        }
      }
      int a = 0;
      for(int j = 0; j < dalkar; j++)
      {
        int nuverandidalkur = dalkar - j - 1;
        if(j%2 == 0)
        {
          System.out.println((nuverandidalkur) + " " + 1);
          System.out.println((nuverandidalkur) + " " + 0);
        }
        else
        {
          System.out.println((nuverandidalkur) + " " + 0);
          System.out.println((nuverandidalkur) + " " + 1);
        }
      }
      /*boolean skipta = true;
      if(skipta)
      {
      for(int j=1;j<(dalkar+1);j++)
      {
        System.out.println((dalkar-j) + " " + 1);
        System.out.println((dalkar-j) + " " + 0);
      }
      skipta = false;
      }
      else if(skipta == false)
      {
        for(int j=1;j<(dalkar+1);j++)
        {
        System.out.println((dalkar-j) + " " + 0);
        System.out.println((dalkar-j) + " " + 1);
        }
        skipta = true;
      }*/
    }
  }
}
