using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Símanúmer
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldi = Convert.ToInt32(Console.ReadLine());
            List<int> list = new List<int>();
            string numer;
            int counter = 0;
            for (int i = 0; i < fjoldi; i++)
            {
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }
            int fjoldiÞrenna = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < fjoldiÞrenna; i++)
            {
                counter = 0;
                string þrenna = Console.ReadLine();
                foreach (int item in list)
                {
                    numer = item.ToString();
                    if (þrenna == numer.Remove(þrenna.Length, 7-þrenna.Length))
                    {
                        counter++;
                    }
                }
                Console.WriteLine(counter);
                Console.ReadKey();
            }
        }
    }
}
