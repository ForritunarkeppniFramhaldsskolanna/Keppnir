using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tala = Convert.ToInt32(Console.ReadLine());
            int svar = 0;
            for (int i = 1; i <= tala; i++)
            {
                svar = svar + i;
                Console.Write(i + " + ");
            }
            Console.WriteLine(" = " + svar);
            Console.ReadLine();
        }
    }
}