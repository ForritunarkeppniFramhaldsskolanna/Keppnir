import sys

n = int(sys.stdin.readline().replace("\n", ""))

x = []
y = []

for k in range(0,n):
    inp = sys.stdin.readline().replace("\n", "").split(" ")
    x.append(int(inp[0]))
    y.append(int(inp[1]))

if sum(abs(i) for i in x) == 0:
    print(2 * (max(y) - min(y)))

