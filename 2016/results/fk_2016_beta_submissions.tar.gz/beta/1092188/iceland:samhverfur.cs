using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 100; i++)
            {
                for (double j = Math.Pow(2, i); j > 0; j--)
                {
                    if (j.ToString() == ReverseString(j.ToString()))
                    {
                        Console.WriteLine(i + " " + j);
                        break;
                    }
                }
            }
            Console.ReadKey();
        }
        static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
