import java.util.*;
public class drone{
  public static void main(String[] args){
    Scanner scan = new Scanner(System.in);
    long fjoldi = scan.nextLong();
    int[][] loc = new int[(int)fjoldi][2];
    for (int i = 0;i<fjoldi;i++){
      loc[i][0] = scan.nextInt();
      loc[i][1] = scan.nextInt();
    }
    scan.close();
    double[][] dis = new double[(int)fjoldi][(int)fjoldi];
    for (int i = 0;i<fjoldi;i++){
      for (int j = 0;j<fjoldi;j++){
        if (i!=j)
          dis[i][j]=  dist(loc[i][0],loc[i][1],loc[j][0],loc[j][1]);
      }
    }
    Arrays.sort(dis);
    double sum = 0;
    for (int i = 0;i<fjoldi;i++){
      for (int j = 0;j<fjoldi;j++){
        sum += dis[i][1];
      }
    }
  }
  public static double dist(int x1, int y1,int x2, int y2){
    double dist = Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
    return dist;
  }
}