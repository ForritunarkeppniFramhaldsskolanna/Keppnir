var = input("")
a = [];
talann = 0;
count = 0;
if var[0] == "-":
    print("0");
else:
    tala = int(var)
    for x in range(1,tala+1):
        talann = talann + x;
    for x in range(0,talann+1):
        if(x % 2 == 0):
            a.insert(count,x)
            count = count + 1
        else:
            pass
    print(max(a))
