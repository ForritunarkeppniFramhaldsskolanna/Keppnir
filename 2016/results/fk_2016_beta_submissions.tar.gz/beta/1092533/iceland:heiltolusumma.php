<?php

fscanf(STDIN, '%d', $tala);

$count = $tala;

while ($tala > 0) {
  $heild = $tala;
  $heild = $heild + $tala - 1;
  $tala--;
}

fprintf(STDOUT, "%d", $heild);

?>
