import sys

N = int(sys.stdin.readline())

bitString = sys.stdin.readline()
bitString = bitString.split()

bestOutcome = -100

for i in range(0,N):
    for j in range(i + 1, N + 1):
        tempOutcome = bitString[i:j].count("0") - bitString[i:j].count("1")
        if tempOutcome > bestOutcome:
            bestOutcome = tempOutcome

print(bestOutcome + bitString.count("1"))