import itertools

from math import *
# Traveling salesman
locations = []
n = int(input())
for i in range(n):
    locations.append(input().split())
poss= []
currentLocation = [0, 0]
allLocations = []
allLocations = list(itertools.permutations(locations))

for locations in allLocations:
    locations = list(locations)
    locations.append(tuple([0, 0]))
    distance = 0
    for point in locations:
        xcoords = int(point[0])
        ycoords = int(point[1])
        diffx = 0
        diffy = 0
        #input()
        #print("{} {}".format(currentLocation[0], currentLocation[1]))
        #print("{} {}".format(xcoords, ycoords))
        if xcoords == currentLocation[0] and ycoords == currentLocation[1]:
            #No change
            #print("No change")
            continue
        elif xcoords == currentLocation[0]:
            #print("Y change")
            #Only y changed
            distance += abs(currentLocation[1] - ycoords)
            #print(distance)
        elif ycoords == currentLocation[1]:
            #print("X change")
            #Only x changed
            distance += abs(currentLocation[0] - xcoords)
            #print(distance)
        else:
            #print("Both changed")
            #Both changed, distance is c
            diffx = abs(currentLocation[0] - xcoords)
            diffy = abs(currentLocation[1] - ycoords)
            distance += sqrt(diffx ** 2 + diffy ** 2)
            #print(distance)
        currentLocation = [xcoords, ycoords]
    else:
        poss.append(distance)
print(min(poss))
