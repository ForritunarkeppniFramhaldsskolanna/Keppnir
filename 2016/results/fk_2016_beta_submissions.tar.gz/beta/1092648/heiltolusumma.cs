using System;
class Heiltolusumma{
	static void Main(){
		long input = Convert.ToInt64(Console.ReadLine());
		long output = 0;
		/*for(int i = 0; i<input.Length; i++){
			 inputArray[i] = input[i];
			 Console.WriteLine(input[i])
		}*/
		for(int I = 0; I<=input; I++){
			output += I;
		}
		Console.WriteLine(output);
	}
}