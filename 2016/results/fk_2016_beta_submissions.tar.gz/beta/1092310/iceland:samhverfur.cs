using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace symmetrical
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 100; i++)
            {
                double pow = Math.Pow(2,i);
                for (double j = pow; 0 < j; j--)
                {
                    string number = j.ToString();
                    string reversed = Reverse(number);
                    if (number == reversed)
                    {
                        Console.WriteLine(i + " " + number);
                        break;
                    }
                }
            }
            
        }
        public static string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
}
