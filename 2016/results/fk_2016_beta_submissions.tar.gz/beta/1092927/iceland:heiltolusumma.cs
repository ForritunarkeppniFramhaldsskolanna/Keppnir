using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heiltölusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            string tala = Console.ReadLine();
            double high = Convert.ToDouble(tala);
            int summa = 0;
            if(high > 0)
            {
                for (int i = 1; i <= high; i++)
                {
                    summa = summa + i;
                }
            }
            else
            {
                for (int i = 1; i >= high; i--)
                {
                    summa = summa + i;
                }
            }
            Console.WriteLine(summa);
            Console.ReadKey();
        }
    }
}
