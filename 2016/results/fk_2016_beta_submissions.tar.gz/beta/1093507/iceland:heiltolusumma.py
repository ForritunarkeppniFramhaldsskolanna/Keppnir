n = int(input())
if n < -1:
    s = 0
    for i in range(n, 2):
        s -= i
    print(s)
else:
    summa = (n * (n + 1)) // 2
    print(summa)
