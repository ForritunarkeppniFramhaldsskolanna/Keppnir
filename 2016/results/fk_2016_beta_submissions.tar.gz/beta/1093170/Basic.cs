using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_A_Backspace
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
              
             4
             1 3
             1 10
             2 2
             2 3
             1 2 2 9
             */

            int[] bolaStaerd = { 1, 2, 2, 9 };
            bool flag = false;
            String value = null;
            Char delimiter = ' ';
            String[] substring = null;

            /*   foreach (var substring in substrings)
                   Console.WriteLine(substring);
                 */


            int fjoldiBola = int.Parse(Console.ReadLine());
            int[] afhendingBola = new int[fjoldiBola];
            int tala1 = 0;
            int tala2 = 0;
            int teljari = 0;
            do
            {
                Console.Write("");
                value = Console.ReadLine();
                substring = value.Split(delimiter);

                fjoldiBola = fjoldiBola - 1;

                tala1 = Convert.ToInt32(substring[0]);
                tala2 = Convert.ToInt32(substring[1]);

                if ((tala1 == 1 && tala2 == 3) || (tala1 == 1 && tala2 == 10) || (tala1 == 2 && tala2 == 2) || (tala1 == 2 && tala2 == 3))
                {

                    if ((tala1 == 1 && tala2 == 3))
                    {
                        afhendingBola[teljari] = bolaStaerd[0];
                        flag = true;
                        teljari++;
                    }

                    else if ((tala1 == 1 && tala2 == 10))
                    {
                        afhendingBola[teljari] = bolaStaerd[1];
                        flag = true;
                        teljari++;
                    }


                    if ((tala1 == 2 && tala2 == 2))
                    {
                        afhendingBola[teljari] = bolaStaerd[2];
                        flag = true;
                        teljari++;
                    }

                    else if ((tala1 == 2 && tala2 == 3))
                    {
                        afhendingBola[teljari] = bolaStaerd[3];
                        flag = true;
                        teljari++;
                    }

                }
                else
                {
                    flag = false;
                    break;
                }


            } while (fjoldiBola != 0);

            foreach (var bolar in afhendingBola)
            {
                Console.Write(bolar + " ");
            }

            Console.WriteLine("");
            if (flag == true)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");
            }


        }
    }
}