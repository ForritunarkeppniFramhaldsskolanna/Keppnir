import java.util.Scanner;

public class Backspace
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    String texti = scan.nextLine();
    scan.close();
    int lengd = texti.length();
    String uttak = "";
    for(int i = 0; i<lengd;i++)
    {
      System.out.println(uttak);
      if(i == lengd-1 && texti.charAt(i) != '<')
      {
        uttak = uttak + texti.charAt(i);
        
      }
      else if (i == lengd-1 && texti.charAt(i) == '<')
      {
 
      }
     else if(texti.charAt(i+1) != '<' && texti.charAt(i) != '<')
      {
       uttak = uttak + texti.charAt(i); 

      }
      
      else if(texti.charAt(i) == '<')
      {
      
      }

    }
    System.out.println(uttak);
    
    
    
    
    
    
  }
}