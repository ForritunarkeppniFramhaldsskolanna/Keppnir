
var input = [];

var line;
while(line = readline()){
	input.push(line);
}

var bits = input[1].split(' ');
for (var i = 0; i < bits.length; i++) {
	bits[i] = parseInt(bits[i]);
}

var a, b;
var high = 0;

for (var i = 0; i < bits.length; i++) {
	var a = i;
	for (var x = i; x < bits.length; x++) {
		var b = x;

		var sum = flipBits(bits, a, b);
		if(sum > high){
			high = sum;
		}
	}
}

function flipBits(p_bits, a, b){
	var fBits = p_bits;
	for (var i = a; i <= b; i++) {
		fBits[i] = fBits[i] == 1 ? 0 : 1;
	}
	// return fBits;

	var sum = 0;
	for (var i = 0; i < fBits.length; i++) {
		sum += fBits[i];
	}
	return sum;
}

// console.log(flipBits(bits, 1, 5));

print(high)