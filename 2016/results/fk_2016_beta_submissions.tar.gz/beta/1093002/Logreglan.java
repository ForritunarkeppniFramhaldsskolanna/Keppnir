import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;

/**
 * @author Alexander
 * @version 1.0
 */

public class Logreglan {

	public static void main(String[] args) {
		/*
		 * 4 8245477 9917762 9871234 8247713 5 824 9 99177 8245477 565
		 **/
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			int amountOfNumbers = Integer.parseInt(br.readLine());
			int[] numbers = new int[amountOfNumbers];
			for (int i = 0; i < numbers.length; i++) {
				numbers[i] = Integer.parseInt(br.readLine());
			}

			int fjoldiVitna = Integer.parseInt(br.readLine());
			int[] vitni = new int[fjoldiVitna];
			boolean[] lygari = new boolean[fjoldiVitna];
			for (int i = 0; i < vitni.length; i++) {
				vitni[i] = Integer.parseInt(br.readLine());
				lygari[i] = true;
			}

			int[] out = new int[amountOfNumbers];
			for (int i = 0; i < out.length; i++) {
				out[i] = 0;
			}
			int numberOfLiars = 0;
			for (int i = 0; i < numbers.length; i++) {
				String s = numbers[i] + "";
				for (int j = 0; j < vitni.length; j++) {
					String s1 = vitni[j] + "";
					if (s.startsWith(s1)) {
						out[i]++;
						lygari[j] = false;
					}
				}
			}
			
			for (int i = 0; i < lygari.length; i++) {
				if(lygari[i]) {
					numberOfLiars++;
				}
			}
			
			for (int i = 0; i < out.length; i++) {
				System.out.println(out[i]);
			}
			for (int i = 0; i < numberOfLiars; i++) {
				System.out.println(0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
