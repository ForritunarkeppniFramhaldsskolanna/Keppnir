import java.io.*;
import java.util.Scanner;
public class tolfr{
  public static void main(String[] args){
    
    Scanner in = new Scanner(System.in);
    long q = in.nextLong();
    int[] hirdmenn = new int[(int)q];
    int amount=0;
    
    
    for(int i = 0;i<q;i++){
      char c = in.next().charAt(0);
      int a = in.nextInt();
      if(c =='A'){
        hirdmenn[i] = a;
        amount++;
      }
      else if(c =='R'){
        for(int j=0;j<hirdmenn.length;j++){
          if(hirdmenn[j]==a){
            hirdmenn[j]=0;
            break;
          }
        }
        if(amount>0){
          amount--;
        }
        
      }
      
      if(amount ==0){
        int minus = -1;
        System.out.println(minus +" "+minus+" "+minus);
      }
      else{
        int min = 999999999;
        int max= -999999999;
        double sum=0;
        int count =0;
        int[] newhirdmenn = new int[amount];
        
        for(int h=0;h<hirdmenn.length;h++){
          if(hirdmenn[h]!=0){
            newhirdmenn[count] = hirdmenn[h];
            count++;
          }
        }
        
       /*
        for(int h=0;h<newhirdmenn.length;h++){
          System.out.print(newhirdmenn[h]+" ");      
        }
        System.out.println();
        */
        
        for(int h=0;h<newhirdmenn.length;h++){
          if(newhirdmenn[h]<min){
            min = newhirdmenn[h];  
          }if(newhirdmenn[h]>max){
            max=newhirdmenn[h];
          }
          sum = sum + newhirdmenn[h];
        }
        double medal = sum/amount;
        
        
        System.out.println(min + " "+ max+ " "+medal);
        
      }
      
    }
    
    in.close();
  }
}


