

function valueOut(){
	if (people.length === 0) {
		print('-1 -1 -1');
	}
	else{
		sum = 0;
		high = -1;
		low = -1;
		
		for (var i = 0; i < people.length; i++) {
			if (low == -1 || people[i] < low){
				low = people[i];
			}

			if (high == -1 || people[i] > high){
				high = people[i];
			}

			sum += people[i];
		}

		avg = sum/people.length;

		print(''+low+' '+high+' '+avg);
	}
}

function pluck(int){
	for (var i = 0; i < people.length; i++) {
		if(int == people[i]){
			people.splice(i, 1);
			break;
		}
	}
}

// A = joining
// R = leaving

var count = 0,
	sum = 0,
	avg = -1,
	low = -1,
	high = -1;

var input = readline();

var people = [];

for (var i = 1; i < input.length; i++) {
	var change = input[i].split(' ');

	if (change[0] == 'A') {
		people.push(parseInt(change[1]));
	}
	else if(change[0] == 'R'){
		// people.splice(people.indexOf(parseInt(change[1])), 1);
		pluck(change[1]);
	}

	valueOut();
}
