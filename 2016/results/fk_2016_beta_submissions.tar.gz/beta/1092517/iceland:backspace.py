import re

s = input()
while True:
    sa = re.sub(r'[a-z][<]{1}', '', s)
    if sa == s:
        break
    s = sa
s = s.split("<")
string = ""
for a in s:
    string += a
print(string)
