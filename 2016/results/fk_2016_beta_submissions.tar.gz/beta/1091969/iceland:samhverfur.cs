using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] k = new int[5] {1,4,3,10,6};
            
            
            for (int i = 0; i < k.Length; i++)
            {
                Console.WriteLine(k[i].ToString() + " " + Math.Pow(2, k[i]));
            }
            Console.ReadKey();
        }
    }
}
