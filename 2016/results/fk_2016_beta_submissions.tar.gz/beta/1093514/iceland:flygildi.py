import math
fjoldi = int(input())
listi = []
summa = 0
for x in range(0,fjoldi):
    strengur = str(input())
    split = strengur.split(" ")
    if x == 0:
        listi.append(split[0])
        listi.append(split[1])
    else:
        byrjun = math.sqrt(math.pow(int(listi[0]) - 0,2) + math.pow(int(listi[1]) - 0,2))
        summa = summa + (math.sqrt( math.pow((int(split[0]) - int(listi[0])), 2) + math.pow((int(split[1]) - int(listi[1])), 2) ))
        listi.pop(0)
        listi.pop(0)
        listi.append(split[0])
        listi.append(split[1])
endir = math.sqrt(math.pow(int(split[0]) - 0,2) + math.pow(int(split[1]) - 0,2))
                  
summa = summa + byrjun + endir
print(summa)        
