number = int(raw_input())

gates = []
to_print = []

def find_inntak(name):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            return x[1], x[2]
    return ""

def replace_inntak(name, value):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            x[1] = name
            x[2] = value

for x in range(0, number):
    thing = raw_input().split()

    if thing[0] == "UTTAK":
        to_print.append(find_inntak(thing[1]))
    else:
        replace_inntak(thing[1], thing[2])
        gates.append(thing)

for x in to_print:
    print x[0], x[1]