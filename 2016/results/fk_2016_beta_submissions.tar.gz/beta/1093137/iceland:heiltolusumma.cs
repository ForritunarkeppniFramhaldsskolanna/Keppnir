using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12
{
    class Program
    {
        static void Main(string[] args)
        {
            long a =  Convert.ToInt64(Console.ReadLine()); 
            float b=0;

            for (int i = 0; i < a+1; i++)
            {
                b += i;
            }
            Console.WriteLine(b);
            Console.ReadKey();
        }
    }
}
