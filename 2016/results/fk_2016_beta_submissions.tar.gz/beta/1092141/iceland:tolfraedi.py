n = int(input())

sum = 0
mi = 0
ma = 0
av = 0
le = 0
for x in range(n):
    a = input().split()
    i = a[0]
    s = int(a[1])
    if i == "A":
        sum += s
        le += 1
    else:
        sum -= s
        le -= 1
    if le != 0:
        av = "{0:.6f}".format(sum / float(le))
        print(mi, ma, av)
    else:
        print(-1, -1, -1)