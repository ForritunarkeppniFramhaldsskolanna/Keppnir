import re

s = input()
s = (re.sub(r'.[<]{1}', '', s))
s = (re.sub(r'.[<]{1}', '', s))
print(s)
