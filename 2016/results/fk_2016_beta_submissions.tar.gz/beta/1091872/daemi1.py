strengur = str(input())
newString = ""
count = 0
for x in range(0, len(strengur)-1):
    if strengur[x+1] == "<" or strengur[x] == "<":
        count = 1      
    else:
        newString += strengur[x]
newString += strengur[len(strengur)-1]
print(newString)
