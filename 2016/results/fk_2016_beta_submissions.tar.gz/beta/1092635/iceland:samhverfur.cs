using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace forritun
{
    class Program
    {
        //43
        static void Main()
        {
            for(int i = 1; i < 42; i++)
            {
                Console.WriteLine(i + " " + pal(i));
            }
        }

        static long pal(long n)
        {
            for(long i = (long)Math.Pow(2, n); i > 0; i--)
            {
                if (IsPalindrome(i.ToString()))
                {
                    return i;
                }
            }
            return 0;
        }
        public static bool IsPalindrome(string s)
        {
            return s == new string(s.Reverse().ToArray());
        }
    }
}
