x = int(input(''))
count=0
for z in range(1,x+1):
    count += z
    print(z)
print(count)
