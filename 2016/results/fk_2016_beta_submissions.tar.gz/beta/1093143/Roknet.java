import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * @author Alexander
 * @version 1.0
 */

public class Roknet {

	/**
	 * Type 1 = inntak
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		/*
		 * 4 8245477 9917762 9871234 8247713 5 824 9 99177 8245477 565
		 **/
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			ArrayList<Rok> inntok = new ArrayList<Rok>();
			int fjoldiHluta = Integer.parseInt(br.readLine());
			for (int i = 0; i < fjoldiHluta; i++) {
				String[] data = br.readLine().split(" ");
				String gerd = data[0];
				if (gerd.equals("INNTAK")) {
					String nafn = data[1];
					String sanngildi = data[2];
					Rok rok = new Rok();
					rok.nafn = nafn;
					rok.sanngildi = sanngildi;
					inntok.add(rok);
				} else if (gerd.equals("UTTAK")) {
					String nafn = data[1];
					for (Rok rok : inntok) {
						if (rok.nafn.equals(nafn)) {
							System.out.println(nafn + " " + rok.sanngildi);
							break;
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
