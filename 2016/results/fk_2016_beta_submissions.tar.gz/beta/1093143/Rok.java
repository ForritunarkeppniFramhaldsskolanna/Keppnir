
/**
 * @author Alexander
 * @version 1.0
 */

public class Rok {
	
	public String nafn;
	public String sanngildi;

}
