import java.util.*;
public class keppnisdaemi
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        String q = in.nextLine();
        int Q = Integer.parseInt(q);
        long sum = 0;
        long max = 0;
        long min = 1000000001;
        int Min = 0;
        int Max = 0;
        int R = 0;
        int A = 0;
        long[] aldrar = new long[Q];
        long[] farnir = new long[Q];
        for(int i = 0; i < Q; i++)
        {
            String inn = in.nextLine();
            String[] a = inn.split(" ");
            int aldur = Integer.parseInt(a[1]);
            if(a[0].equals("A"))
            {
                sum += aldur;
                aldrar[i] = aldur;
                A++;
                /*if(aldur > max)
                {
                    max = aldur;
                }
                if(aldur < min)
                {
                    min = aldur;
                }*/
            }
            else if(a[0].equals("R"))
            {
                sum -= aldur;
                farnir[i] = aldur;
                /*if(aldur == min)
                    Min++;
                if(aldur == max)
                    Max++;*/
                R++;
            }
            long[] sorted = new long[Q];
            sorted = sort(aldrar);
            max = sorted[Q-R-1];
            min = sorted[Q-i+R-1];
            double medaltal = ((double)sum)/((double)(A-R));
            if(R==A)
                System.out.println("-1 -1 -1");
            else System.out.println(min + " " + max + " " + medaltal);
        }
    }
    public static long[] sort(long[] a)
    {
        long[] b = new long[a.length];
        if(a.length == 1)
        {
            b[0] = a[0];
            return b;
        }
        else if(a.length == 2)
        {
            b[0] = Math.min(a[0], a[1]);
            b[1] = Math.max(a[0], a[1]);
            return b;
        }
        else
        {
            long[] c = new long[a.length/2];
            long[] d = new long[a.length - c.length];
            for(int i = 0; i<a.length; i++)
            {
                if(i < c.length)
                    c[i] = a[i];
                else
                    d[i-c.length] = a[i];
            }
            long[] sc = sort(c);
            long[] sd = sort(d);
            return merge(sc, sd);
        }
    }
    public static long[] merge(long[] a, long[] b)
    {
        long[] c = new long[a.length+b.length];
        int s = 0;
        int r = 0;
        for(int i = 0; i < a.length+b.length; i++)
        {
            if(r < b.length && s < a.length)
            {
                if(a[s] < b[r])
                {
                    c[i] = a[s];
                    s++;
                }
                else if(a[s] >= b[r])
                {
                    c[i] = b[r];
                    r++;
                }
            }
            else
            {
                if(r == b.length)
                {
                    c[i] = a[s];
                    s++;
                }
                else
                {
                    c[i] = b[r];
                    r++;
                }
            }
        }
        return c;
    }
}
