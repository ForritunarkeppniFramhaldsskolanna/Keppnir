n = int(input())
summa = 0

if n > 0:
    summa = int((n * (n + 1)) / 2)
else:
    summa = -int((n * (n - 1)) / 2) + 1
print(summa)