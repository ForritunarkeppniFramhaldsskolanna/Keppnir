#include <iostream>
#include <string>
#include <math.h>      
using namespace std;
int main(){
	int number1;
	cin >> number1;
	string phonenumber[number1];
	for (int i = 0; i < number1; ++i)
	{
		string line;
		cin >> line;
		phonenumber[i] = line;
	}
	int number;
	cin >> number;

	for (int i = 0; i < number; ++i)
	{
		string line;
		cin >> line;
		int counter = 0;
		for (int j = 0; j < number1; ++j)
		{
			// substring what whe have if it is longer and compare.
			string temp = phonenumber[j].substr(0,line.length());
			if (temp == line)
			{
				counter += 1;
			}
		}
		cout << counter << endl;
	}
}