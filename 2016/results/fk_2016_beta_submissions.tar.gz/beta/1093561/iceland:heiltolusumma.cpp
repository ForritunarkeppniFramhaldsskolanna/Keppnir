#include <iostream>
using namespace std;
int main() {
	long long int n;
	long long int sum;
	cin >> n;
	if(n < 0){
		n = n * -1;
		sum = (((n*(n+1)/2)) * -1)+1;
	} else {
		sum = (n*(n+1)/2);
	}
	cout << sum;
}