import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;

/**
 * @author Alexander
 * @version 1.0
 */

public class HeilToluSumma {

	public static void main(String[] args) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			long fjoldi = Long.parseLong(br.readLine());
			boolean negative = fjoldi < 0;
			if (negative) {
				fjoldi = -fjoldi;
			}
			BigInteger i = BigInteger.valueOf(fjoldi);
			BigInteger i2 = BigInteger.valueOf(fjoldi + 1);
			BigInteger i3 = BigInteger.valueOf(2);
			i = i.multiply(i2);
			i = i.divide(i3);
			if (negative)
				System.out.println("-" + i.toString());
			else
				System.out.println(i.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
