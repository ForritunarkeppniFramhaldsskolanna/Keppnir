
inp = raw_input()
svar = 0
intInp = int(inp)
if(int(inp) > 0):
    for x in range(1,intInp + 1):
        svar += x
else:
    for item in range(intInp, 0):
        svar += item
print svar
