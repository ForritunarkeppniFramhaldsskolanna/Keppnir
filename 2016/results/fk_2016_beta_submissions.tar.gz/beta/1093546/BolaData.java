
/**
 * @author Alexander
 * @version 1.0
 */

public class BolaData {

	public long max, min;
	
	public boolean buinn = false;

}
