import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * @author Alexander
 * @version 1.0
 */

public class Bolir {

	public static void main(String[] args) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			long fjoldi = Long.parseLong(br.readLine());
			ArrayList<BolaData> users = new ArrayList<BolaData>();

			long maxBolaStaerd = 0;
			long minBolaStaerd = Long.MAX_VALUE;
			for (int i = 0; i < fjoldi; i++) {
				BolaData user = new BolaData();
				String[] data = br.readLine().split(" ");
				user.min = Long.parseLong(data[0]);
				user.max = Long.parseLong(data[1]);
				if (maxBolaStaerd < user.max) {
					maxBolaStaerd = user.max;
				}
				if (minBolaStaerd > user.min) {
					minBolaStaerd = user.min;
				}
				users.add(user);
			}

			long[] lausirBolir = new long[(int) maxBolaStaerd + 1];
			for (int i = 0; i < lausirBolir.length; i++) {
				lausirBolir[i] = 0;
			}

			String[] data = br.readLine().split(" ");
			for (int i = 0; i < data.length; i++) {
				lausirBolir[Integer.parseInt(data[i])]++;
			}

			for (int i = 0; i < users.size(); i++) {
				BolaData user = users.get(i);
				if (user.min == user.max) {
					lausirBolir[(int) user.min]--;
					user.buinn = true;
				}

			}

			for (int i = (int) minBolaStaerd; i <= maxBolaStaerd; i++) {
				
				for (int j = 0; j < users.size(); j++) {
					BolaData u = users.get(j);
					if (!u.buinn) {
						if (u.min >= minBolaStaerd && u.max <= i) {
							for (int k = (int) minBolaStaerd; k <= i; k++) {
								if (lausirBolir[k] > 0) {
									lausirBolir[k]--;
									u.buinn = true;
									break;
								}

							}
						}
					}
				}
			}

			for (int i = 0; i < lausirBolir.length; i++) {
				if (lausirBolir[i] < 0) {
					System.out.println("Neibb");
					return;
				}
			}
			for (int i = 0; i < users.size(); i++) {
				if (!users.get(i).buinn) {
					System.out.println("Neibb");
					return;
				}
			}
			System.out.println("Jebb");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
