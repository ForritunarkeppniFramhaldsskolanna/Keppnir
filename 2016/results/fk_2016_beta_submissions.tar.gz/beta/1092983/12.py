x = int(input())

def 12(num):
    count=0
    for z in range(1,x+1):
        count += z
    print(count)
12(x)
