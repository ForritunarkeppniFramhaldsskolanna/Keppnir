talaN, talaK = input().split()
talaN = input().split()
talaN = list(map(int,talaN))
replacement = talaN
for index in range(int(talaK)):
    talaN[0],talaN[1] = talaN[1],talaN[0]
print (talaN[0], talaN[1])
    
    
