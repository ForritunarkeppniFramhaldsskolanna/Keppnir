items = int(input())
gates = []
gateDict = {}
for item in range(items):
    gates.append(input().split())
UTTAKCounter = '0'
for gate in gates:
    if gate[0] == 'INNTAK':
        gateDict[gate[1]] = {}
        gateDict[gate[1]]['type'] = gate[0]
        if gate[2] == 'SATT':
            gateDict[gate[1]]['value'] = True
        else:
            gateDict[gate[1]]['value'] = False
    elif gate[0] == 'UTTAK':
        gateDict['UTTAK' + UTTAKCounter] = {}
        gateDict['UTTAK' + UTTAKCounter]['type'] = gate[0]
        gateDict['UTTAK' + UTTAKCounter]['input'] = gate[1]
        UTTAKCounter = int(UTTAKCounter)
        UTTAKCounter += 1
        UTTAKCounter = str(UTTAKCounter)
    elif gate[0] == 'OG':
        gateDict[gate[3]] = {}
        gateDict[gate[3]]['type'] = gate[0]
        gateDict[gate[3]]['input1'] = gate[1]
        gateDict[gate[3]]['input2'] = gate[2]
    elif gate[0] == 'EKKI':
        gateDict[gate[2]] = {}
        gateDict[gate[2]]['type'] = gate[0]
        gateDict[gate[2]]['input'] = gate[1]
    elif gate[0] == 'EDA':
        gateDict[gate[3]] = {}
        gateDict[gate[3]]['type'] = gate[0]
        gateDict[gate[3]]['input1'] = gate[1]
        gateDict[gate[3]]['input2'] = gate[2]

for gate2 in gateDict:
    if gateDict[gate2]['type'] == 'INNTAK':
       continue
    elif gateDict[gate2]['type'] == 'UTTAK':
        for gateInner in gateDict:
            if gateInner == gateDict[gate2]['input'] and gateDict[gateInner]['type'] != 'UTTAK':
                print(gateDict[gateInner]['value'])