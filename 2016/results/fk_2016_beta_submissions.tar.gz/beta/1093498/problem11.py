import sys

n = int(sys.stdin.readline().replace("\n", ""))

numer = []

pruf = []

for i in range(0, n):
    temp = sys.stdin.readline().replace("\n", "")

    pruf.append(int(temp[:1]))
    pruf.append(int(temp[:2]))
    pruf.append(int(temp[:3]))
    pruf.append(int(temp[:4]))
    pruf.append(int(temp[:5]))
    pruf.append(int(temp[:6]))
    pruf.append(int(temp[:7]))

q = int(sys.stdin.readline().replace("\n", ""))

rett = [0] * q

for i in range(0, q):
    gisk = sys.stdin.readline().replace("\n", "")

    if int(gisk) in pruf:
        rett[i] += 1

for i in range(0, len(rett)):
    print(rett[i])
