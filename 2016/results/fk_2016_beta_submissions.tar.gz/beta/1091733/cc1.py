x = raw_input()
y = []

for i in range(0, len(x)):
    if(x[i] == "<"):
        del y[len(y) - 1]
    else:
        y.append(x[i])

print ''.join(y)