def main():
    import sys
    from math import sqrt

    def sortBoth(cList, now, counter):
        for hnit in cList:
            if "first" not in locals():
                first = hnit
            else:
                if sqrt((hnit[0] - now[0])**2 + (hnit[1] - now[1])**2) < sqrt((first[0] - now[0])**2 + (first[1] - now[1])**2):
                    first = hnit
        if "first" not in locals():
            first = [0,0]
        if len(cList) == 0:
            counter += sqrt((now[0])**2 + (now[1])**2)
            return counter
        else:
            counter += sqrt((first[0] - now[0])**2 + (first[1] - now[1])**2)
            now = first
            cList.pop(cList.index(first))
            counter = sortBoth(cList, now, counter)
            return counter

    way = []
    for line in sys.stdin:
        line = line.strip()
        if "ñ" not in locals():
            ñ = line
        else:
            line = line.split(" ")
            way.append([float(line[0]),float(line[1])])
    way.insert(0, [0,0])
    way = sortBoth(way, [0,0], 0)
    print(way)








main()