using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Application
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			int number = Convert.ToInt32 (Console.ReadLine ());
			List<int> people = new List<int> ();
			for (int i = 0; i < number; i++) {
				string[] line = Console.ReadLine ().Split (' ');
				int age = Convert.ToInt32 (line [1]);
				if (line[0][0] == 'A') {
					// is adding
					people.Add(age);
				} else {
					// is quiteing
					int index = 0;
					//Console.WriteLine ("People total sizw" + people.Count);
					for (int j = 0; j < people.Count; j++) {
						
						if (people[j] == age) {
							//Console.WriteLine (i);
							index = j;
						}
					}
					people.RemoveAt (index);
				}
				// print the numbers
				Console.WriteLine (people.Min() +" "+ people.Max() +" "+ people.Average());
			}
		}
	}
}