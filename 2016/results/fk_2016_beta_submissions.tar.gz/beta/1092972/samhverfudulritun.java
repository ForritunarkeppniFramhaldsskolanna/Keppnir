import java.math.*;
public class samhverfudulritun {
public static void main(String[] args){
	BigInteger max=new BigInteger("2");
	BigInteger t=new BigInteger("-1");
	BigInteger geymsla=new BigInteger("1");
	BigInteger samhverfa=new BigInteger("0");
	BigInteger deilir=new BigInteger("0");
	for(int i=1;i<=35;i++){
		System.out.print(i+" ");
		max=max.pow(i);

		while(t.equals(new BigInteger("-1"))){
			geymsla=max;
			
			for(BigInteger j=new BigInteger("1");j.compareTo(max)<=0;j=j.multiply(new BigInteger("10"))){
				deilir=j.multiply(new BigInteger("10"));
				
				while(true){
				if((geymsla.remainder(deilir)).equals(new BigInteger("0"))){
					samhverfa=samhverfa.multiply(new BigInteger("10"));
					
					break;
				}
				geymsla=geymsla.subtract(j);
				samhverfa=samhverfa.add(new BigInteger("1"));
				
			}}
			
			samhverfa=samhverfa.divide(new BigInteger("10"));
			if(samhverfa.compareTo(max)==0)
				t=samhverfa;	
			else{
				samhverfa=BigInteger.valueOf(0);}
				max=max.subtract(new BigInteger("1"));
		}
		
		System.out.println(t);
		geymsla=BigInteger.valueOf(0);
	    t=BigInteger.valueOf(-1);
	    samhverfa=BigInteger.valueOf(0);
	    max=BigInteger.valueOf(2);
	
	}
}
}