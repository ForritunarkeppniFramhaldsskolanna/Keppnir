import java.util.*;
public class dans
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        String a = in.nextLine();
        String[] A = a.split(" ");
        int N = Integer.parseInt(A[0]);
        long K = Long.parseLong(A[1]);
        String b = in.nextLine();
        String[] B = b.split(" ");
        int[] manns = new int[B.length+1];
        for(int i = 1; i < B.length+1; i++)
        {
            manns[i] = Integer.parseInt(B[i-1]);
        }
        int[] manns2 = new int[manns.length];
        //long x = 0;
        for(int i = 1; i < manns.length; i++)
        {
            int nu = i;
            int x = 0;
            while(x < K % N)
            {
                nu = manns[nu];
                x++;
            }
            manns2[i]=nu;
        }
        /*while(x < K)
        {
            int telj = 1;
            int y = 1;
            while(telj < manns.length)
            {
                manns[manns[y]] = manns[y];
                telj++;
            }
            x++;
        }*/
        for(int i = 1; i < manns.length; i++)
        {
            System.out.print(manns2[i] + " ");
        }
        System.out.println();
    }
}