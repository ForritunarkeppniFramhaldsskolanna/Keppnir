amount = int(input())
ranges = []
for contestant in range(amount):
    temp = input().split()
    temp[0] = int(temp[0])
    temp[1] = int(temp[1])
    ranges.append(temp)
shirtSizes = input().split()
for shirtSize in shirtSizes:
    shirtSize = int(shirtSize)
for shirt in shirtSizes:
    for sizeRange in ranges:
        if int(shirt) == sizeRange[0] or int(shirt) == sizeRange[1]:
            ranges.remove(sizeRange)
            shirtSizes.remove(shirt)
        elif int(shirt) in range(sizeRange[0], sizeRange[1] + 1):
            ranges.remove(sizeRange)
            shirtSizes.remove(shirt)
if len(shirtSizes) == len(ranges) and len(shirtSizes) == 0:
    print("Jebb")
else:
    print("Neibb")