using System;
class Heiltolusumma{
	static void Main(){
		long input = Convert.ToInt64(Console.ReadLine());
		long output = 0;
		if(input>0){
			for(int I = 1; I<=input; I++){
				output += I;
			}
		}
		else{
			for(long a = input; a<=1; a++){
				output += a;
			}
		}
		Console.WriteLine(output);
	}
}