import java.util.Scanner;

public class BackspaceV3time
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    
   String boingo = scan.nextLine();
   scan.close();
   int lengdBoingo = boingo.length();
   
   for(int i = 0;i<lengdBoingo;i++)
   {

     if(boingo.charAt(i) == '<')
     {
//       String boingoTemp = "";
//      for(int j = 0;j<i-1;j++)
//      {
//        boingoTemp = boingoTemp + boingo.charAt(j);
//      }
//        for(int j = i+1;j<boingo.length()-2;j++)
//      {
//        boingoTemp = boingoTemp + boingo.charAt(j);
//      }
       
       String boingoTemp = boingo.substring(0, i-1) + boingo.substring(i+1);
i = 0;
boingo = boingoTemp;
lengdBoingo = boingo.length();
     }
     else
     {

       
     }
     
    

   }
    
    
  System.out.println(boingo);
    
    
    
    
    
    
  }
}