var input = [];

var line;
while(line = readline()){
	input.push(line);
}

var verses = input[0].split(' ')[1];
var dancers = input[1].split(' ');

for (var i = 0; i < verses; i++) {
	var first = dancers[0];
	
	for (var i = 0; i < dancers.length-1; i++) {
		dancers[i] = dancers[i+1];
	}

	dancers[dancers.length-1] = first;
}

print(dancers.join(' '));
