number = int(raw_input())

bits = map(int, raw_input().split())
number_of_ones = []

for idx, x in enumerate(bits):
    bit_buffer = bits
    for i in range(idx-1, len(bit_buffer)):
        for i in range(i, len(bit_buffer)):
            if bit_buffer[i] == 0:
                bit_buffer[i] = 1
            else:
                bit_buffer[i] = 0
        counter = 0
        for i in bit_buffer:
            if i == 1:
                counter += 1

        number_of_ones.append(counter)

print max(number_of_ones)