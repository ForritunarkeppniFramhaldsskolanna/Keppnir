using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            long tala = Convert.ToInt32(Console.ReadLine());
            long summa = 0;
            summa = ((tala * (tala + 1)) / 2);
            Console.WriteLine(summa);
            Console.ReadKey();
        }
    }
}
