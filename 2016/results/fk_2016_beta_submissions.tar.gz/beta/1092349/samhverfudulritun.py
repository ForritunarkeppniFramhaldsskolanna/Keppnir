def palindrome(x):
    return str(x) == str(x)[::-1]
palindromes = set()
for k in range(1,101):
    maxNumber = k**2
    highest = 0
    for x in range(maxNumber, 1, -1):
        if palindrome(x):
            if x > highest:
                highest = x
    print('%s %s' % (k, highest))