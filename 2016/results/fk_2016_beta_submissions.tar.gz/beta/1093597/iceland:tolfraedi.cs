using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> digits = new List<string>();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                digits.Add(Console.ReadLine());
            }

            int queryCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < queryCount; i++)
            {
                string digit = "";

                foreach (string s in digits)
                {
                    digit += s;
                }
                //string digit = digits[i];
                string req = Console.ReadLine();

                int t = 0;
                int counter = 0;

                while ((t = digit.IndexOf(req, t)) != -1)
                {
                    t += req.Length;
                    counter++;
                }

                Console.WriteLine(counter);
            }
        }
    }
}