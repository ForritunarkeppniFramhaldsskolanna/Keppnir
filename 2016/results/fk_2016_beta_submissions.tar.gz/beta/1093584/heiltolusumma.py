number = int(input())
total = 0
if number < 0:
    for i in range(1, number-1, -1):
        total += i
else:
    for i in range(number+1):
        total += i
print(total)