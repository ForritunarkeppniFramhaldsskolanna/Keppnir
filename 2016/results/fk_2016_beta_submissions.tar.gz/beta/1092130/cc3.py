import math

def ersam(x):
    return int(str(x)[::-1]) == x

for i in range(1, 20):
    m = math.pow(2, i)
    for w in range(int(m), 0, -1):
        if(ersam(w)):
            print "{0} {1}".format(i, w)
            break


