a = map(int, raw_input().split(" "))
c = []
b = map(int, raw_input().split(" "))
for p in range(0, (a[0] + 1)):
    c.append(p + 1)

for i in range(0, (a[1])):
    atemp = []
    for x in range(0, (a[0])):
        atemp.append(c[((b[x] - 1))])
    c = atemp
print ' '.join(map(str, atemp))