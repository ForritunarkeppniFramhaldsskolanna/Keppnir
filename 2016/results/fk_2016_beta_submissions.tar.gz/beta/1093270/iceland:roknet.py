number = int(raw_input())

gates = []

def find_inntak(name):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            return x[2]

def replace_inntak(name, value):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            x[1] = name
            x[2] = value

for x in range(0, number):
    thing = raw_input().split()

    if thing[0] == "UTTAK":
        print find_inntak(thing[1])
    else:
        replace_inntak(thing[1], thing[2])
        gates.append(thing)