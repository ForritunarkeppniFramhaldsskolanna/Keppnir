<?php

fscanf(STDIN, '%d', $tala);

$count = $tala;
$heild = $tala;

if ($tala > 1) {

while ($tala > 0) {


  $heild = $heild + $tala - 1;
  $tala--;
}

}

if ($tala == 1) {

$heild = 1;

}

if ($tala > 1) {

while ($tala < 1) {


  $heild = $heild + $tala - 1;
  $tala++;
}

}

fprintf(STDOUT, "%d\n", $heild);

?>
