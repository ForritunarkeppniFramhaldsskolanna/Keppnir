using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string intak = Console.ReadLine();
            List<char> listin = new List<char>();
            int stroka = 0;
            int tala = 0;
            for (int i = 0; i < intak.Length; i++)
            {
                if (i != (intak.Length - 1))
                {
                    if (intak[i + 1] == '<')
                    {
                        listin.Add(intak[i]);
                        for (int s = (i + 1); s < intak.Length; s++)
                        {
                            if (intak[s] == '<')
                            {
                                stroka++;
                                i++;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        listin.Add(intak[i]);
                    }
                }
                else if(intak[i] == '<')
                {
                    stroka++;
                }
                else
                {
                    listin.Add(intak[i]);
                }
                tala =(i - stroka);
                for (int h = stroka; h > 0; h--)
                {
                    stroka--;
                    listin.RemoveAt((listin.Count-1));
                    tala--;
                }
            }
            foreach (var s in listin)
            {
                Console.Write(s);
            }
            Console.ReadKey();
        }
    }
}
