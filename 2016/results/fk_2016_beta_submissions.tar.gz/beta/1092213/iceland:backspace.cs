using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string S = "a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<asda<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<";
            char[] array = S.ToCharArray();
            List<string> output = new List<string>();
            for (double i = 0; i < array.Length; i++)
            {
                char letter = array[i];             
                if (letter.ToString() == "<")
                {
                    output.Remove(output.Last());
                }
                else
                {
                    output.Add(letter.ToString());
                }
            }
            string Res = string.Join("",output.ToArray());
            Console.WriteLine(Res);
            
            
        }
    }
}
