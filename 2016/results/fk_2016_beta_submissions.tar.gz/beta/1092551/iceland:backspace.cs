using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dæmi1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string newstring = null;

            foreach (char c in input)
            {
                if (c != '<')
                {
                    newstring += c;
                }
                else
                {
                    newstring = newstring.Substring(0, newstring.Length - 2);
                }
            }
            Console.WriteLine(newstring);
        }
    }
}
