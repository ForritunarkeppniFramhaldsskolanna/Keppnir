using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tala = Convert.ToInt32(Console.ReadLine());
            List<string> listi = new List<string>();
            int nulltelja = 0;
            int einntelja = 0;
            int byrja = 0;
            bool byrjun = false;
            int enda = 0;
            listi.AddRange(Console.ReadLine().Split(' '));
            for (int i = 0; i < tala; i++)
            {
                if (listi[i] == "0")
                {
                    nulltelja++;
                }
                else
                {
                    einntelja++;
                }
            }
            for (int i = 0; i < tala; i++)
            {
                if (listi[i] == "0" && byrjun == false)
                {
                    byrja = i;
                    byrjun = true;
                }
                else if(listi[i] == "0")
                {
                    enda = i;
                }
            }
            for (int i = byrja; i <= enda; i++)
            {
                if (listi[i] == "0")
                {
                    listi[i] = "1";
                }
                else
                {
                    listi[i] = "0";
                }
            }
            einntelja = 0;
            nulltelja = 0;
            for (int i = 0; i < tala; i++)
            {
                if (listi[i] == "1")
                {
                    einntelja++;
                }
            }
            Console.WriteLine(einntelja);
            Console.ReadKey();
        }
    }
}
