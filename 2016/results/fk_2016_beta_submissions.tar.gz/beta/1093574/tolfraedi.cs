using System;
class tolfraedi{
	static void Main(){
		int inn = Convert.ToInt32(Console.ReadLine());
		string[] hirdar = new string[inn];
		string[] temp = new string[2];
		string age = null;
		long lowest = Int64.MaxValue;
		long highest = 0;
		long medal = 0;
		for(int i = 0; i<inn; i++){
			hirdar[i] = Console.ReadLine();
		}
		for(int a = 0; a<inn; a++){
				temp = hirdar[a].Split(' ');
				if(temp[0].Equals('A')){
					age += (temp[1] + ' ');
				}
				 if(temp[0].Equals('R')){
					for(int b = 0; b<age.Length; b++){
						if(age[b].Equals(temp[0])){
							age = age.Remove(age.Length-1);
						}
					}
				}
				for(int c = 0; c<inn; c++){
					if(highest<Convert.ToInt32(age[c])){
						highest = Convert.ToInt32(age[c]);
					}
					if(lowest>Convert.ToInt32(age[c])){
						lowest = Convert.ToInt32(age[c]);
					}
				}
			}

	}
}