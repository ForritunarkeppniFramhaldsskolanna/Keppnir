using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            int Q = int.Parse(Console.ReadLine());
            List<int> nums = new List<int>();
            string[] input;
            char inpChar;
            int inp1;

            for (int i = 0; i < Q; i++)
            {
                input = Console.ReadLine().Split(' ');
                
                inpChar = input[0][0];
                inp1 = int.Parse(input[1]);

                if (inpChar == 'A')
                {
                    nums.Add(inp1);
                }
                else if (inpChar == 'R')
                {
                    nums.Remove(inp1);
                }

                    if (nums.Count > 0)
                        Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
                    else
                        Console.WriteLine((-1) + " " + (-1) + " " + (-1));
            }
        }
    }
}