using System;
using System.Linq;

namespace SumAndAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            int input = Convert.ToInt32(Console.ReadLine());
            var data = Enumerable.Range(1, input);
            Console.WriteLine(data.Sum());
        }
    }
}