using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            double inputCount = double.Parse(Console.ReadLine());
            List<double> nums = new List<double>();

            for (double i = 0; i < inputCount; i++)
            {
                string[] input = Console.ReadLine().Split(' ');

                if (input[0][0] == 'A')
                    nums.Add(double.Parse(input[1]));
                else
                    nums.Remove(double.Parse(input[1]));

                Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
            }
        }
    }
}
