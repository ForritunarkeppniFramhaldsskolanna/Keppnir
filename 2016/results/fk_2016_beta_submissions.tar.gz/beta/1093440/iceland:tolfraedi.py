
ages = []
output = []
q = int(input())
for i in range(q):
    inp = input().split()
    if inp[0] == "A":
        ages.append(int(inp[1]))
    else:
        try:
            ages.pop(ages.index(int(inp[1])))
        except:
            None
    if len(ages) >= 1:
        output.append("{} {} {}".format(min(ages), max(ages), sum(ages) / float(len(ages))))
    else:
        output.append("-1 -1 -1")
for o in output:
    print(o)
