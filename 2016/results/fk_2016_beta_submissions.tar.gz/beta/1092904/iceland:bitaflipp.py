def main():
    import sys

    nums = []
    for line in sys.stdin:
        line = line.strip()
        if "ñ" not in locals():
            ñ = line
        else:
            line = line.split(" ")
            for num in line:
                nums.append(int(num))

    counter = 0
    try:
        first = nums.index(0)
        last = (len(nums) - 1) - nums[::-1].index(0)
        counter += nums[:first].count(1)
        counter += nums[last:].count(1)
        nums = nums[first:last+1]
        counter += nums.count(0)
    except ValueError:
        counter = nums.count(1) - 1

    print(counter)





main()