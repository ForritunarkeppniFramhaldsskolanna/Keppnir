using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication4
{
    class Program
    {

        static void Main(string[] args)
        {
            int bufSize = 1024;
            Stream inStream = Console.OpenStandardInput(bufSize);
            Console.SetIn(new StreamReader(inStream, Console.InputEncoding, false, bufSize));
            string Res = Console.ReadLine();
            char[] array = Res.ToCharArray();
            List<string> output = new List<string>();
            for (int i = 0; i < array.Length; i++)
            {
                char letter = array[i];
                if (letter.ToString() == "<")
                {
                    if (output.Count() != 0)
                    {
                        output.Remove(output.Last());
                    }
                }
                else
                {
                    output.Add(letter.ToString());
                }
            }
            string S = string.Join("", output.ToArray());
            Console.WriteLine(S);
         

        }
    }
}