import sys

n = int(sys.stdin.readline().replace("\n", ""))

ans = 0

if n == 0:
    ans = 1

elif n > 0:
    ans = n * (n+1) / 2

else:
    ans = - abs(n) *(abs(n) + 1) / 2

print(int(ans))
