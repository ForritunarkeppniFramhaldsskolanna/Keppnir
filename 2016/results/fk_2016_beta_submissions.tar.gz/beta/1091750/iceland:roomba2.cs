using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            string inntak = Console.ReadLine();
            int r = Convert.ToInt32(inntak.Split(' ')[0]);
            int d = Convert.ToInt32(inntak.Split(' ')[1]);

            Console.WriteLine("0 0");
            for (int i = 0; i < r; i++)
            {
                if (i % 2 == 0)
                {
                    for (int j = 1; j < d; j++)
                    {
                        Console.WriteLine(i + " " + j);
                    }
                }
                else
                {
                    for (int j = d-1; j >= 0; j--)
                    {
                        Console.WriteLine(i + " " + j);
                    }
                }
                
            }
            for (int i = r-1; i >= 0; i--)
            {
                Console.WriteLine("0 " + i);
            }
            Console.ReadKey();

        }
    }
}
