n = int(input())
summa = (n * (n + 1)) / 2
print(int(summa))
