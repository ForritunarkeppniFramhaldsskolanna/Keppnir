using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace Problem_D
{
    class Program
    {
        static void Main(string[] args)
        {
            int cX = 0, cY = 0;
            double traveled = 0;
            int packCount = Convert.ToInt32(Console.ReadLine());
            List<int> xList = new List<int>();
            List<int> yList = new List<int>();
            for (int i = 0; i < packCount; i++)
            {
                string[] temp = Console.ReadLine().Split(' ');
                xList.Add(Convert.ToInt32(temp[0]));
                yList.Add(Convert.ToInt32(temp[1]));     
            }
            xList.Add(0);
            yList.Add(0);
            for (int i = 0; i < xList.Count; i++)
            {
                    traveled += (Math.Round((Math.Sqrt(Math.Pow(cX - xList[i], 2) + Math.Pow(cY - yList[i], 2))), 10));
                cX = xList[i];
                cY = yList[i];
            }
            Console.WriteLine(traveled);
        }
        
    }
}
