import java.math.BigInteger;
import java.util.Scanner;

public class heiltolusumma {
public static void main(String[] args){
	Scanner in=new Scanner(System.in);

	BigInteger byrjun=new BigInteger(in.next());
    BigInteger summa=new BigInteger("0");
    summa=((byrjun.abs()).multiply(byrjun.abs().add(new BigInteger("1")))).divide(new BigInteger("2"));

	if(byrjun.compareTo(new BigInteger("0"))==-1)
		summa=summa.multiply(new BigInteger("-1")).add(new BigInteger("1"));
	System.out.println(summa);
}
}
