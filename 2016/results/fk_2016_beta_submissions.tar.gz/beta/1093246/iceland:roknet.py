number = int(raw_input())

gates = []

def find_inntak(name):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            return x[2]

for x in range(0, number):
    thing = raw_input().split()

    if thing[0] == "UTTAK":
        print find_inntak(thing[1])
    else:
        gates.append(thing)