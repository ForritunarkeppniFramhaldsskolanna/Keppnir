<?php

fscanf(STDIN, '%[^\n]s', $string);

$array = explode(' ', $string);

$xhnit = $array[0];
$yhnit = $array[1];
$xtelja = 0;
$ytelja = 0;

$oddatala = 0;
$count = 1;
$space = " ";

$margfeldi = 2 * $xhnit;

$heild = $xhnit * $yhnit;

if ($xhnit % 2 == 1) {
  $byrjun = 1;
  $talning = 0;
  $ofugt = 1;
}

while ($count < $heild) {

  while ($byrjun == 1) {
    if ($oddatala == 0 && $count != $margfeldi) {

      if ($ytelja < $yhnit) {
        fprintf(STDOUT, "%s", $xtelja);
        fprintf(STDOUT, "%s", $space);
        fprintf(STDOUT, "%s\n", $ytelja);
        if ($talning == 0) {
          $oddatala = 1;
          $ytelja++;
          $talning++;
        }
        else {
        $xtelja++;
        $talning = 0;
        }
        $count++;
      }

    }
    if ($oddatala == 1 && $count != $margfeldi) {
      if ($ytelja >= 0) {
        fprintf(STDOUT, "%s", $xtelja);
        fprintf(STDOUT, "%s", $space);
        fprintf(STDOUT, "%s\n", $ytelja);
        if ($talning == 0) {
          $oddatala = 0;
          $ytelja--;
          $talning++;
        }
        else {
        $xtelja++;
        $talning = 0;
        }
        $count++;
      }

    }

    $margfeldi = 2 * $yhnit;

    if ($count >= $margfeldi) {
      $byrjun = 0;
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);
      $ytelja++;
      $oddatala = 1;
    }
  }

  if ($oddatala == 0 && $count != $heild && $byrjun == 0  && $ofugt != 1) {

    if ($ytelja < $yhnit) {
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);
      if ($ytelja == $yhnit - 1 && $count != $heild) {
        $oddatala = 1;
        $xtelja++;
      }
      else {
      $ytelja++;
      }
      $count++;
    }

  }

  if ($oddatala == 1 && $count != $heild && $byrjun == 0 && $ofugt != 1) {

    if ($ytelja >= 0) {
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);


      if ($ytelja == 0 && $count != $heild && $mismunur != 1) {
        $oddatala = 0;
        $xtelja++;
      }
      else {
      $ytelja--;
      }
      $count++;
      if ($count == $heild) {
        $xtelja--;
        $xtelja--;
      }
    }

  }

  if ($oddatala == 1 && $count != $heild && $byrjun == 0 && $ofugt == 1) {
    $mismunur = $heild - $count;
    if ($xtelja >= 0) {

      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);
      if ($xtelja == 0 && $count != $heild  && $mismunur != 1) {
        $oddatala = 0;
        $ytelja++;
      }
      else {
      $xtelja--;
      }
      $count++;
    }

  }
  if ($oddatala == 0 && $count != $heild && $byrjun == 0 && $ofugt == 1) {
    if ($xtelja <= $xhnit) {
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);

      if ($xtelja < $xhnit - 1 && $count != $heild) {
        $xtelja++;
      }
      else {
      $ytelja++;
      $oddatala = 1;
      }
      $count++;
    }

  }


}

while ($count == $heild && $ofugt != 1) {
  if ($xtelja > 0) {
    fprintf(STDOUT, "%s", $xtelja);
    fprintf(STDOUT, "%s", $space);
    fprintf(STDOUT, "%s\n", $ytelja);
    $xtelja--;
  }
  if ($xtelja == 0 && $ytelja >= 0) {
    fprintf(STDOUT, "%s", $xtelja);
    fprintf(STDOUT, "%s", $space);
    fprintf(STDOUT, "%s\n", $ytelja);
    $ytelja--;
    if ($ytelja==-1 && $xtelja == 0) {
      exit();
    }
  }

}

$xtelja = 0;
$ytelja--;

while ($count == $heild && $ofugt == 1) {


  if ($ytelja >= -1) {
    fprintf(STDOUT, "%s", $xtelja);
    fprintf(STDOUT, "%s", $space);
    fprintf(STDOUT, "%s\n", $ytelja);
    $ytelja--;
    if ($ytelja== -1 && $xtelja == 0) {
      exit();
    }
  }

}

if ($ytelja == 0 && $xtelja == 0) {
  exit();
}




?>
