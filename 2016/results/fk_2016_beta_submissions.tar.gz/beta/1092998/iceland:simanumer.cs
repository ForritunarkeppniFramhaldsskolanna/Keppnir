using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            long number_count = Convert.ToInt64(Console.ReadLine());
            string[] number_list = new string[number_count];
            for (int i = 0; i < number_count; i++)
            {
                number_list[i] = Console.ReadLine();
            }
            long search_count = Convert.ToInt64(Console.ReadLine());
            string[] search_list = new string[search_count];
            for (int i = 0; i < search_count; i++)
            {
                number_list[i] = Console.ReadLine();
            }
            foreach (string search in search_list)
            {
                long temp = 0;
                foreach (string num in number_list)
                {
                    if (num.Contains(search))
                    {
                        temp++;
                    }              
                }
                Console.WriteLine(temp);
               
            }
            Console.ReadKey();
        }
    }
}
