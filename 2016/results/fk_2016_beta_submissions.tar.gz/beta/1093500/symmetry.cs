using System;
class samhverfudulritun{
	static void Main(){
		bool keepGoing = true;
		int a = 0;
		for(int I = 1; I<101; I++){
			a = I;
			if(Math.Pow(2L,I)<Int64.MaxValue){
				do{
					if(erSamhverf(Convert.ToInt64(Math.Pow(2L,a)))){
						Console.WriteLine(I + " " + Math.Pow(2L,a));
						keepGoing = false;
						a--;
					}
					}while(keepGoing);
				keepGoing = true;
			}
		}
	}
	static bool erSamhverf(long inn){
		string input = Convert.ToString(inn);
		string output = null;
		for(int i = input.Length; i>0; i--){
			output += input[i-1];
		}
		if(output.Equals(input)){
			return true;
		}
		else{
			return false;
		}
	}
}
