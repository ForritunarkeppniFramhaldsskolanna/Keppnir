public static void main(String[] args){
	Scanner in= new Scanner(System.in);
	String s=in.next();
	String[] c=s.split("");
    for(int i=1;i<=s.length();i++){
    	   if(c[i].equals("<")){
    		   c[i]=c[i]+"q";
    		   c[i-1]=c[i-1]+"q";
    	   }
    	  
    	}
    String t="";
    for(int i=1;i<=s.length();i++){
    	if(c[i].length()<2){
    		t=t+c[i];
    	}	
    }
    in.close();
    System.out.print(t);
    }

}

