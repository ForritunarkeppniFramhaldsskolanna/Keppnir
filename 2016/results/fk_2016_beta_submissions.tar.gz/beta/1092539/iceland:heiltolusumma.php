<?php

fscanf(STDIN, '%d', $tala);

$count = $tala;
$heild = $tala;

while ($tala > 0) {

  $heild = $heild + $tala - 1;
  $tala--;
}

fprintf(STDOUT, "%d\n", $heild);

?>

