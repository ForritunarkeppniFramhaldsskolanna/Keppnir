using System;
class Flygildi{
	static void Main(){
		int inn = Convert.ToInt32(Console.ReadLine());
		string[] innArray = new string[2];
		string temp = null;
		Hnit[] hnit = new Hnit[10000*10000];
		double fjarlaegd = 0;
		Hnit fjarHnit = new Hnit(Int32.MaxValue,Int32.MaxValue);
		Hnit hnitaCheck = new Hnit(Int32.MaxValue,Int32.MaxValue);
		for(int i = 0; i<inn; i++){
			temp = Console.ReadLine();
			innArray = temp.Split(' ');
			hnit[i] = new Hnit(Convert.ToInt32(innArray[0]), Convert.ToInt32(innArray[1]));
		}
		double hnitacheckLengd = 0;
		double hnitArrayLengd = 0;
		int temp1 = 0;
		for(int b = 0; b<inn; b++){
			for(int a = 0; a<inn; a++){
				hnitaCheck.x = fjarHnit.x - hnit[a].x;
				hnitaCheck.y = fjarHnit.y - hnit[a].y;
				hnitacheckLengd = Math.Sqrt(Math.Pow(hnitaCheck.x,2) + Math.Pow(hnitaCheck.y,2));
				hnitArrayLengd = Math.Sqrt(Math.Pow(hnit[a].x,2) + Math.Pow(hnit[a].y,2));
				if(hnit[a].used == false){
					if(hnitArrayLengd<hnitacheckLengd){
					fjarHnit = hnit[a];
					temp1 = a;
					}
				}
				Console.WriteLine(hnitacheckLengd + " " + fjarHnit.x + " " + fjarHnit.y);
			}
			hnit[temp1].used = true;
			fjarlaegd +=  (Math.Sqrt((fjarHnit.x*fjarHnit.x) + (fjarHnit.y*fjarHnit.y)));
		}
		//fjarlaegd += (Math.Sqrt(Math.Pow(hnitaCheck.x,2) + Math.Pow(hnitaCheck.y,2)));
		Console.WriteLine(fjarlaegd);
	}
}
class Hnit{
	public int x,y;
	public bool used = false;
	public Hnit(int a,int b){
		x = a;
		y = b;
	}
}