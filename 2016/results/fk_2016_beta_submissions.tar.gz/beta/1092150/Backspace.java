import java.util.Scanner;

public class Backspace
{
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
    String texti = scan.nextLine();
    scan.close();
    int lengd = texti.length();
    texti = texti + " ";
    String uttak = "";
    String uttakTemp = "";
    for(int i = 0; i<lengd;i++)
    {
      System.out.println(uttak);
      
      //ef síðasti stafur og ekki <
      if(i == lengd-1 && texti.charAt(i) != '<')
      {
        uttak = uttak + texti.charAt(i);
        
      }
      //ef síðasti stafur og <
      else if (i == lengd-1 && texti.charAt(i) == '<')
      {
        
      }
      // ef stafurinn er ekki < og ekki næsti heldur
      else if(texti.charAt(i+1) != '<' && texti.charAt(i) != '<')
      {
        uttak = uttak + texti.charAt(i);
      }
      
      
      
      else if(texti.charAt(i) == '<')
      {
        int backCount = 0;
        int lengdUttaks = uttak.length();
        while(true)
        {
          
          // ef það er < í næsta líka
          //það er eitthvað að þessu if falli, er að fara út fyrir kannski?
//        if(i == lengd-1 && texti.charAt(i) == '<')
//        {
//backCount ++;
//for(int u = 0; u<lengdUttaks - backCount;u++)
//{
//  uttakTemp = uttakTemp + uttak.charAt(u);
//       }
//        }
         if(((i < lengd-1 ) && texti.charAt(i+backCount) == '<') )
          {
            backCount ++;
            for(int u = 0; u<lengdUttaks - backCount-1;u++)
            {
              uttakTemp = uttakTemp + uttak.charAt(u);
            }
            
          }
          uttak = uttakTemp;
        }
        
      }
    
      
      
    }
      uttak.trim();
      System.out.println(uttak);
  }
}
