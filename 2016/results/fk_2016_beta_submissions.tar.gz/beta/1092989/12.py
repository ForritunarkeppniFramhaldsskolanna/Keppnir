x = int(input())

def func(num):
    count=0
    for z in range(1,x+1):
        count += z
    print(count)
func(x)
