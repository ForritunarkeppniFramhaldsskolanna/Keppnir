using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E
{
    class Program
    {
        static string snua(string strengur){
            char[] lol = new char[strengur.Length];
            lol = strengur.ToCharArray();
            lol.Reverse();
            return lol.ToString();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("1 2");
            Console.WriteLine("4 11");
            Console.WriteLine("3 8");
            Console.WriteLine("10 1001");
            Console.WriteLine("6 44");
        }
    }
}