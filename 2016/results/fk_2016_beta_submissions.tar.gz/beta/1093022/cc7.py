import math

def getDistance(v1, v2):
    vx = v1[0] - v2[0]
    vy = v1[1] - v2[1]
    vz = v1[2] - v2[2]

    dist = math.sqrt(math.pow(vx, 2) + math.pow(vy, 2) + math.pow(vz, 2))
    return dist


def isIntersecting(v1, v2):
    d = getDistance(v1, v2)
    if(d < v1[3] + v2[3]):
        return True
    else:
        return False

n = int(raw_input())
s = []
for i in range(0, n):
    s.append(map(int, raw_input().split()))
m = int(raw_input())
b = []
for i in range(0, m):
    b.append(map(int, raw_input().split()))



for i in range(0, len(b)):
    for e in range(0, len(s)):
        if(s[e] != None):
            if(isIntersecting(s[e], b[i])):
                s[e] = None

c = 0
for i in range(0, len(s)):
    if(s[i] != None):
        c += 1

print c

