using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forkep2016B
{
    class Program
    {
        static void Main(string[] args)
        {
            int r = 0, d = 0;
            Console.WriteLine("write in 2 numbers");
            r = Convert.ToInt32(Console.ReadLine());
            d = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            int teljari = r * d;
            int x = r, y = d;
            for (int i = 0; i < teljari; i++)
            {
                Console.Write("(" + x + "," + i + ")");
                if (i == r)
                {
                    i = 0;
                    x--;
                    Console.WriteLine();
                    Console.ReadKey();
                }
            }
            Console.ReadLine();
        }
    }
}