import java.util.*;

public class geimskip
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    String nta = sc.nextLine();
    int N = Integer.parseInt(nta);
    int k=0;
    int[][] skip = new int[N][4]; 
    while(k<N)
    {
      String inntak1 = sc.nextLine();
      String[] splittari = inntak1.split(" ");
      skip[k][0] = Integer.parseInt(splittari[0]);
      skip[k][1] = Integer.parseInt(splittari[1]);
      skip[k][2] = Integer.parseInt(splittari[2]);
      skip[k][3] = Integer.parseInt(splittari[3]);
      k++;
    }
    String mta = sc.nextLine();
    int M = Integer.parseInt(mta);
    k=0;
    int[][] sprengjur = new int[M][4];
    while(k<M)
    {
      String inntak1 = sc.nextLine();
      String[] splittari = inntak1.split(" ");
      sprengjur[k][0] = Integer.parseInt(splittari[0]);
      sprengjur[k][1] = Integer.parseInt(splittari[1]);
      sprengjur[k][2] = Integer.parseInt(splittari[2]);
      sprengjur[k][3] = Integer.parseInt(splittari[3]);
      k++;
    }
    while( true ){
      boolean[] springa = new boolean[N];
      int count = 0;
      for( int a = 0; a < N; a++ ){
        for( int b = 0; b < M; b++ ){
          if( lengd(sprengjur[b][0],sprengjur[b][1],sprengjur[b][2],skip[a][0],skip[a][1],skip[a][2]) < sprengjur[b][3] + skip[a][3] ){
            springa[a] = true; 
            count++;
          }
        }
      }
      if( count == 0 ) break;
      int[][] nskip = new int[N-count][4];
      int[][] nsprengjur = new int[count][4];
      int i = 0;
      int j = 0;
      for( int a = 0; a < N; a++ ){
        if( springa[a] ){
          nsprengjur[i] = skip[a];
          nsprengjur[i][3]*=2;
          i++;
        }
        else{
          nskip[j] = skip[a];
          j++;
        }
      }
      sprengjur = nsprengjur;
      skip = nskip;
      N -= count; 
      M = count;
    }
    System.out.println(N);
  }
  public static double lengd(int a, int b, int c, int x, int y, int z)
  {
    int xhnit = x-a;
    int yhnit = y-b;
    int zhnit = z-c;
    int iodru = xhnit*xhnit + yhnit*yhnit + zhnit*zhnit; 
    return Math.sqrt(iodru);
  }
}