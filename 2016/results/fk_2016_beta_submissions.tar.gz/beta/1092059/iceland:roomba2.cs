using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Application
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			int[] tolur = Console.ReadLine ().Split (' ').Select(x => Convert.ToInt32(x)).ToArray();
			int inx = tolur [0];
			int y = tolur[1];
			// for inni for og skilja eftir o,y línuna til að komast til baka
			Console.WriteLine ("0 0");
			for (int i = 1; i < inx; i++) {
				if (i % 2 != 0) {
					for (int j = 0; j < y -1; j++) {
						Console.WriteLine (i + " " + j);
					}
				} else {
					for (int j = y -2; j >= 0; j--) {
						Console.WriteLine (i + " " + j);
					}
				}
			}
			for (int j = inx -1; j >= 0; j--) {
				Console.WriteLine (j +" "+ (y-1));
			}
		}
	}
}