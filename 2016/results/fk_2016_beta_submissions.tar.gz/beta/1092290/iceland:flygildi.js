
var packageNumber;
var pos = {
	x: 0,
	y: 0
}
var distanceTraveled = 0;

var line;
while (line = readline()){
	var input = line.split(' ');

	if (packageNumber === undefined) {
		packageNumber = input[0];
	}
	else{
		distanceTraveled += Math.sqrt(
			Math.pow(pos.x - parseInt(input[0]), 2) +
			Math.pow(pos.y - parseInt(input[1]), 2)
		);

		pos.x = input[0];
		pos.y = input[1];
	}
}

distanceTraveled += Math.sqrt(
	Math.pow(pos.x, 2) +
	Math.pow(pos.y, 2)
);

print(distanceTraveled);
