number = int(raw_input())

bits = map(int, raw_input().split())
number_of_ones = []

for idx, x in enumerate(bits):
    for i in range(idx-1, len(bits)):
        bit_buffer = bits
        for r in range(i, len(bits)):
            if bit_buffer[r] == 0:
                bit_buffer[r] = 1
            else:
                bit_buffer[r] = 0
        counter = 0
        for r in bit_buffer:
            if r == 1:
                counter += 1

        number_of_ones.append(counter)

print max(number_of_ones)