using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            long input = Convert.ToInt64(Console.ReadLine());
            long ans;
            if (input >= 1)
            {
                ans = input / 2 * (input + 1);
            }
            else
            {
                ans = (input / 2 * (input + 1))*-1;
            }
            Console.WriteLine(ans);
            Console.ReadKey();
        }
    }
}
