
function lowerNumber(string){
	int = parseInt(string);
	int = Math.floor(int/10)*10-1;
	return toFixed(int);
}

for (var i = 1; i <= 100; i++) {
	var string = toFixed(Math.pow(2, i));

	var org = parseInt(string);

	if (string.length == 1){
		print(i + ' ' + string);
	}
	else if (string.length%2==0){
		// console.log(':'+string)
		string = string.slice(0, string.length/2);

		var suffix = '';
		for (var x = string.length - 1; x >= 0; x--) {
			suffix += string[x];
		}

		var mirrored = parseInt(string+suffix);

		if(mirrored > org){
			string = lowerNumber(org);

			string = string.slice(0, string.length/2);

			suffix = '';
			for (var x = string.length - 1; x >= 0; x--) {
				suffix += string[x];
			}
		}

		print(i + ' ' + string+suffix);
	}
	else if (string.length%2!=0){
		// console.log(':'+string)
		string = string.slice(0, Math.floor(string.length/2));

		var suffix = '';
		for (var x = string.length - 1; x >= 0; x--) {
			suffix += string[x];
		}

		var mirrored = parseInt(string+suffix);

		if(mirrored > org){
			string = lowerNumber(org);

			string = string.slice(0, string.length/2);

			suffix = '';
			for (var x = string.length - 1; x >= 0; x--) {
				suffix += string[x];
			}
		}

		print(i + ' ' + string+suffix);
	}
}

// console.log(toFixed(Math.pow(2, 1)).length);
// console.log(toFixed(Math.pow(2, 100)));

function toFixed(x) {
  if (Math.abs(x) < 1.0) {
    var e = parseInt(x.toString().split('e-')[1]);
    if (e) {
        x *= Math.pow(10,e-1);
        x = '0.' + (new Array(e)).join('0') + x.toString().substring(2);
    }
  } else {
    var e = parseInt(x.toString().split('+')[1]);
    if (e > 20) {
        e -= 20;
        x /= Math.pow(10,e);
        x += (new Array(e+1)).join('0');
    }
  }
  return ''+x;
}