import math
from decimal import *
fjoldi = int(input())
listi = []
summa = 0
for x in range(0,fjoldi):
    strengur = str(input())
    split = strengur.split(" ")
    if x == 0:
        listi.append(split[0])
        listi.append(split[1])
    else:
        byrjun = math.sqrt(math.pow(float(listi[0]) - 0,2) + math.pow(float(listi[1]) - 0,2))
        summa = summa + (math.sqrt( math.pow((float(split[0]) - float(listi[0])), 2) + math.pow((float(split[1]) - float(listi[1])), 2) ))
        listi.pop(0)
        listi.pop(0)
        listi.append(split[0])
        listi.append(split[1])
endir = math.sqrt(math.pow(float(split[0]) - 0,2) + math.pow(float(split[1]) - 0,2))
                  
summa = summa + byrjun + endir
print(summa)        
