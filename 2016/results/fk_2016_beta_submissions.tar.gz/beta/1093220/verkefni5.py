import math

hversumorgskip = int(input())
skipinfo = []
for x in range(hversumorgskip):
    skipinfo.append(input())


hversumargarsprengjur = int(input())
sprengjuinfo = []
for x in range(hversumargarsprengjur):
    sprengjuinfo.append(input())

survivalcount = 0

for x in range(len(skipinfo)):
    dead = False
    for y in range(len(sprengjuinfo)):
        print(int(skipinfo[x].split()[3]))
        print(int(sprengjuinfo[x].split()[3]))
        sumradius = int(skipinfo[x].split()[3]) + int(sprengjuinfo[y].split()[3])
        xVigur = int(sprengjuinfo[y].split()[0]) - int(skipinfo[x].split()[0])
        yVigur = int(sprengjuinfo[y].split()[1]) - int(skipinfo[x].split()[1])
        zVigur = int(sprengjuinfo[y].split()[2]) - int(skipinfo[x].split()[2])

        vigurMilliKula = (xVigur**2) + (yVigur**2) + (zVigur**2)

        print("vigur milli kula " + str(math.sqrt(vigurMilliKula)))
        print("vigur sum radius " + str(sumradius))
        print(skipinfo[x].split())
        print(sprengjuinfo[y].split())

        if vigurMilliKula < (sumradius*sumradius):
            dead = True
    if not dead:
        survivalcount += 1

print(survivalcount)
