<?php

fscanf(STDIN, '%s', $string);

$array = str_split($string);

$length = strlen($string) + 1;

$stadsetning = 0;

for ($i = 0; $i < $length; $i++) {

  $substr = substr($string, $i);
  $len = strspn($substr, "<");

  if ($len > 0) {

    $count = 0;


    while ($count < $len) {

    $len2 = $i - $count - 1;
    //echo ".." . $len2 . "..";
    //echo ".." . $len3 . "..";

    $len3 = $i + $len - $count;



    $array[$i] = "";
    $array[$len2] = "";

    $count++;

    }
  }



}

foreach ($array as $gildi) {
  fprintf(STDOUT, "%s", $gildi;
}

?>