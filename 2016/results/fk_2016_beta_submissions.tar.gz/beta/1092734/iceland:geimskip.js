var input = [];

var line;
while(line = readline()){
	input.push(line);
}

console.log(input);

var spaceShips = [];
for (var i = 1; i <= input[0]; i++) {
	spaceShips.push(input[i].split(' '));
}

var explosions = [];
for (var i = parseInt(input[0])+2; i < input.length; i++) {
	explosions.push(input[i].split(' '));
}

var destroyedShips = 0;
for (var i = 0; i < spaceShips.length; i++) {
	var point1 = spaceShips[i];
	var hasCollided = false;

	for (var x = 0; x < explosions.length; x++) {
		var point2 = explosions[x];

		var distance = Math.sqrt(
			Math.pow(point1[0]-point2[0], 2) +
			Math.pow(point1[1]-point2[1], 2) +
			Math.pow(point1[2]-point2[2], 2)
		)

		var radi = point1[3] + point2[3];

		if(radi>distance) {
			hasCollided = true;
			break;
		}
	}

	if (hasCollided == true) destroyedShips++;
}

print(spaceShips.length-destroyedShips);