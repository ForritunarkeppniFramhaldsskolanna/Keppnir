import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;

/**
 * @author Alexander
 * @version 1.0
 */

public class Symmetrical {

	private static String[] data = { "1 2", "2 4", "3 8", "4 11", "5 22", "6 55", "7 121", "8 252", "9 505", "10 1001", "11 2002", "12 4004", "13 8118", "14 16361", "15 32723", "16 65456", "17 130031", "18 261162", "19 523325", "20 1048401", "21 2096902", "22 4193914", "23 8387838", "24 16766761", "25 33544533", "26 67100176", "27 134212431", "28 268434862", "29 536868635", "30 1073663701", "31 2147447412", "32 4294884924", "33 8589889858", "34 17179797171", "35 34359695343", "36 68719391786", "37 137438834731", "38 274877778472", "39 549755557945", "40 1099511159901", "41 2199023209912", "42 4398046408934", "43 8796092906978", "44 17592177129571", "45 35184366348153", "46 70368733786307", "47 140737484737041", "48 281474969474182", "49 562949949949265", "50 1125899889985211", "51 2251799779971522", "52 4503599559953054", "53 9007199229917009", "54 18014398489341081", "55 36028796969782063", "56 72057593939575027", "57 144115187781511441", "58 288230375573032882", "59 576460752257064675", "60 1152921504051292511", "61 2305843009003485032", "62 4611686018106861164", };

	public static void main(String[] args) {
		if (true) {
			for (int i = 0; i < data.length; i++) {
				System.out.println(data[i]);
			}
			return;
		}
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			for (int i = 0; i < 100; i++) {
				BigInteger s1 = BigInteger.valueOf(2);
				BigInteger s2 = BigInteger.valueOf(i + 1);
				BigInteger max = pow(s1, s2);
				if (i >= 150) {
					String s = max.toString() + "";
					boolean add = false;
					if (s.length() / 2 % 2 != 0) {
						add = true;
					}
					s = s.substring(0, s.length() / 2 + (add ? 1 : 0));
					String sub = s.substring(0, s.length() + (add ? -1 : 0));
					for (int j = sub.length() - 1; j >= 0; j--) {
						s += sub.charAt(j);
					}
					System.out.println((i + 1) + " " + s);
				} else
					for (long j = max.longValue(); j > 0; j--) {
						if (isSymmetric(j)) {
							System.out.println((i + 1) + " " + j);
							break;
						}
					}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		/*
		 * 1 2 2 4 3 8 4 11 5 22 6 55 7 121 8 252 9 505 10 1001 11 2002 12 4004
		 * 13 8118 14 16361 15 32723 16 65456 17 130031 18 261162 19 523325 20
		 * 1048401 21 2096902 22 4193914 23 8387838 24 16766761 25 33544533 26
		 * 67100176 27 134212431 28 268434862 29 536868635 30 1073663701 31
		 * 2147447412 32 4294884924 33 8589889858 34 17179797171 35 34359695343
		 * 36 68719391786 37 137438834731 38 274877778472 39 549755557945 40
		 * 1099511159901 41 2199023209912 42 4398046408934 43 8796092906978 44
		 * 17592177129571 175921868129571 45 35184366348153 46 70368733786307 47
		 * 140737484737041 48 281474969474182 49 562949949949265 50
		 * 1125899889985211 51 2251799779971522 52 4503599559953054 53
		 * 9007199229917009 54 18014398489341081 55 36028796969782063 56
		 * 72057593939575027 57 144115187781511441 58 288230375573032882 59
		 * 576460752257064675 60 1152921504051292511 61 2305843009003485032 62
		 * 4611686018106861164
		 * 
		 * 
		 */
	}

	public static boolean isSymmetric(long number) {
		if (number == 0)
			return true;
		else if (number < 0)
			return false;
		long DEG_10 = (long) (Math.pow(10, (int) Math.log10(number)));

		while (number > 0) {
			long dStart = number / DEG_10;
			long dEnd = number % 10;
			if (dStart != dEnd)
				return false;
			number = (number - dStart * DEG_10 - dEnd) / 10;
			DEG_10 /= 100;
		}

		return true;
	}

	static BigInteger pow(BigInteger base, BigInteger exponent) {
		BigInteger result = BigInteger.ONE;
		while (exponent.signum() > 0) {
			if (exponent.testBit(0))
				result = result.multiply(base);
			base = base.multiply(base);
			exponent = exponent.shiftRight(1);
		}
		return result;
	}
}
