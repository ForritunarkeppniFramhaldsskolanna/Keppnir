using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            double veldisTala;
            Int64 highest = 0;
            for (int i = 1; i < 19; i++)
            {
                veldisTala = Math.Pow(2, i);
                char[] original = null;
                char[] reversed = null;
                for (int j = 0; j <= veldisTala; j++)
                {
                    reversed = j.ToString().ToCharArray();
                    original = reversed;
                    string high = new string(original);
                    original = high.ToCharArray();
                    Array.Reverse(reversed);
                    string highRev = new string(reversed);
                    if(high == highRev)
                    {
                        highest = Convert.ToInt64(high);
                    }
                }
                Console.WriteLine(i + " " + highest);
            }
        }
    }
}
