using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni2
{
    class Program
    {
        static void Main(string[] args)
        {
            string lengthString = Console.ReadLine();
            int lengthInt = Convert.ToInt32(lengthString);
            List<int> list = new List<int>();
            int max;
            int min;
            double avg;
            int ageInt;
            char[] lines;
            for (int i = 0; i < lengthInt; i++)
            {
                string line = Console.ReadLine();
                lines = line.ToCharArray();
                string letter = lines[0].ToString();
                string age = lines[2].ToString();
                ageInt = Convert.ToInt32(age);
                if(letter.ToUpper() == "A")
                {
                    list.Add(ageInt);
                }
                max = list.Max();
                min = list.Min();
                avg = list.Average();
                Console.WriteLine(min + " " + max + " " + avg);
            }
            Console.ReadLine();
        }
    }
}
