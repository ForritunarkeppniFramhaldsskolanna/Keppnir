a = raw_input()
if int(a) > 0:
	print(sum(range(1, int(a)+1)))
elif int(a) < 0:
	print(sum(range(1, int(a)-1, -1)))
else:
	print("0")