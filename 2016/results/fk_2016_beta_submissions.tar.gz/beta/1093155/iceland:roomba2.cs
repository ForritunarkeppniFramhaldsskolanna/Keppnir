using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inp = Console.ReadLine().Split(' ');
            int y = Convert.ToInt32(inp[0]);
            int z = Convert.ToInt32(inp[1]);
            int stepDown = y - 1;
            int stepZ = 0;
            int stepY = 0;

            List<string> framm = new List<string>();
            List<string> upp = new List<string>();
            
            
            //slétt y================================================================
            if (y % 2 == 0 && z % 2 == 0)
            {
                for (int i = 0; i < z - 1; i++)
                {
                    framm.Add(Convert.ToString(i + 1));
                }

                for (int i = 0; i < y; i++)
                {
                    Console.WriteLine(i.ToString() + " " + "0");
                }


                for (int i = 1; i < y; i++)
                {
                    foreach (string item in framm)
                    {
                        Console.WriteLine(Convert.ToString(stepDown) + " " + item);
                    }
                    framm.Reverse();
                    stepDown = stepDown - 1;
                    //    Console.WriteLine("y is " + stepDown.ToString());

                }
                foreach (string item in framm)
                {
                    Console.WriteLine(Convert.ToString(stepDown) + " " + item);
                }
                Console.WriteLine("0 0");
            }

            //y oddur og z slettur =========================================================================================
            if (y % 2 != 0 && z % 2 == 0)
            {

                for (int i = 0; i < y - 1; i++)
                {
                    upp.Add(Convert.ToString(i));
                }

                for (int i = 0; i < z - 1; i++)
                {
                    framm.Add(Convert.ToString(i + 1));
                }

                
                
                Console.WriteLine(Convert.ToString(stepY) + " " + Convert.ToUInt32(stepZ));
                stepZ += 1;
                for (int i = 0; i < z - 1; i++)
                {
                    
                    foreach (string item in upp)
                    {
                        Console.WriteLine(item + " " + Convert.ToString(stepZ));
                    }
                    stepZ += 1;
                    upp.Reverse();
                }
                framm.Reverse();
                foreach (string thingy in framm)
                {
                    Console.WriteLine(Convert.ToString(y - 1) + " " + thingy);
                }
                Console.WriteLine(Convert.ToString(y - 1) + " 0");
                foreach (string item in upp)
                {
                    
                    Console.WriteLine(item + " 0");
                }
            }

            // y odd z odd ==============================================================================
            if (y % 2 != 0 && z % 2 != 0) 
            {
                for (int hlidar = 0; hlidar < z - 1; hlidar++)
                {
                    for (int i = 0; i < stepDown; i++)
                    {
                        Console.WriteLine(Convert.ToString(stepY) + " " + stepZ);
                        stepY += 1;
                    }
                    stepZ += 1;
                }
            }
            
            
        }
    }
}
