import sys

n = int(sys.stdin.readline().replace("\n", ""))

ans = 0

if n > 0:
    for x in range(1, n + 1):
        ans += x

else:
    for x in range(n, 2):
        ans += x

print(ans)
