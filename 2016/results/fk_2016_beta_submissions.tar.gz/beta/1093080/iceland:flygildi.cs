using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem_D
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] start = new int[] { 0, 0 };
            int[] currentPos = new int[] { 0, 0 };
            int[] tempCoords;
            List<double> answers = new List<double>();
            double traveled = 0;
            int packCount = Convert.ToInt32(Console.ReadLine());
            List<int[]> packXY = new List<int[]>();
            for (int i = 0; i < packCount; i++)
            {
                string[] temp = Console.ReadLine().Split(' ');
                tempCoords = new int[] {Convert.ToInt32(temp[0]), Convert.ToInt32(temp[1])};
                packXY.Add(tempCoords);          
            }
            tempCoords = new int[] { 0,0};
            if (packCount > 8)
            {
                packXY = packXY.OrderBy(arr => arr[1]).ToList();
                for (int i = 0; i <= packXY.Count; i++)
                {
                    if (i < packXY.Count)
                    {
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - packXY[i][0], 2) + Math.Pow(currentPos[1] - packXY[i][1], 2))));
                        currentPos = packXY[i];
                    }
                    else
                    {
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - start[0], 2) + Math.Pow(currentPos[1] - start[1], 2))));
                        currentPos = start;
                    }

                }
            }
            else
            {
                List<List<int[]>> pointLists = new List<List<int[]>>();
                List<int[]> startPositions = new List<int[]>();
                List<int[]> currentPositions = new List<int[]>();
                List<int> distances = new List<int>();
                List<int[]> packXY_temp = makeTemp(packXY);
                for (int i = 0; i < packCount; i++)
                {
                    pointLists.Add(packXY);
                    startPositions.Add(start);
                    currentPositions.Add(currentPos);
                    distances.Add(0);
                }
                while (pointLists.Count != 0)
                {
                    packXY = pointLists[0];
                    pointLists.RemoveAt(0);
                    start = startPositions[0];
                    startPositions.RemoveAt(0);
                    currentPos = currentPositions[0];
                    currentPositions.RemoveAt(0);
                    traveled = distances[0];
                    distances.RemoveAt(0);


                    foreach (int[] packCoords in packXY_temp)
                    {
                        bool FINISH_HIM = false;
                        List<int[]> tempPackXY = packXY;
                        tempPackXY.Remove(packCoords);
                        if (tempPackXY.Count == 0)
                        {
                            FINISH_HIM = true;
                        }
                        tempCoords = packCoords;
                        int[] tempStart = start;
                        int[] tempCurrentPos = currentPos;
                        double tempTraveled = traveled;
                        tempTraveled += ((Math.Sqrt(Math.Pow(tempCurrentPos[0] - packCoords[0], 2) + Math.Pow(tempCurrentPos[1] - packCoords[1], 2))));
                        if (FINISH_HIM)
                        {
                            tempTraveled += ((Math.Sqrt(Math.Pow(tempCurrentPos[0] - tempStart[0], 2) + Math.Pow(tempCurrentPos[1] - tempStart[1], 2))));
                            answers.Add(tempTraveled);
                        }
                        else
                        {

                        }
                    }
                }
                

            }
            if (packCount > 8)
            {
                Console.WriteLine(traveled.ToString("F10"));
            }
            else
            {
                Console.WriteLine(answers.Min().ToString("F10"));
            }
            Console.ReadKey();
        }
        static private List<int[]> makeTemp(List<int[]> packXY)
        {
            List<int[]> temp = new List<int[]> { };
            foreach (int[] item in packXY)
            {
                temp.Add(item);
            }
            return temp;
        }

    }
}
