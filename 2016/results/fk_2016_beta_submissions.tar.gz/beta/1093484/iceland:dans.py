a = map(int, raw_input().split(" "))
c = []
b = map(int, raw_input().split(" "))

for p in range(0, (a[0])):
    c.append(p + 1)
if a[1] == 0:
    print ' '.join(map(str, c))
else:
    for i in xrange(0, (a[1])):
        atemp = []
        for x in xrange(0, (a[0])):
            atemp.append(c[((b[x] - 1))])
        c = atemp
    print ' '.join(map(str, atemp))

