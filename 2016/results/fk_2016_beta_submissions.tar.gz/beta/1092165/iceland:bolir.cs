using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int keppendur = Convert.ToInt32(Console.ReadLine());
            List<string> keppnisbolir = new List<string>();
            List<string> bolir = new List<string>();
            List<int> tolubolir = new List<int>();
            bool fannbol = false;
            for (int i = 0; i < keppendur; i++)
            {
                keppnisbolir.AddRange(Console.ReadLine().Split(' '));
            }
            bolir.AddRange(Console.ReadLine().Split(' '));
            foreach (var s in bolir)
            {
                tolubolir.Add(Convert.ToInt32(s));
            }
            for (int i = 0; i < keppnisbolir.Count;)
            {
                for (int s = 0; s < tolubolir.Count; s++)
                {
                    if(tolubolir.Max() >= Convert.ToInt32(keppnisbolir[i]) && tolubolir.Max() <= Convert.ToInt32(keppnisbolir[i+1]))
                    {
                        tolubolir.Remove(tolubolir.Max());
                        fannbol = true;
                        break;
                    }
                    else if(tolubolir.Min() >= Convert.ToInt32(keppnisbolir[i]) && tolubolir.Min() <= Convert.ToInt32(keppnisbolir[i + 1]))
                    {
                        tolubolir.Remove(tolubolir.Min());
                        fannbol = true;
                        break;
                    }
                    else if (tolubolir[s] < Convert.ToInt32(keppnisbolir[i]) && tolubolir[s] > Convert.ToInt32(keppnisbolir[i+1]))
                    {
                        tolubolir.RemoveAt(s);
                        fannbol = true;
                        break;
                    }
                }
                if (fannbol == false)
                {
                    break;
                }
                else
                {
                    fannbol = false;
                }
                i += 2;
            }
            if (tolubolir.Count > 0)
            {
                tolubolir.Clear();
                foreach (var s in bolir)
                {
                    tolubolir.Add(Convert.ToInt32(s));
                }
                for (int i = 0; i < keppnisbolir.Count;)
                {
                    for (int s = 0; s < tolubolir.Count; s++)
                    {
                        if (tolubolir.Min() >= Convert.ToInt32(keppnisbolir[i]) && tolubolir.Min() <= Convert.ToInt32(keppnisbolir[i + 1]))
                        {
                            tolubolir.Remove(tolubolir.Max());
                            fannbol = true;
                            break;
                        }
                        else if (tolubolir.Max() >= Convert.ToInt32(keppnisbolir[i]) && tolubolir.Max() <= Convert.ToInt32(keppnisbolir[i + 1]))
                        {
                            tolubolir.Remove(tolubolir.Min());
                            fannbol = true;
                            break;
                        }
                        else if (tolubolir[s] < Convert.ToInt32(keppnisbolir[i]) && tolubolir[s] > Convert.ToInt32(keppnisbolir[i + 1]))
                        {
                            tolubolir.RemoveAt(s);
                            fannbol = true;
                            break;
                        }
                    }
                    if (fannbol == false)
                    {
                        break;
                    }
                    else
                    {
                        fannbol = false;
                    }
                    i += 2;
                }
            }
            if (tolubolir.Count == 0)
            {
                Console.WriteLine("Jebb");
            }
            else
            {
                Console.WriteLine("Neibb");
            }
            Console.ReadKey();
        }
    }
}
