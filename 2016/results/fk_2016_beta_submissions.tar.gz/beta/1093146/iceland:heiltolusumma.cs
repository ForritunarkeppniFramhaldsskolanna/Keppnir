using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backspace
{
    class Program
    {
        static void Main(string[] args)
        {
            long n, answer;
            n = long.Parse(Console.ReadLine());
            answer = (n * (n + 1)) / 2;
            Console.WriteLine( answer);
            Console.ReadKey();
        }
    }
}
