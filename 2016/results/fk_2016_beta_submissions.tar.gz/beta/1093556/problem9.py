import sys
import math

n = int(sys.stdin.readline().replace("\n", ""))

x=[]
y=[]
z=[]
r=[]

for i in range(0, n):
    j = sys.stdin.readline().replace("\n", "").split(" ")
    x.append(float(j[0]))
    y.append(float(j[1]))
    z.append(float(j[2]))
    r.append(float(j[3]))

q = int(sys.stdin.readline().replace("\n", ""))

sx=[]
sy=[]
sz=[]
sr=[]

for i in range(0, q):
    j = sys.stdin.readline().replace("\n", "").split(" ")
    sx.append(float(j[0]))
    sy.append(float(j[1]))
    sz.append(float(j[2]))
    sr.append(float(j[3]))

total = n

for i in range(0, n):
    exploded = 0
    for j in range(0, q):
        length = math.sqrt( (x[i] - sx[j])**2 + (y[i] - sy[j])**2 + (z[i] - sz[j])**2)

        if r[i] + sr[j] > length:
            exploded = 1

    if exploded == 1:
        total -= 1

print(total)
