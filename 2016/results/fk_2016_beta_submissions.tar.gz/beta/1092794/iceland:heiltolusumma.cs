using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());

            int answer = (n * (n + 1)) / 2;

            Console.WriteLine(answer);

            Console.ReadKey();
        }
    }
}
