n = int(input())
if n <= 0:
    print(0)
else:
    summa = (n * (n + 1)) // 2
    print(summa)
