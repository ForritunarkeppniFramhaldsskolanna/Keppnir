var = input("")
a = [];
talann = 0;
count = 0;
tala = int(var)
for x in range(1,tala+1):
    talann = talann + x;
for x in range(0,talann+1):
        a.insert(count,x)
        count = count + 1
print(max(a))
