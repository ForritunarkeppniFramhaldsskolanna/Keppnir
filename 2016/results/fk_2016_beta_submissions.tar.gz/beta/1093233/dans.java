import java.util.Scanner;
public class dans{
  public static void main(String[] args){
    Scanner scan = new Scanner(System.in);
    int fjoldi = scan.nextInt();
    long log = scan.nextLong();
    long[] dance = new long[fjoldi+1];
    long[] gaur = new long[fjoldi+1];
    for (long i = 1;i<=fjoldi;i++){
      dance[(int)i] = scan.nextLong();
      gaur[(int)i] = i;
    }
    scan.close();
    for (long i = 0;i<log;i++){
      for (long j = 1;j<=fjoldi;j++){
        gaur[(int)j] = dance[(int)gaur[(int)j]];
        
        
      }
    }
    for (long i = 1;i<gaur.length;i++){
      System.out.print(gaur[(int)i]+" ");
    }
    
  }
}