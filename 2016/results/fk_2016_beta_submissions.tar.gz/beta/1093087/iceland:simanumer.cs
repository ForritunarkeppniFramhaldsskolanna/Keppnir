using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberCount = Convert.ToInt32(Console.ReadLine());
            string[] numbers = new string[numberCount];

            for (int i = 0; i < numberCount; i++)
            {
                numbers[i] = Console.ReadLine();
            }

            int queryCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < queryCount; i++)
            {
                string query = Console.ReadLine();
                int queryResultCount = 0;

                for (int x = 0; x < numbers.Length; x++)
                {
                    if (numbers[x].StartsWith(query))
                    {
                        queryResultCount++;
                    }
                }

                Console.WriteLine(queryResultCount);
            }

            Console.ReadKey();
        }
    }
}
