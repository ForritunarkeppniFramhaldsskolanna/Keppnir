n = int(raw_input())
s = []
for i in range(0, n):
    s.append(raw_input())
q = int(raw_input())
for i in range(0, q):
    qq = raw_input()
    c = 0
    for e in range(0, len(s)):
        if(str(s[e]).startswith(qq)):
            c += 1
    print c
