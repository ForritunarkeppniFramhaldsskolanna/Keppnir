import sys

n = int(sys.stdin.readline().replace("\n", ""))

if n >= 0:
    print(n * (n + 1) / 2)

else:
    print(1 - abs(n) * (abs(n) + 1) / 2 )

