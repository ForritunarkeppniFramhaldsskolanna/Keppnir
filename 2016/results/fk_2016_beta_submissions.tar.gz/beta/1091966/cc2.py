import math




s = int(raw_input())
p = []

def check(g):
    _min = -1
    _max = -1
    summ = 0
    avg = -1
    counter = len(g)
    for t in range(0, len(g)):
        age = int(g[t][1])

        if _min > age or _min == -1:
            _min = age
        if _max < age or _max == -1:
            _max = age
        summ += age



    if counter <= 0:
        _min = -1
        _max = -1
        avg = -1
    else:
        avg = summ / float(counter)

    print "{0} {1} {2}".format(_min, _max, avg)


def remove(g, a):
    for q in range(0, len(g)):
        if(g[q][1] == a):
            del g[q]
            return g
def removeR(g):
    for q in range(0, len(g)):
        if(g[q][0] == "R"):
            del g[q]
            return g

for i in range(0, s):
    p.append(raw_input().split())

    for w in range(0, len(p)):
        if(p[w][0] == "R"):
            p = remove(p, p[w][1])
            p = removeR(p)
            break

    check(p)







