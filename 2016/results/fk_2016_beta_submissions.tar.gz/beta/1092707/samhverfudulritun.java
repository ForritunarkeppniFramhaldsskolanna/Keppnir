import java.math.*;
public class samhverfudulritun
{
    public static void main(String[] args)
    {
        for(int i = 0; i < 100; i++)
        {
            BigInteger tveir = BigInteger.valueOf(2);
            BigInteger k2 = tveir.pow(i);
            String n = ""+k2;
            System.out.println(n);
            String utt ="";
            String fyrst = ""+n.charAt(0);
            String sidst = ""+n.charAt(n.length()-1);
            int fy = Integer.parseInt(fyrst);
            int si = Integer.parseInt(sidst);
            boolean buid = false;
            if(fy<si)
            {
                for(int m = 0; m < n.length()-1; m++)
                    System.out.print(9);
                buid = true;
                System.out.println();
            }
            boolean niu = false;
            if(!buid)
            {
            if(n.length()%2 == 0)
            {
                for(int j = 0; j < (n.length()/2); j++)
                {
                    if(niu)
                        utt+=9;
                    String fyr = ""+n.charAt(j);
                    String sid = ""+n.charAt(n.length()-1-j);
                    int f = Integer.parseInt(fyr);
                    int s = Integer.parseInt(sid);
                    if(f>s && !niu)
                    {
                        utt+=(f-1);
                        niu = true;
                    }
                    else if(f<=s&&!niu)
                    {
                        utt+=f;
                    }
                    
                }
                for(int j = (n.length())/2-1; j>=0;j--)
                {
                    utt+=utt.charAt(j);
                }
                
            }
            else
            {
                for(int j = 0; j <= (n.length()/2)-1; j++)
                {
                    String fyr = ""+n.charAt(j);
                    String sid = ""+n.charAt(n.length()-1-j);
                    int f = Integer.parseInt(fyr);
                    int s = Integer.parseInt(sid);
                    if(f>s && !niu)
                    {
                        utt+=(f-1);
                        niu = true;
                    }
                    else if(f<=s&&!niu)
                    {
                        utt+=f;
                    }
                    if(niu)
                        utt+=9;
                }
                if(niu)
                    utt+=9;
                else
                    utt+=n.charAt((n.length())/2);
                for(int j = (n.length())/2-1; j>=0;j--)
                {
                    utt+=utt.charAt(j);
                }
                
            }
                
            /*for(int j = 0; j < (n.length()/2)+1; j++)
            {
                String fyr = ""+n.charAt(j);
                String sid = ""+n.charAt(n.length()-1-j);
                int f = Integer.parseInt(fyr);
                int s = Integer.parseInt(sid);
                utt+=Math.min(f,s);
            }
            if(n.length()%2==1)
            {
                utt+=n.charAt((n.length()/2)+1);
                for(int j = n.length()/2); j>0;j--)
            {
                utt+=utt.charAt(j);
            }
            }
            else
            {
                for(int j = n.length()/2); j>0;j--)
                {
                    utt+=utt.charAt(j);
                }
            }*/
            System.out.println(utt);
            }
        }
    }
}