using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_kóði
{
    class Basic
    {

        public class Example
        {
            public static void Main()
            {
                int tala1 = Convert.ToInt32(Console.ReadLine()), tala2;
                int[] arr = new int[tala1], arr2 = new int[tala1];
                string[] arr1 = new string[tala1];
                string stafur;
                int tala3;
                for (int i = 0; i < tala1; i++)
                {
                    String value = Console.ReadLine();
                    Char delimiter = ' ';
                    String[] substrings = value.Split(delimiter);
                    int a = 0;
                    foreach (var substring in substrings)
                    {
                        stafur = substring.ToString();
                        Console.WriteLine(stafur);
                        Console.WriteLine(substring);
                    }
                    
                    Console.ReadLine();
                    tala2 = Convert.ToInt32(arr2[2]);
                    arr[i] = tala2;
                    Console.Write(arr.Min() + " " + arr.Max() + " " + arr.Average().ToString("f2"));
                    Console.WriteLine();
                    Console.ReadLine();


                }
            }

        }

    }
    
}
