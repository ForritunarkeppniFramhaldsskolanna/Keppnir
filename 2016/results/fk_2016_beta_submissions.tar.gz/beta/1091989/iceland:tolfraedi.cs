using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            int inputCount = int.Parse(Console.ReadLine());
            List<decimal> nums = new List<decimal>();

            for (int i = 0; i < inputCount; i++)
            {
                string[] input = Console.ReadLine().Split(' ');

                if (input[0][0] == 'A')
                    nums.Add(decimal.Parse(input[1]));
                else
                    nums.Remove(decimal.Parse(input[1]));

                if (nums.Count != 0)
                    Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
                else
                    Console.WriteLine(0 + " " + 0 + " " + 0);
            }
        }
    }
}
