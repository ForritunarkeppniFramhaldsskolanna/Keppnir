using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string Res = "a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<<<<<<<<<<<<<<<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<asda<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<a<a<a<aa<<";
            char[] array = Res.ToCharArray();
            List<string> output = new List<string>();
            for (int i = 0; i < array.Length; i++)
            {
                char letter = array[i];             
                if (letter.ToString() == "<")
                {
                    if (output.Count() != 0)
                    {
                        output.Remove(output.Last());
                    }
                }
                else
                {
                    output.Add(letter.ToString());
                }
            }
            string S = string.Join("",output.ToArray());
            Console.WriteLine(S);
            Console.ReadKey();
            
        }
    }
}