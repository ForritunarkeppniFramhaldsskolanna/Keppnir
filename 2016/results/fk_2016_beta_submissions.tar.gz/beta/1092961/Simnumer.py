a = str(input())
b = []

for i in range(0, int(a)):
    b.append(str(input()))
length = int(raw_input())
c = len(b)
for x in range(0, length):
    temp = str(input())
    counter = 0
    for y in range(0, c):
        if b[y].startswith(temp):
            counter += 1
    print counter
