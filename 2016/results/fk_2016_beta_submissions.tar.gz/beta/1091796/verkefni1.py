string = input()
tala = len(string)
newstring = ""
laststring = ""
backspacedict = {}
for x in range(tala):
    if string[x] == "<":
        newstring = newstring[:-1]
    else:
        newstring += string[x]
print(newstring)