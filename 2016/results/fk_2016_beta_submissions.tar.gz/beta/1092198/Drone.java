import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * @author Alexander
 * @version 1.0
 */

public class Drone {

	public static void main(String[] args) {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			long l = Long.parseLong(br.readLine());

			long[][] d = new long[(int) l][2];
			for (long i = 0; i < l; i++) {
				String data[] = br.readLine().split(" ");
				long x = Long.parseLong(data[0]);
				long y = Long.parseLong(data[1]);
				d[(int) i] = new long[] { x, y };
			}

			long currentX = 0;
			long currentY = 0;
			double length = 0;

			long[][] dOut = new long[(int) l][2];
			long[][] dCopy2 = new long[(int) l][2];
			for (long i = 0; i < l; i++) {
				dCopy2[(int) i] = new long[] { d[(int) i][0], d[(int) i][1] };
			}

			for (long i = 0; i < l; i++) {
				length = Double.MAX_VALUE;
				long index = 0;
				for (long j = 0; j < l; j++) {
					if (d[(int) j] == null) {
						continue;
					}
					double len = getDistance(currentX, currentY, d[(int) j][0], d[(int) j][1]);
					if (length > len) {
						length = len;
						index = j;
					}
				}
				currentX = d[(int) index][0];
				currentY = d[(int) index][1];
				dOut[(int) i] = new long[] { d[(int) index][0], d[(int) index][1] };
				d[(int) index] = null;
			}

			currentX = 0;
			currentY = 0;
			length = 0;

			for (long i = 0; i < l; i++) {
				long x = dOut[(int) i][0];
				long y = dOut[(int) i][1];

				length += getDistance(currentX, currentY, x, y);
				currentX = x;
				currentY = y;
			}
			length += getDistance(currentX, currentY, 0, 0);

			System.out.println(length);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static double getDistance(long x1, long y1, long x2, long y2) {
		long x = x2 - x1;
		long y = y2 - y1;
		return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
	}

}
