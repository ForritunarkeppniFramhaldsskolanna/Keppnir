strengur = input('string input: ')
def checkMethod(line):
	new = ''
	if '<' not in line:
		return(line)
	elif '<' in line:
	    for x in range(0, len(line), 1):
	    	if line[x] != '<':
	    		new += line[x]
	    	elif line[x] == '<':
	    		better = new.replace(str(new[len(new) -1]), '')
	    		new = better
	    	elif line[x] == '<' and line[x -1] == '<':
	    		pass
	return(new)

print(checkMethod(strengur))