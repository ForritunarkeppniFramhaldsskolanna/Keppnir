tala = int(input())
summa = 0
for x in range(0,tala+1):
    summa = (summa) + (x)
print(summa)    
