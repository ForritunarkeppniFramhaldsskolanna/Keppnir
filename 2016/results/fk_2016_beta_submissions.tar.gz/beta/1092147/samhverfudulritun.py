for k in range(1, 40):
    testResult = 2**k
    for x in range(testResult):
        stringX = str(x)
        if stringX == stringX[::-1]:
            print ("%s %s" % (k, stringX))