n = int(input())
phonenumbers = []
for x in range(n):
	phonenumbers.append(input())
f = int(input())
thelen = len(phonenumbers)
for x in range(f):
	count = 0
	string = input()
	for y in range(thelen):
		if string == phonenumbers[y][:len(string)]:
				count+=1
	print(count)
