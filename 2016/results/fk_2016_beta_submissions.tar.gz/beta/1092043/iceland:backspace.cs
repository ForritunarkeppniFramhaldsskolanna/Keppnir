using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string Input = "Luf<g<v";
            char[] array = Input.ToCharArray();
            List<string> output = new List<string>();
            for (int i = 0; i < array.Length; i++)
            {
                string backspace = "<";
                char letter = array[i];
               
                if (letter.ToString() == backspace)
                {
                    output.Remove(output.Last());
                }
                else
                {
                    output.Add(letter.ToString());
                }
            }
            string End = string.Join("",output.ToArray());
            
            Console.WriteLine(End);
            Console.ReadKey();
            
        }
    }
}