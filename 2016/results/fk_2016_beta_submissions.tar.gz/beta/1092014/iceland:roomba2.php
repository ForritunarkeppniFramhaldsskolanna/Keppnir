<?php

fscanf(STDIN, '%[^\n]s', $string);

$array = explode(' ', $string);

$xhnit = $array[0];
$yhnit = $array[1];
$xtelja = 0;
$ytelja = 0;

$oddatala = 0;
$count = 1;
$space = " ";

$heild = $xhnit * $yhnit;

while ($count < $heild) {

  if ($oddatala == 0 && $count != $heild) {

    if ($ytelja < $yhnit) {
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);
      if ($ytelja == $yhnit - 1 && $count != $heild) {
        $oddatala = 1;
        $xtelja++;
      }
      else {
      $ytelja++;
      }
      $count++;
    }

  }

  if ($oddatala == 1 && $count != $heild) {
    if ($ytelja >= 0) {
      fprintf(STDOUT, "%s", $xtelja);
      fprintf(STDOUT, "%s", $space);
      fprintf(STDOUT, "%s\n", $ytelja);
      if ($ytelja == 0 && $count != $heild) {
        $oddatala = 0;
        $xtelja++;
      }
      else {
      $ytelja--;
      }
      $count++;
    }

  }


}

while ($count == $heild) {
  if ($ytelja > 0) {
    fprintf(STDOUT, "%s", $xtelja);
    fprintf(STDOUT, "%s", $space);
    fprintf(STDOUT, "%s\n", $ytelja);
    $ytelja--;
  }

  if ($ytelja == 0 && $xtelja >= 0) {
    fprintf(STDOUT, "%s", $xtelja);
    fprintf(STDOUT, "%s", $space);
    fprintf(STDOUT, "%s\n", $ytelja);
    $xtelja--;
    if ($ytelja==0 && $xtelja == -1) {
      exit();
    }
  }

}





?>