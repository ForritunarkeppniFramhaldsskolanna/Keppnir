<script type="text/javascript">

            var y
            var x = "fun<asd<"
            for (var i = 0; i <x.length; i++) {
                if (x[i]=='<') {
                    console.log('< hér')
                }
                else {
                    y += x[i]
                }
            }
            console.log(y)



        </script>