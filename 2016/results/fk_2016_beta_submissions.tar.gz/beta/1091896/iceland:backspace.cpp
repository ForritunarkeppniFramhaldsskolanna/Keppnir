#include <iostream>
#include <string>
using namespace std;
int main(){
	string inthing;
	cin >> inthing;
	for (long i = 0; i < inthing.length(); ++i)
	{
		if (inthing[i] == '<')
		{
			inthing.erase(i -1, 2);
			i -= 2;
		}
	}
	cout << inthing << endl;
}