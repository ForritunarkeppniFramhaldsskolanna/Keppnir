using System;
class Ship{
	public int X,Y,Z,r;
	public bool isDed = false;
	public Ship(int x,int y, int z,int R){
		X = x;
		Y = y;
		Z = z;
		r = R;
	}
	public bool isTouching(Ship thing){
		int distX = (this.X-thing.X);
		int distY = (this.Y-thing.Y);
		int distZ = (this.Z-thing.Z);
		double dist = Math.Sqrt((distX * distX) + (distY * distY) + (distZ*distZ));
		if(dist <= (this.r + thing.r)){
			//if(distZ <= (this.r + thing.r)){
				return true;
			//}
			//else{
			//	return false;
			//}
		}
		else{
			return false;
		}
	}
}
class fleet{
	static void Main(){
		int input1 = Convert.ToInt32(Console.ReadLine());
		int aliveCount = input1;
		string[] input1Array = new string[input1];
		string[] temp = new string[4];
		Ship[] skip = new Ship[input1];
		for(int i = 0; i<input1; i++){
			input1Array[i] = Console.ReadLine();
		}
		for(int a = 0; a<input1; a++){
				temp = input1Array[a].Split(' ');
				skip[a] = new Ship(Convert.ToInt32(temp[0]),Convert.ToInt32(temp[1]),Convert.ToInt32(temp[2]),Convert.ToInt32(temp[3]));
		}
		int input2 = Convert.ToInt32(Console.ReadLine());
		string[] input2Array = new string[input2];
		string[] temp2 = new string[4];
		Ship[] skip2 = new Ship[input2];
		for(int I = 0; I<input2; I++){
			input2Array[I] = Console.ReadLine();
		}
		for(int b = 0; b<input2; b++){
				temp2 = input2Array[b].Split(' ');
				skip2[b] = new Ship(Convert.ToInt32(temp2[0]),Convert.ToInt32(temp2[1]),Convert.ToInt32(temp2[2]),Convert.ToInt32(temp2[3]));
		}
		for(int A = 0; A<input1; A++){
			for(int B = 0; B<input2; B++){
				if(skip[A].isTouching(skip2[B])){
					skip[A].isDed = true;
					aliveCount --;
				}
			}
		}
		Console.WriteLine(aliveCount);
	}
}