n = int(input())
al = input().split()
string = ""
for x in range(len(al)):
	string += al[x]
numbers = []
thewhole = 0
for x in range(len(string)):
	if string[x] == '1':
		thewhole += 1
for x in range(1,n):
	for y in range(0,(n+1)-x):
		count = thewhole
		for z in range(y,x+y):
			if string[z] == '1':
				count -= 1
			else:
				count += 1
		numbers.append(count)
print(max(numbers))
				