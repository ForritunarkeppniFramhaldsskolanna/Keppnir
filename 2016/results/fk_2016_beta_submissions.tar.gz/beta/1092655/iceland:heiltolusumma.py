N= int(input())

def gauss(num):
	sum = num
	for x in range(0,num,1):
		sum += x
	return sum
if N<1:
	print(0)
else:
	print(gauss(N))