using System;
class samhverfudulritun{
	static void Main(){
		long temp = 0;
		for(int I = 1; I<101; I++){
			temp = Convert.ToInt64(Math.Pow(2L,I));
			if(erSamhverf(temp)){
				Console.WriteLine(I + " " + Math.Pow(2L,I));
			}
		}
	}
	static bool erSamhverf(long inn){
		string input = Convert.ToString(inn);
		string output = null;
		for(int i = input.Length; i>0; i--){
			output += input[i-1];
		}
		if(output.Equals(input)){
			return true;
		}
		else{
			return false;
		}
	}
}
