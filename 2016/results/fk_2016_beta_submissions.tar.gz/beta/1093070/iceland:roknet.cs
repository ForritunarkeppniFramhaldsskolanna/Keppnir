using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace roknet
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, bool> input = new Dictionary<string, bool>();
            Dictionary<string, bool> output = new Dictionary<string, bool>();

            int num = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < num; i++)
            {
                string[] temp = Console.ReadLine().Split(' ');
                if (temp[0] == "INNTAK")
                {
                    bool tempbool;
                    if (temp[2] == "SATT")
                    {
                        tempbool = true;
                    }
                    else
                    {
                        tempbool = false;
                    }
                    input.Add(temp[1], tempbool);
                }
                if (temp[0] == "UTTAK")
                {
                    if (input[temp[1]])
                    {
                        Console.WriteLine(temp[1] + " " + "SATT");
                    }
                    else
                    {
                        Console.WriteLine(temp[1] + " " + "OSATT");
                    }
                }
                if (temp[0] == "OG")
                {
                    bool tempbool1;
                    bool tempbool2;
                    if (input[temp[2]])
                    {
                        tempbool1 = true;
                    }
                    else
                    {
                        tempbool1 = false;
                    }
                    if (input[temp[1]])
                    {
                        tempbool2 = true;
                    }
                    else
                    {
                        tempbool2 = false;
                    }
                    input.Add(temp[3], tempbool1 && tempbool2);
                }
                if (temp[0] == "EDA")
                {
                    bool tempbool1;
                    bool tempbool2;
                    if (input[temp[2]])
                    {
                        tempbool1 = true;
                    }
                    else
                    {
                        tempbool1 = false;
                    }
                    if (input[temp[1]])
                    {
                        tempbool2 = true;
                    }
                    else
                    {
                        tempbool2 = false;
                    }
                    input.Add(temp[3], tempbool1 || tempbool2);
                }
                if (temp[0] == "EKKI")
                {
                    bool tempbool1;
                    if (input[temp[1]])
                    {
                        tempbool1 = true;
                    }
                    else
                    {
                        tempbool1 = false;
                    }
                    input.Add(temp[2], !tempbool1);
                }
            }
            Console.ReadKey();

        }
    }
}
