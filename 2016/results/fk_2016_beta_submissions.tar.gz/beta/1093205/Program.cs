using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forkep2016B
{
    class Program
    {
        static void Main(string[] args)
        {
            int r = 0, d = 0;
            Console.WriteLine("write in 2 numbers");
            r = Math.Abs(Convert.ToInt32(Console.ReadLine()));
            d = Math.Abs(Convert.ToInt32(Console.ReadLine()));
            Console.Clear();
            r--;
            d--;
            int R = r, D = d;
            for (int i = 0; i <= r; i++)
            {
                for (int y = 0; y <= d; y++)
                {
                    if (i % 2 == 0)
                    {
                        Console.Write(i + " " + y + "\n");
                    }
                    else if (i % 2 != 0)
                    {
                        Console.Write(i + " " + D + "\n");
                        --D;
                    }
                    if (i == r && y == d)
                    {
                        r--;
                        for (int x = r; x >= 0; x--)
                        {
                            Console.Write(x + " 0\n");
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
