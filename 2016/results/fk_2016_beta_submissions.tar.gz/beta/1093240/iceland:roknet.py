import sys

N = int(sys.stdin.readline())

vars = []
varsNames = []
wantedOut = []

for i in range(0, N):
    temp = sys.stdin.readline().rstrip()
    temp = temp.split()
    if temp[0] == "INNTAK":
        if temp[2] == "SATT":
            vars.append(True)
            varsNames.append(temp[1])
        elif temp[2] == "OSATT":
            vars.append(False)
            varsNames.append(temp[1])
    elif temp[0] == "UTTAK":
        wantedOut.append(temp[1])
    elif temp[0] == "OG":
        vars.append(vars[varsNames.index(temp[1])] and vars[varsNames.index(temp[2])])
        varsNames.append(temp[3])
    elif temp[0] == "EDA":
        vars.append(vars[varsNames.index(temp[1])] or vars[varsNames.index(temp[2])])
        varsNames.append(temp[3])
    elif temp[0] == "EKKI":
        vars.append(not vars[varsNames.index(temp[1])])
        varsNames.append(temp[2])

counter = 0

for i in wantedOut:
    if vars[counter]:
        print(str(i) + " SATT")
    elif not vars[counter]:
        print(str(i) + " OSATT")
    counter += 1
