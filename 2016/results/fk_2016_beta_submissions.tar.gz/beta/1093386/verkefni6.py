tala = int(input())
summa = (tala*(tala + 1))/2

if tala > 0:
    print(round(summa))
else:
    print((-1 * round(summa)) + 1)