number = int(raw_input())

gates = []
to_print = []

def find_inntak(name):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            return x[1], x[2]
    return ""

def replace_inntak(name, value):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            x[1] = name
            x[2] = value

def find_value(name):
    for x in gates:
        if x[0] == "INNTAK" and x[1] == name:
            return x[2]

for x in range(0, number):
    thing = raw_input().split()

    if thing[0] == "UTTAK":
        to_print.append(find_inntak(thing[1]))
    elif thing[0] == "EKKI":
        value = find_value(thing[1])
        if value == "SATT":
            gates.append(["INNTAK", thing[2], "OSATT"])
        else:
            gates.append(["INNTAK", thing[2], "SATT"])
    elif thing[0] == "EDA":
        value = find_value(thing[1])
        value1 = find_value(thing[2])

        if value == "SATT" or value1 == "SATT":
            gates.append(["INNTAK", thing[3], "SATT"])
        else:
            gates.append(["INNTAK", thing[3], "OSATT"])
    elif thing[0] == "OG":
        value = find_value(thing[1])
        value1 = find_value(thing[2])

        if value == "SATT" and value1 == "SATT":
            gates.append(["INNTAK", thing[3], "SATT"])
        else:
            gates.append(["INNTAK", thing[3], "OSATT"])
    else:
        replace_inntak(thing[1], thing[2])
        gates.append(thing)

for x in to_print:
    print x[0], x[1]