def reverseish(A,B):
    if len(A) % 2 == 0:
        addender = int(len(A) / 2)
        stringPart = str(int(A[0:addender]) - int(B))
        revAddender = stringPart[::-1]
        return stringPart + revAddender
    else:
        addender = int((len(A) + 1) / 2)
        stringPart = str(int(A[0:addender]) - int(B))
        revAddender = stringPart[::-1]
        return stringPart + revAddender[1:]

for i in range(1, 101):
    palindrFound = 0
    currentCheck = 2**i

    temp = str(currentCheck)
    shiet = 0

    while not palindrFound:
        possPalindr = int(reverseish(str(currentCheck), shiet))
        if possPalindr <= currentCheck:
            print(possPalindr)
            palindrFound = 1
        else:
            shiet += 1