import math

hversuoft = input()
aldurlisti = []
output = ""
answerlist = []
for x in range(int(hversuoft)):
    strengur,tala = input().split()
    if(strengur == "A"):
        aldurlisti.append(int(tala))
        output = str(min(aldurlisti)) + " "
        output += str(max(aldurlisti)) + " "
        if(sum(aldurlisti)/len(aldurlisti) - round(sum(aldurlisti)/len(aldurlisti) > 0)):
            if(len(str(sum(aldurlisti)/len(aldurlisti)).split(".")[1]) > 6):
                output += str(sum(aldurlisti)/len(aldurlisti)).split(".")[0] + "." + str(sum(aldurlisti)/len(aldurlisti)).split(".")[1][:6]
            else:
                output += str(sum(aldurlisti)/len(aldurlisti))
        else:
            output += str(sum(aldurlisti)/len(aldurlisti))

    if(strengur == "R"):
        aldurlisti.remove(int(tala))
        output = str(min(aldurlisti)) + " " + str(max(aldurlisti)) + " "
        if(sum(aldurlisti)/len(aldurlisti) - round(sum(aldurlisti)/len(aldurlisti) > 0)):
            if(len(str(sum(aldurlisti)/len(aldurlisti)).split(".")[1]) > 6):
                output += str(sum(aldurlisti)/len(aldurlisti)).split(".")[0]+ "." + str(sum(aldurlisti)/len(aldurlisti)).split(".")[1][:6]
            else:
                output += str(sum(aldurlisti)/len(aldurlisti))
        else:
            output += str(sum(aldurlisti)/len(aldurlisti))

    if(len(aldurlisti) == 0):
        answerlist.append("-1," + "-1," +"-1")
    else:
        answerlist.append(output)
for x in range(len(answerlist)):
    print(answerlist[x])