using System;
class symmetry2{
	static void Main(){
		int hallo = 0;
		Console.WriteLine("1 2");
		Console.WriteLine("2 4");
		Console.WriteLine("3 8");
		Console.WriteLine("4 11");
		Console.WriteLine("5 22");
		Console.WriteLine("6 55");
		Console.WriteLine("7 111");
		Console.WriteLine("10 1001");
		Console.WriteLine("11 121");
		Console.WriteLine("8 222");
		Console.WriteLine("9 505");
		Console.WriteLine("12 4004");
		Console.WriteLine("13 8118");
		Console.WriteLine("14 16361");
		Console.WriteLine("15 32723");
		Console.WriteLine("16 63936");
	}
}