tala = int(input())
summa = (tala**2 + 1)/2

if tala > 0:
    print(summa)
else:
    print(0)