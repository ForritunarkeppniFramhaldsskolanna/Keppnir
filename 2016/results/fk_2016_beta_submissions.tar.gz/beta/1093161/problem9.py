import sys
import math

n = int(sys.stdin.readline().replace("\n", ""))

x=[]
y=[]
z=[]
r=[]

for i in range(0, n):
    j = sys.stdin.readline().replace("\n", "").split(" ")
    x.append(int(j[0]))
    y.append(int(j[1]))
    z.append(int(j[2]))
    r.append(int(j[3]))

q = int(sys.stdin.readline().replace("\n", ""))

sx=[]
sy=[]
sz=[]
sr=[]

for i in range(0, q):
    j = sys.stdin.readline().replace("\n", "").split(" ")
    sx.append(int(j[0]))
    sy.append(int(j[1]))
    sz.append(int(j[2]))
    sr.append(int(j[3]))

total = 0

for i in range(0, n):
    for j in range(0, q):
        length = math.sqrt( (x[i] - sx[j])**2 + (y[i] - sy[j])**2 + (z[i] - sz[j])**2)

        if r[i] + sr[j] > length:
            total += 1

print(n-total)
