people = []
numbers = []
input_amount = input()
people1 = ""
numbers1 = ""
for index in range(int(input_amount)):
    people1, numbers1 = input().split()

    if str(people1).lower() == "r":
        if int(numbers1) in numbers:
            numbers.remove(int(numbers1))
    elif people1 == "A":
        people.append(people1)
        numbers.append(int(numbers1))
    if not numbers:
        print ("-1 -1 -1")
    else:
        rounded = float(sum(numbers))/len(numbers)
        rounded = round(rounded, 6)
        print (min(numbers), max(numbers), rounded)


