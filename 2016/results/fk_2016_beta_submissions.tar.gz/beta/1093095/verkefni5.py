import math

hversumorgskip = int(input())
skipinfo = []
for x in range(hversumorgskip):
    skipinfo.append(input())
hversumargarsprengjur = int(input())
sprengjuinfo = []
for x in range(hversumargarsprengjur):
    sprengjuinfo.append(input())

survivalcount = 0

for x in range(len(skipinfo)):
    dead = False
    for y in range(len(sprengjuinfo)):

        sumradius = int(skipinfo[x].split()[3]) - int(sprengjuinfo[y].split()[3])
        xVigur = int(skipinfo[x].split()[0]) - int(sprengjuinfo[y].split()[0])
        yVigur = int(skipinfo[x].split()[1]) - int(sprengjuinfo[y].split()[1])
        zVigur = int(skipinfo[x].split()[2]) - int(sprengjuinfo[y].split()[2])

        vigurMilliKula = math.sqrt(abs((xVigur**xVigur) + (yVigur**yVigur) + (zVigur**zVigur)))

        if vigurMilliKula < sumradius:
            dead = True
    if not dead:
        survivalcount += 1
print(survivalcount)
