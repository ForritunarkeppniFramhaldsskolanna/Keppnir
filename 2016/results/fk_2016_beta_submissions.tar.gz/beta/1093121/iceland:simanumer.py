n = int(input())

simanumer = []
for x in range(n):
    simanumer.append(input())

queries = []
q = int(input())
for j in range(q):
    queries.append(input())

for query in queries:
    sum = 0
    for simi in simanumer:
        if query == simi[:len(query)]:
            sum += 1
    print(sum)