using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static void Main(string[] args)
        {
            long n = Convert.ToInt64(Console.ReadLine());

            long answer = (Math.Abs(n) * (Math.Abs(n) + 1)) / 2;

            if (n =< 0)
            {
                answer = 0;
            }

            Console.WriteLine(answer);

            Console.ReadKey();
        }
    }
}