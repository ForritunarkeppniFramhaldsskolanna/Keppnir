import java.util.*;
public class roomba
{
  public static void main(String[] args)
  {
    System.out.println(0 + " " + 0);
    Scanner sc = new Scanner(System.in);
    String radirs = sc.nextLine();
    int radir = Integer.parseInt(radirs);
    String dalkars = sc.nextLine();
    int dalkar = Integer.parseInt(dalkars);
    boolean radirslett = false;
    boolean dalkarslett = false;
    boolean slett = true;
    if((dalkar%2) == 0)
      dalkarslett = true;
    if((radir%2) == 0)
      radirslett = true;
    int k=0;
    if(radirslett)
    {
      
      if(k<(radir-1))
      {
        
      }
      else if(k==(radir-1))
      {
        
      }
    }
    else if(radirslett)
    {
    }
    else
    {
    }
    System.out.println(0 + " " + 0);
  }
}