#include <iostream>
using namespace std;

int main(){
int tala;
cout << "";
cin >> tala;
int talann = 0;
for(int i = 1; i <= tala;i++){
talann = talann + i;

}
cout << talann;
return 0;
}
