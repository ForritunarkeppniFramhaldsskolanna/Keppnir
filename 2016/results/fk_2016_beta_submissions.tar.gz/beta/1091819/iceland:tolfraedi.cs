using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FK16
{
    class Program
    {
        static void Main(string[] args)
        {
            int inputCount = int.Parse(Console.ReadLine());
            List<int> nums = new List<int>();

            for (int i = 0; i < inputCount; i++)
            {
                string[] input = Console.ReadLine().Split(' ');

                if (input[0] == "A")
                    nums.Add(int.Parse(input[1]));
                else if (input[0] == "R")
                    nums.Remove(int.Parse(input[1]));

                Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
            }

            Console.ReadKey();
        }
    }
}
