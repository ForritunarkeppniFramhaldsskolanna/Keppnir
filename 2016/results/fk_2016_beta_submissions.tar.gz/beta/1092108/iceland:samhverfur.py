import math

for x in range(1, 101):
    for y in range(int(math.pow(2, x)), 1, -1):
        st = str(y)
        le = len(st)
        if le % 2 == 0 and st[:int(le/2)] == st[int(le/2):][::-1]:
            print(x, y)
            break