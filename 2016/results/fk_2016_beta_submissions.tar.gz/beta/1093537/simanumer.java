import java.util.*;

public class simanumer{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    int fjoldi = Integer.parseInt(sc.nextLine());
    int[] numer =  new int[fjoldi];
    for( int i = 0; i < fjoldi; i++ ){
      numer[i] = Integer.parseInt(sc.nextLine());
    }
    numer = sort(numer);
    int fjoldifyr = Integer.parseInt(sc.nextLine());
    for( int i = 0; i < fjoldifyr; i++ ){
      int N = Integer.parseInt(sc.nextLine());
      int l = (int) (Math.log(N)/Math.log(10)) + 1;
      int k = fjoldi/2; 
      int bil = fjoldi/2;
      int j = 0;
      while( (fyrstu( numer[k], l ) != N) && bil!=0 ) {
        if( fyrstu( numer[k], l ) < N ){
          bil/=2;
          k+= bil;
        }
        else{
          bil/=2;
          k -= bil;
        }
      }
      if( fyrstu(numer[k], l) >= N ){
        while( k-1 >= 0 && fyrstu(numer[k-1], l) >= N  ){
          k--;
        }
      }
      else{
        while( k < fjoldi && fyrstu(numer[k],l) < N ){
          k++;
        }
      }
      while( k+j < fjoldi && (fyrstu( numer[k+j], l ) == N ) ){
        j++;
      }
      System.out.println(j);
    }
  }
  public static int[] sort(int[] a)
  {
    int[] b = new int[a.length];
    if(a.length == 1)
    {
      b[0] = a[0];
      return b;
    }
    else if(a.length == 2)
    {
      b[0] = Math.min(a[0], a[1]);
      b[1] = Math.max(a[0], a[1]);
      return b;
    }
    else
    {
      int[] c = new int[a.length/2];
      int[] d = new int[a.length - c.length];
      for(int i = 0; i<a.length; i++)
      {
        if(i < c.length)
          c[i] = a[i];
        else
          d[i-c.length] = a[i];
      }
      int[] sc = sort(c);
      int[] sd = sort(d);
      return merge(sc, sd);
    }
  }
  public static int[] merge(int[] a, int[] b)
  {
    int[] c = new int[a.length+b.length];
    int s = 0;
    int r = 0;
    for(int i = 0; i < a.length+b.length; i++)
    {
      if(r < b.length && s < a.length)
      {
        if(a[s] < b[r])
        {
          c[i] = a[s];
          s++;
        }
        else if(a[s] >= b[r])
        {
          c[i] = b[r];
          r++;
        }
      }
      else
      {
        if(r == b.length)
        {
          c[i] = a[s];
          s++;
        }
        else
        {
          c[i] = b[r];
          r++;
        }
      }
    }
    return c;
  }
  static int fyrstu( int a, int l ){
    for( int i = 0; i < 7-l; i++ ){
      a/=10;
    }
    return a;
  }
}
