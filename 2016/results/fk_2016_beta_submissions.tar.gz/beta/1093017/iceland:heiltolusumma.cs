using System;

namespace forritun
{
    class Program
    {
        static void Main()
        {
            long n = long.Parse(Console.ReadLine());
            Console.WriteLine(talasum(n));

            Console.ReadKey();
        }

        static long talasum(long n)
        {
            if(n < 0)
            {
                return ((((n*-1) * (n*-1 + 1)) / 2) * -1) + (n * -1);
            }
            else
            {
                return (n * (n + 1)) / 2;
            }
        }
    }
}