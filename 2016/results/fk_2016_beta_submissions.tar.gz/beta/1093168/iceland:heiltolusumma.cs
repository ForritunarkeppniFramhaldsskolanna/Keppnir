int tala = Convert.ToInt32(Console.ReadLine());
            int svar = 0;
            for (int i = 1; i <= tala; i++)
            {
                svar = svar + i;
                Console.Write(i + " + ");
            }
            Console.WriteLine(" = " + svar);
            Console.ReadLine();