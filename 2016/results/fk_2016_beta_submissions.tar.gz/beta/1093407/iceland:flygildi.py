def main():
    import sys
    from math import sqrt

    def countY(cList):
        counter = 0
        now = 0
        for x in cList:
            diff = abs(now - x)
            counter += diff
            now = x
        return counter

    def sortBoth(cList, now, list):
        sortedd = list
        for hnit in cList:
            if "first" not in locals():
                first = hnit
            else:
                if sqrt((hnit[0] - now[0])**2 + (hnit[1] - now[1])**2) < sqrt((first[0] - now[0])**2 + (first[1] - now[1])**2):
                    first = hnit
        now = first
        sortedd.append(first)
        cList.pop(cList.index(first))
        if len(cList) == 0:
            return sortedd
        else:
            sortedd = sortBoth(cList, now, list)
            return sortedd

    def countBoth(cList):
        counter = 0
        for x in range(len(cList) - 1):
            counter += sqrt((cList[x][0] - cList[x+1][0])**2 + (cList[x][1] - cList[x+1][1])**2)
        return counter


    way = []
    for line in sys.stdin:
        line = line.strip()
        if "ñ" not in locals():
            ñ = line
        else:
            line = line.split(" ")
            if int(ñ) > 8:
                way.append(float(line[1]))
            else:
                way.append([float(line[0]),float(line[1])])

    if int(ñ) > 8:
        way.sort(key=float)
        way.insert(-1, 0)
        print(countY(way))
    else:
        way = sortBoth(way, [0,0], [])
        way.insert(0, [0,0])
        way.insert(len(way), [0,0])
        print(countBoth(way))








main()