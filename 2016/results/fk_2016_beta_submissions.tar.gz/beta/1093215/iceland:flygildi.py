def main():
    import sys

    def count(cList):
        counter = 0
        now = 0
        for x in cList:
            diff = abs(now - x)
            counter += diff
            now = x
        return counter


    way = []
    for line in sys.stdin:
        line = line.strip()
        if "ñ" not in locals():
            ñ = line
        else:
            line = line.split(" ")
            way.append(float(line[1]))
    way.sort(key=float)
    way.insert(-1, 0)
    print(count(way))








main()