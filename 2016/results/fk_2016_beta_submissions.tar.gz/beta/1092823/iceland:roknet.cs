using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eftirhadegi
{
    class Program
    {
        static void Main(string[] args)
        {
            var inntak = new Dictionary<string, string>();
            var uttak = new List<string>();
            var OG = new Dictionary<string, string>();
            var EDA = new Dictionary<string, string>();
            var EKKI = new List<string>();
            var slattur = new List<string>();
            int fjoldi = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < fjoldi; i++)
            {
                slattur.AddRange(Console.ReadLine().Split(' '));
                if (slattur[0].ToUpper() == "INNTAK")
                {
                    inntak.Add(slattur[1], slattur[2]);
                }
                else if(slattur[0].ToUpper() == "UTTAK")
                {
                    uttak.Add(slattur[1]);
                }
                else if(slattur[0].ToUpper() == "OG")
                {
                    OG.Add(slattur[1], slattur[2]);
                }
                else if(slattur[0].ToUpper() == "EDA")
                {
                    EDA.Add(slattur[1], slattur[2]);
                }
                else if(slattur[0].ToUpper() == "EKKI")
                {
                    EKKI.Add(slattur[1]);
                }
                slattur.Clear();
            }
            foreach (var s in uttak)
            {
                if (inntak.ContainsKey(s))
                {
                    Console.WriteLine(s + " " + inntak[s]);
                }
            }
            Console.ReadKey();
        }
    }
}
