#include <iostream>
#include <string>
#include  <algorithm>
using namespace std;
int main() {
	string s;
	cin >> s;
	string news = "";
	size_t c = count(s.begin(), s.end(), '<');
	if (c*2 >= s.length())
	{
		cout << "" <<  endl;
	}else {
		for (int i = 0; i < s.length(); ++i)
		{
			if (s[i] != '<')
			{
				news += s[i];
			}
			else {
				news = news.substr(0,news.length()-1);
			}
		}
		cout << news << endl;
	}
}