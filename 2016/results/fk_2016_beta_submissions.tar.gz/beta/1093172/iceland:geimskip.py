import math

n = int(input())

enemies = []
for i in range(n):
    x, y, z, r = [int(l) for l in input().split()]
    enemies.append((x, y, z, r))
# my bombs
m = int(input())

alive = len(enemies)
for j in range(m):
    x1, y1, z1, r1 = [int(l) for l in input().split()]
    for enemy in enemies:
        if enemy:
            pass
        elif math.pow(enemy[0], 2) + math.pow(enemy[0], 2) + math.pow(enemy[0], 2) <= math.pow(math.pi, 2):
            print("BLOWN UP")
            enemy = False
            alive -= 1
print(alive)