num = int(input())
su = 0
if num < 0:
	for x in range(num,(num*-1)+1):
		su += x
else:
	for x in range(num+1):
		su += x
print(su)