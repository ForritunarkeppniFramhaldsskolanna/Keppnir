int Q = int.Parse(Console.ReadLine());
            List<int> nums = new List<int>();

            for (int i = 0; i < Q; i++)
            {
                string[] input = Console.ReadLine().Split(' ');
                
                char InpChar = input[0][0];
                int inp1 = int.Parse(input[1]);

                if (InpChar == 'A')
                {
                    nums.Add(inp1);
                }
                else if (InpChar == 'R')
                {
                    nums.Remove(inp1);
                }

                    if (nums.Count > 0)
                        Console.WriteLine(nums.Min() + " " + nums.Max() + " " + nums.Average());
                    else
                        Console.WriteLine((-1) + " " + (-1) + " " + (-1));
            }