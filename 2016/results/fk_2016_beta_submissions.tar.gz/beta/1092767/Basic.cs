using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_A_Backspace
{
    class Program
    {
        static void Main(string[] args)
        {


            

            String value = Console.ReadLine();
            int tala1 = 1;
            string[] a = value.Select(c => c.ToString()).ToArray();
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != "<")
                {
                    tala1 = 1;
                }
                if (i > 0 && a[i] == "<")
                {
                    
                    a[i] = null;
                    a[i - tala1] = null;
                    tala1 = tala1 + 2;
                    
                    
                }
                
                
            }
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != null)
                {
                    Console.Write(a[i]);
                }
                
            }
            Console.Read();


           







        }
    }
}