r, d = map(int, raw_input().split())

number = 0
print 0, 0
if d % 2 == 1:
    for x in range(0, r - 2):
        if number % 2 == 0:
            number += 1
            for i in range(1, d):
                print x, i
        else:
            number += 1
            for i in range(d - 1, 0, -1):
                print x, i
    number = 0
    for x in range(d-1, -1, -1):
        if number % 2 == 0:
            number += 1
            for i in range(r-2, r):
                print x, i
        else:
            number += 1
            for i in range(r-1, r-3, -1):
                print x, i

    for x in range(r-2, -1, -1):
        print 0, x

else:
    for i in range(0, d):
        if number % 2 == 0:
            number += 1
            for x in range(1, r):
                print x, i
        else:
            number += 1
            for x in range(r-1, 0, -1):
                print x, i

    for x in range(r-1, -1, -1):
        print 0, x