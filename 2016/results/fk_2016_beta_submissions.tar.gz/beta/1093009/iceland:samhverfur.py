import math

for x in range(0,101):
    tempNum = math.pow(2, x)
    tempBiggest = 0
    for y in range(int(tempNum),0,-1):
        if str(y) == str(y)[::-1]:
            if tempBiggest < y:
                tempBiggest = y
                break
    print(str(x) + " " + str(tempBiggest))
    
