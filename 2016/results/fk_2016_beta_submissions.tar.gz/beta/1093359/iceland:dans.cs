using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dans
{
    class Program
    {
        static void Main(string[] args)
        {
            string rusl = Console.ReadLine();
            int num = Convert.ToInt32(rusl.Split(' ')[0]);
            int rounds = Convert.ToInt32(rusl.Split(' ')[1]);
            int[] pattern = new int[num];
            int[] position = new int[num];
            int[] tempposition = new int[num];
            string rusl2 = Console.ReadLine();
            for (int i = 0; i < num; i++)
            {
                pattern[i] = Convert.ToInt32(rusl2.Split(' ')[i]) - 1;
                position[i] = i+1;
            }
            for (int i = 0; i < rounds; i++)
            {
                for (int j = 0; j < num; j++)
                {

                    tempposition[j] = pattern[position[j]-1]+1;
                }
                position = tempposition;
            }
            for (int i = 0; i < num; i++)
            {
                Console.Write(position[i] + " ");
            }
            Console.ReadKey();
        }
    }
}
