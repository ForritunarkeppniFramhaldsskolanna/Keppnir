n = int(input())
summa = 0

for o in range(1, n + 1):
    print(o)
    summa += o
print(summa)