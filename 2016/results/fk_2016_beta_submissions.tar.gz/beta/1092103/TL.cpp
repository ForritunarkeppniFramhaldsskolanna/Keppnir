#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>

using namespace std;

int main()
{
	int n = 0;
	double l = 0;
	int b = 0;
	int f = 0;

	cin >> n;
	vector<int> a((n * 2)+4);
	a[0] = 0;
	a[1] = 0;
	a[n - 2] = 0;
	a[n - 1] = 0;

	int count = 2;
	for (int i = 2; i < n+2; i++)
	{
		cin >> b >> f;
		a[count] = b;
		count++;
		a[count] = f;
		count++;
	}
	
	for (int i = 1; i < n; i++)
	{
		l += (a[i] - a[i + 3]) + (a[i + 1] - a[i + 2]);
		i += 4;
	}

	cout << abs(l);

}
