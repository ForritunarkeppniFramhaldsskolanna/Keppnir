using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace heiltolusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            long inp = Convert.ToInt32(Console.ReadLine());
            long svar = 0;
            if (inp >= 0)
            {
                for (long i = 1; i < inp + 1; i++)
                {
                    svar += i;
                }
            }
            else
            {
                for (long i = inp; i <= 0 + 1; i++)
                {
                    svar += i;
                }

            }
            Console.WriteLine(svar);
            Console.ReadKey();
        }
    }
}
