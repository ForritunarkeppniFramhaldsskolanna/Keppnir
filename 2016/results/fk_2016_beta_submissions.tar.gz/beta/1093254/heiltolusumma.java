import java.util.Scanner;

public class heiltolusumma {
public static void main(String[] args){
	Scanner in=new Scanner(System.in);
	long byrjun= in.nextLong();
    long summa=(Math.abs(byrjun)*(Math.abs(byrjun)+1))/2;
	if(byrjun<0)
		summa=summa*(-1)+1;
	System.out.println(summa);
}
}