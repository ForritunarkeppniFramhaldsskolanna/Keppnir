using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static int countScore(string input)
        {
            int score = 0;
            for (int x = 0; x < input.Length; x++)
            {
                if (input[x] == '1')
                {
                    score++;
                }
            }
            return score;
        }

        static string flipRange(string input, int flipStart, int flipEnd)
        {
            string newString = "";

            for (int i = 0; i < input.Length; i++)
            {
                if (i >= flipStart && i <= flipEnd)
                {
                    if (input[i] == '0')
                    {
                        newString += "1";
                    }
                    else
                    {
                        newString += "0";
                    }
                }
                else
                {
                    newString += input[i];
                }
            }

            return newString;
        }

        static void Main(string[] args)
        {
            int inputLength = Convert.ToInt32(Console.ReadLine());
            string bits = Console.ReadLine();

            bits = Regex.Replace(bits, @"\s+", "");

            int bestString = 0;

            for (int i = 0; i < bits.Length; i++)
            {
                for (int x = i; x < bits.Length; x++)
                {
                    //Console.WriteLine(flipRange(bits, i, x));
                    bestString = Math.Max(countScore(flipRange(bits, i, x)), bestString);
                }
            }

            //string thatString = flipRange(bits, 0, 0);
            //Console.WriteLine(thatString);

            //Console.WriteLine(countScore(thatString));

            Console.WriteLine(bestString);

            Console.ReadKey();
        }
    }
}
