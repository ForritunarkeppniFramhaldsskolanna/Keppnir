using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forkep2016B
{
    class Program
    {
        static void Main(string[] args)
        {
            int r = 0, d = 0;
            Console.WriteLine("write in 2 numbers");
            r = Math.Abs(Convert.ToInt32(Console.ReadLine()));
            d = Math.Abs(Convert.ToInt32(Console.ReadLine()));
            Console.Clear();
            for (int i = 0; i < r; i++)
            {
                for (int y = 0; y < d; y++)
                {
                    Console.Write(i + " " + y + "\n");
                }
            }
            Console.ReadKey();
        }
    }
}
