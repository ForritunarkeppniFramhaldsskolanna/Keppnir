#include <iostream>
#include <string>
using namespace std;
int main(){
	string inthing;
	cin >> inthing;
	string output = "";
	for (int i = inthing.length(); i > 0; --i)
	{
		if (inthing[i] == '<' && inthing[i-1] != '<')
		{
			inthing.erase(i -1, 2);
			i -= 1;
		}
		else if(inthing[i] == '<' && inthing[i -1] == '<')
		{
			int counter = 0; // find how many letters back it goes
			int index = 0; // stores the index of the begining
			while(true) {
			    if (inthing[i - counter] != '<') // the index is found
			    {
			    	index = i - counter +1;
			    	break;
			    }
			    counter += 1;
			}
			inthing.erase(index - counter,counter +counter);
			i -= counter * 2 -1;
		}
		// put the value in the end of inthing into output and make inthing shorter
		output = inthing.substr(i) + output;
		inthing = inthing.substr(0, i);
	}
	output = inthing + output;
	if (inthing.length() > 0)
	{
		cout << output << endl;
	}
}