r, d = map(int, raw_input().split())

number = 0
for x in range(0, r):
    if number % 2 == 0:
        number += 1
        for i in range(0, d):
            print x, i
    else:
        number += 1
        for i in range(d - 1, -1, -1):
            print x, i