import sys

NK = sys.stdin.readline().rstrip()
NK = NK.split()

N = int(NK[0])
K = int(NK[1])

K = K % N

pi = sys.stdin.readline()
pi = pi.split()

currentPositions = list(range(1, N+1))


def cycle(curPos, thing):
    tempNewPos = []
    for i in curPos:
        tempNewPos.append(int(thing[i - 1]))
    return tempNewPos


for i in range(0, K):
    currentPositions = cycle(currentPositions, pi)

print(" ".join(str(x) for x in currentPositions))