import java.util.*;

public class geimskip
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    String nta = sc.nextLine();
    int N = Integer.parseInt(nta);
    int k=0;
    int[] x1hnit = new int[N];
    int[] y1hnit = new int[N];
    int[] z1hnit = new int[N];
    int[] r1hnit = new int[N];
    while(k<N)
    {
      String inntak1 = sc.nextLine();
      String[] splittari = inntak1.split(" ");
      x1hnit[k] = Integer.parseInt(splittari[0]);
      y1hnit[k] = Integer.parseInt(splittari[1]);
      z1hnit[k] = Integer.parseInt(splittari[2]);
      r1hnit[k] = Integer.parseInt(splittari[3]);
      k++;
    }
    String mta = sc.nextLine();
    int M = Integer.parseInt(mta);
    k=0;
    int[] x2hnit = new int[M];
    int[] y2hnit = new int[M];
    int[] z2hnit = new int[M];
    int[] r2hnit = new int[M];
    while(k<M)
    {
      String inntak1 = sc.nextLine();
      String[] splittari = inntak1.split(" ");
      x2hnit[k] = Integer.parseInt(splittari[0]);
      y2hnit[k] = Integer.parseInt(splittari[1]);
      z2hnit[k] = Integer.parseInt(splittari[2]);
      r2hnit[k] = Integer.parseInt(splittari[3]);
      k++;
    }
    boolean[] skerast = new boolean[N];
    for(int i=0;i<N;i++)
    {
      for(int j=0;j<M;j++)
      {
        if((lengd(x1hnit[i], y1hnit[i], z1hnit[i], x2hnit[j], y2hnit[j], z2hnit[j]))<(r1hnit[i] + r2hnit[j]))
        {
          skerast[i] = true;
          break;
        }
      }
    }
      int skila = 0;
      for(int i=0;i<N;i++)
      {
        if(skerast[i] != true)
        {
          skila++;
        }
      }
      System.out.println(skila);
    }
  public static double lengd(int a, int b, int c, int x, int y, int z)
  {
    int xhnit = Math.abs(x-a);
    int yhnit = Math.abs(y-b);
    int zhnit = Math.abs(z-c);
    int iodru = xhnit*xhnit + yhnit*yhnit + zhnit*zhnit; 
    return Math.sqrt(iodru);
  }
}