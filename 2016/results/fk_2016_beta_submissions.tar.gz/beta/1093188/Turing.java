import java.util.Scanner;

public class Turing
{
  public static void main(String[] args)
  {
    
    Scanner scan = new Scanner(System.in);
    
    int n = scan.nextInt();
    
    int numbers[] = new int[n];
    
    for (int i= 0; i < n; i++)
    { 
      numbers[0] = scan.nextInt();
    }
    
    int max = 0;
    
    for (int i = 0; i < n; i++)
    {
      for (int k = 0; k < i; k++)
      {
        int null_oftar_en_einn = oft(numbers, 0, k, i) - oft(numbers, 1, k, i);
        if (null_oftar_en_einn > max)
        {
          max = null_oftar_en_einn;
        }
      }
    }
    
    
    System.out.println(max);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    scan.close();
    
  }
  
  
  
  
  public static int oft(int[] x, int a, int b, int c)
  {
    int summa = 0; 
    
    for (int i = 0; i < (c-b+1); i++)
    {
      if (x[b+i] == a) {summa++;}
    } 
    
    return summa;
    
    
  }      
  
  
  
}