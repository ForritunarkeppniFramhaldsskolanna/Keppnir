import math

def ersam(x):
    return int(str(x)[::-1]) == x

def getsam(x, m):
    z = str(x)[::-1]
    y = str(x)
    l = int(math.floor(len(y)/2))
    z = z.replace(z[:l], '')
    if(len(str(x)) % 2 == 0):
        y = y.replace('','')[:(l) * -1].upper()
    else:
        y = y.replace('','')[:(l + 1) * -1].upper()
    if(int(y + z) > m):
        a = int(y[-1:]) - 1
        y = y [:-1]
        y += str(a)
        return getsam(y + z, x)
    return y + z

#for i in range(1, 20):
 #   m = math.pow(2, i)
  #  for w in range(int(m), 0, -1):
   #     if(ersam(w)):
    #        print "{0} {1}".format(i, w)
     #       break

for i in range(1, 101):
    m = math.pow(2, i)

    print "{0} {1}".format(i , str(getsam(int(m), int(m))))



