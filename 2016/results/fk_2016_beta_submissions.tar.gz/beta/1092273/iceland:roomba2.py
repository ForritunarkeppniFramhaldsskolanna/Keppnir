grid = raw_input().split(" ")
print grid
xhnit = 0
yhnit = 0
forward = True
backward = False
forwardloop = True
exit = False
while exit != True:
    print xhnit, " ", yhnit
    xhnit += 1
    if (int(grid[1]) % 2) == 0:

        while yhnit != (int(grid[1]) - 1):
            if xhnit != (int(grid[0]) - 1) and yhnit != (int(grid[1])):
                while xhnit != (int(grid[0]) - 1):
                    print xhnit, " ", yhnit
                    xhnit += 1
            if yhnit != (int(grid[1]) - 1):
                print xhnit, " ", yhnit
                yhnit += 1
            if xhnit >= 0 and yhnit != (int(grid[1])):
                while xhnit > 1:
                    print xhnit, " ", yhnit
                    xhnit -= 1
            if yhnit != (int(grid[1]) - 1):
                print xhnit, " ", yhnit
                yhnit += 1
    print xhnit, " ", yhnit
    xhnit -= 1
    while yhnit > 0:
        print xhnit, " ", yhnit
        yhnit -= 1
    print xhnit, " ", yhnit
    exit = True
    if (int(grid[1]) % 2) != 0:
        print "No"
    exit = True
