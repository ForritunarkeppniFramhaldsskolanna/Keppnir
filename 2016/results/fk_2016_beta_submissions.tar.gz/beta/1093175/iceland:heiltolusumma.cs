using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            long b = 0;

            Console.Write("");
            long a = Convert.ToInt64(Console.ReadLine());
            

            for (int i = 1; i <= a; i++)
            {
                b += i;
            }
            Console.WriteLine(b);

            Console.ReadKey();
        }
    }
}
