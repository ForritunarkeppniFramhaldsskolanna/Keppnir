using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heiltölusumma
{
    class Program
    {
        static void Main(string[] args)
        {
            string tala = Console.ReadLine();
            int high = Convert.ToInt32(tala);
            int summa = 0;
            for (int i = 1; i <= high; i++)
            {
                summa = summa + i;
            }
            Console.WriteLine(summa);
        }
    }
}
