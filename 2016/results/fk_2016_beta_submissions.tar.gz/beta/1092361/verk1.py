#!/usr/bin/python
import math
var = input("skrifadu inn strenginn: ")
backspace = "\b \b"
var = var.replace("<", backspace)
print("retti strenguinn er: ", var)
