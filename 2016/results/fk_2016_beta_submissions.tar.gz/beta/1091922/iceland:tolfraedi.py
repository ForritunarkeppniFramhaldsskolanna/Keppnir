n = int(input())


people = []

for x in range(n):
    a = input().split()
    i = a[0]
    s = int(a[1])
    if i == "A":
        people.append(s)
    else:
        people.remove(s)
    if len(people) != 0:
        mi = min(people)
        ma = max(people)
        av = "{0:.6f}".format(sum(people) / float(len(people)))
        print(mi, ma, av)
    else:
        print(-1, -1, -1)