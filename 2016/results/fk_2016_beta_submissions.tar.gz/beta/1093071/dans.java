import java.io.*;
import java.util.Scanner;
public class dans{
  public static void main(String[] args){
    
    Scanner in = new Scanner(System.in);
    
    int n = in.nextInt();//fjoldi dansara
    
    long k = (int)in.nextLong();//fjoldi vidlaga
    
    int[] dansinn = new int[n];
    int[] upphafdansins = new int[n];
    int[] endirdansins = new int[n];
    for(int i=0;i<n;i++){
      dansinn[i]=in.nextInt()-1;
      upphafdansins[i]=i;
      endirdansins[i]=i;
    }
    /*
    System.out.println("Hér er dansinn: ");  
    
    for(int i =0;i<n;i++){
      System.out.print(dansinn[i]+" ");
    }
    System.out.println();
    System.out.println("Hér er listi dansaranna upphaflega");
    for(int i =0;i<n;i++){
      System.out.print(upphafdansins[i]+" ");
    }
    */
    for(int j=0;j<k;j++){
      for(int i =0;i<n;i++){
        upphafdansins[i]=endirdansins[i];
      }
      for(int h=0;h<n;h++){
        endirdansins[h] = upphafdansins[dansinn[h]];
      }
      
    }
    
    
    for(int i =0;i<n;i++){
      endirdansins[i]=endirdansins[i]+1;
      System.out.print(endirdansins[i]+" ");
    }
    //MUNA PLUSA PEOPLE FYRIR RETURN
    
    in.close();
  }
}


