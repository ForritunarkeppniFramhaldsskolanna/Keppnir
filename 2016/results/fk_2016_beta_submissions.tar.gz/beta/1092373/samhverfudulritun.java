public class samhverfudulritun {
public static void main(String[] args){
	long max=0;
	long t=-1;
	long geymsla=0;
	long samhverfa=0;
	for(int i=1;i<=30;i++){
		System.out.print(i+" ");
		max=(long)Math.pow(2, i);
		while(t==-1){
			geymsla=max;
			for(int j=1;j<=max;j=j*10){
				while(true){
				if(geymsla%(j*10)==0){
					samhverfa=samhverfa*10;
					break;
				}
				geymsla=geymsla-j;
				samhverfa=samhverfa+1;
				
			}}
			
			samhverfa=samhverfa/10;
			if(Math.abs(samhverfa)==max)
				t=samhverfa;	
			else
				samhverfa=0;
				max=max-1;
		}
		
		System.out.println(t);
		geymsla=0;
	    t=-1;
	    samhverfa=0;
	
	}
}
}
