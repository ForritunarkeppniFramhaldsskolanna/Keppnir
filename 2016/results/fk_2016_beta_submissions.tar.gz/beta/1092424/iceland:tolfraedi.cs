using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kattis
{
    class Program
    {
        static void Main(string[] args)
        {
            int peopleCount = Convert.ToInt32(Console.ReadLine());
            int[] people = new int[peopleCount];
            int minAge = int.MaxValue;
            int currentPopulation = 0;
            double currentAverage = 0;
            int maxAge = 0;
            List<int> ages = new List<int>();

            for (int i = 0; i < peopleCount; i++)
            {
                string[] currentInput = Console.ReadLine().Split(' ');
                string operation = currentInput[0];
                int currentAge = Convert.ToInt32(currentInput[1]);

                if (operation == "A")
                {
                    currentAverage = ((currentAverage * currentPopulation) + currentAge) / (currentPopulation + 1);
                    currentPopulation++;
                    minAge = Math.Min(currentAge, minAge);
                    maxAge = Math.Max(currentAge, maxAge);

                    //ages.Add(currentAge);
                }
                else
                {
                    if (currentPopulation > 1)
                    {
                        currentAverage = ((currentAverage * currentPopulation) - currentAge) / (currentPopulation - 1);
                        currentPopulation--;
                        ages.Remove(currentAge);

                        minAge = ages.Min();
                        maxAge = ages.Max();
                    }
                    else
                    {
                        currentPopulation = 0;
                        ages.Clear();
                        minAge = int.MaxValue;
                        maxAge = 0;
                        currentAverage = 0;
                    }
                }

                if (currentPopulation > 0)
                {
                    Console.WriteLine(minAge + " " + maxAge + " " + currentAverage);
                }
                else
                {
                    Console.WriteLine("-1 -1 -1");
                }
            }

            Console.ReadKey();
        }
    }
}
