using System;

namespace forritun
{
    class Program
    {
        static void Main()
        {
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(talasum(n));
        }

        static long talasum(long n)
        {
            long sum = 0;
            if(n < 0)
            {
                for(long i = n; i <= 1; i++)
                {
                    sum += i;
                }
                return sum;
            }
            else
            {
                return (n + 1) * (n / 2);
            }
        }
    }
}