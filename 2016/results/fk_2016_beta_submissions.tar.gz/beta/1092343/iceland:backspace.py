strengur = str(input())
newString = ""
listi = []
for x in strengur:
    listi.append(x)
count = len(listi)-1
pop = 0
for x in range(count,0,-1):
    pop = 0
    if listi[count] == "<":
        listi.pop(count)
        pop = pop + 1
        if listi[count-1] == "<":
            listi.pop(count-1)
            pop = pop + 1
            if listi[count-2] != "<":
                pop = pop + 1
                listi.pop(count-2)
            if listi[count-3] != "<":
                listi.pop(count-3)
                pop = pop + 1
        else:
            listi.pop(count-1)
            pop = pop + 1
    count = count - 1
    if pop > 0:
        count = (count - pop) +1
    if count < 1:
        break
strengur = ""
for x in listi:
    strengur += x
print(strengur)
