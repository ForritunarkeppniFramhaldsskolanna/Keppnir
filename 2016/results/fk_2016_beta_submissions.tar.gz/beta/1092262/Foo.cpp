#include <iostream>
#include <algorithm>

using namespace std;

int Capacity = 10000;
int Size = 0;

int main() {
	char *arr = new char[Capacity];

	*arr = { ' ' };

	cin >> *arr;

	for (int i = 0; i < *arr; i++)
	{
		if (arr[i] == '<')
		{
			char* _new_arr = new char[Capacity];
			for (int j = 0; j < Size; j++)
			{
				if (j == i)
				{

				}
				else {
					_new_arr[i] = arr[i];
				}
			}
			arr = _new_arr;
		}
	}
	cout << *arr;

	return 0;
}