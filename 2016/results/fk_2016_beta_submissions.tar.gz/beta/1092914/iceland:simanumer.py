n = int(input())
phonenumbers = []
for x in range(n):
	phonenumbers.append(input())
f = int(input())
thelen = len(phonenumbers)
for x in range(f):
	count = 0
	string = input()
	for y in range(thelen):
		isit = True
		for z in range(len(string)):
			if string[z] != phonenumbers[y][z]:
				isit = False
				break
		if isit:
			count+= 1
	print(count)
