row, column = input().split()
row = int(row)
column = int(column)

board = []

for x in range(row):
    board.append([])
    for y in range(column):
        board[x].append([x, y])

visitedTiles = [[0, 0]]
currentPosition = [0, 0]
print(currentPosition)
currentPosition = [0, 1]
while currentPosition != [0, 0]:
    left = [(currentPosition[0] - 1), currentPosition[1]]
    right = [(currentPosition[0] + 1), currentPosition[1]]
    up = [currentPosition[0], (currentPosition[1] - 1)]
    down = [currentPosition[0], (currentPosition[1] + 1)]
    directions = [left, right, up, down]
    for direction in directions:
        if direction[0] != -1 and direction[1] != -1 and direction not in visitedTiles and direction[0] <= row and direction[1] <= column:
            visitedTiles.append(direction)
            currentPosition = direction
            print(currentPosition)
            break
print(currentPosition)
