using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forritunarkeppni2
{
    class Program
    {
        static void Main(string[] args)
        {
            string lengthString = Console.ReadLine();
            int lengthInt = Convert.ToInt32(lengthString);
            List<int> list = new List<int>();
            int max;
            int min;
            double avg;
            int listLength;
            string age = null;
            int extra;
            int ageInt;
            char[] lines;
            for (int i = 0; i < lengthInt; i++)
            {
                age = null;
                string line = Console.ReadLine();
                lines = line.ToCharArray();
                extra = lines.Length - 1;
                string letter = lines[0].ToString();
                for (int j = 0; j < extra; j++)
                {
                    age += lines[j+1].ToString();
                }
                ageInt = Convert.ToInt32(age);
                if(letter.ToUpper() == "A")
                {
                    list.Add(ageInt);
                }
                else if (letter.ToUpper() == "R")
                {
                    listLength = list.Count();
                    for (int k = 0; k < listLength; k++)
                    {
                        if (list[k] == ageInt)
                        {
                            list.RemoveAt(k);
                            break;
                        }
                    }
                }
                max = list.Max();
                min = list.Min();
                avg = list.Average();
                Console.WriteLine(min + " " + max + " " + avg);
            }
            Console.ReadLine();
        }
    }
}
