tala = int(input())
summa = (tala*(tala + 1))/2

if tala > 0:
    print(round(summa))
else:
    print(((round(summa) * 1)))