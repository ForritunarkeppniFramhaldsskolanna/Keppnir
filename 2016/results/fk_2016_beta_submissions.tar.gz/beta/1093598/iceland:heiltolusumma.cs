using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal b = 0;

            decimal a = Convert.ToDecimal(Console.ReadLine());

            if (a > 0)
            {
                b = (a * (a + 1)) / 2;

            }
            else
            {
                b = 1 - (Math.Abs(a) * (Math.Abs(a) + 1)) / 2;
            }
            Console.WriteLine(b);

            Console.ReadKey();
        }
    }
}
