using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem_D
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] start = new int[] { 0, 0 };
            int[] currentPos = new int[] { 0, 0 };
            int[] tempCoords;
            List<double> answers = new List<double>();
            List<double> ansList = new List<double> { };
            double traveled = 0;
            int packCount = Convert.ToInt32(Console.ReadLine());
            List<int[]> packXY = new List<int[]>();
            for (int i = 0; i < packCount; i++)
            {
                string[] temp = Console.ReadLine().Split(' ');
                tempCoords = new int[] {Convert.ToInt32(temp[0]), Convert.ToInt32(temp[1])};
                packXY.Add(tempCoords);          
            }
            tempCoords = new int[] { 0,0};
            if (packCount > 3)
            {
                packXY = packXY.OrderBy(arr => arr[1]).ToList();
                for (int i = 0; i <= packXY.Count; i++)
                {
                    if (i < packXY.Count)
                    {
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - packXY[i][0], 2) + Math.Pow(currentPos[1] - packXY[i][1], 2))));
                        currentPos = packXY[i];
                    }
                    else
                    {
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - start[0], 2) + Math.Pow(currentPos[1] - start[1], 2))));
                        currentPos = start;
                    }

               } 
            }
            else
            {
                

                switch (packCount)
                {
                    case 1:
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - packXY[0][0], 2) + Math.Pow(currentPos[1] - packXY[0][1], 2))));
                        currentPos = packXY[0];
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - start[0], 2) + Math.Pow(currentPos[1] - start[1], 2))));
                        currentPos = packXY[0];
                        ansList.Add(traveled);
                        break;
                    case 2:
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - packXY[0][0], 2) + Math.Pow(currentPos[1] - packXY[0][1], 2))));
                        currentPos = packXY[0];
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - packXY[1][0], 2) + Math.Pow(currentPos[1] - packXY[1][1], 2))));
                        currentPos = packXY[0];
                        traveled += ((Math.Sqrt(Math.Pow(currentPos[0] - start[0], 2) + Math.Pow(currentPos[1] - start[1], 2))));
                        ansList.Add(traveled);
                        break;
                    case 3:
                        double[] traveledTemp3 = new double[] { 0, 0, 0 };
                        int[,] currentPos3 = new int[,] { { 0, 0 }, { 0, 0 }, { 0, 0 } };
                        traveledTemp3[0] += ((Math.Sqrt(Math.Pow(currentPos3[0, 0] - packXY[0][0], 2) + Math.Pow(currentPos3[0, 1] - packXY[0][1], 2))));
                        currentPos3[0, 0] = packXY[0][0];
                        currentPos3[0, 1] = packXY[0][1];
                        traveledTemp3[0] += ((Math.Sqrt(Math.Pow(currentPos3[0, 0] - packXY[1][0], 2) + Math.Pow(currentPos3[0, 1] - packXY[1][1], 2))));
                        currentPos3[0, 0] = packXY[0][0];
                        currentPos3[0, 1] = packXY[0][1];
                        traveledTemp3[0] += ((Math.Sqrt(Math.Pow(currentPos3[0, 0] - packXY[2][0], 2) + Math.Pow(currentPos3[0, 1] - packXY[2][1], 2))));
                        currentPos3[0, 0] = packXY[0][0];
                        currentPos3[0, 1] = packXY[0][1];
                        traveledTemp3[0] += ((Math.Sqrt(Math.Pow(currentPos3[0, 0] - start[0], 2) + Math.Pow(currentPos3[0, 1] - start[1], 2))));

                        traveledTemp3[1] += ((Math.Sqrt(Math.Pow(currentPos3[1, 0] - packXY[0][0], 2) + Math.Pow(currentPos3[1, 1] - packXY[0][1], 2))));
                        currentPos3[1, 0] = packXY[1][0];
                        currentPos3[1, 1] = packXY[1][1];
                        traveledTemp3[1] += ((Math.Sqrt(Math.Pow(currentPos3[1, 0] - packXY[2][0], 2) + Math.Pow(currentPos3[1, 1] - packXY[2][1], 2))));
                        currentPos3[1, 0] = packXY[1][0];
                        currentPos3[1, 1] = packXY[1][1];
                        traveledTemp3[1] += ((Math.Sqrt(Math.Pow(currentPos3[1, 0] - packXY[1][0], 2) + Math.Pow(currentPos3[1, 1] - packXY[1][1], 2))));
                        currentPos3[1, 0] = packXY[1][0];
                        currentPos3[1, 1] = packXY[1][1];
                        traveledTemp3[1] += ((Math.Sqrt(Math.Pow(currentPos3[1, 0] - start[0], 2) + Math.Pow(currentPos3[1, 1] - start[1], 2))));

                        traveledTemp3[2] += ((Math.Sqrt(Math.Pow(currentPos3[2, 0] - packXY[2][0], 2) + Math.Pow(currentPos3[2, 1] - packXY[2][1], 2))));
                        currentPos3[2, 0] = packXY[2][0];
                        currentPos3[2, 1] = packXY[2][1];
                        traveledTemp3[2] += ((Math.Sqrt(Math.Pow(currentPos3[2, 0] - packXY[0][0], 2) + Math.Pow(currentPos3[2, 1] - packXY[0][1], 2))));
                        currentPos3[2, 0] = packXY[2][0];
                        currentPos3[2, 1] = packXY[2][1];
                        traveledTemp3[2] += ((Math.Sqrt(Math.Pow(currentPos3[2, 0] - packXY[1][0], 2) + Math.Pow(currentPos3[2, 1] - packXY[1][1], 2))));
                        currentPos3[2, 0] = packXY[2][0];
                        currentPos3[2, 1] = packXY[2][1];
                        traveledTemp3[2] += ((Math.Sqrt(Math.Pow(currentPos3[2, 0] - start[0], 2) + Math.Pow(currentPos3[2, 1] - start[1], 2))));
                        foreach (double d in traveledTemp3)
                        {
                            ansList.Add(d);
                        }
                        break;
                }
            }
            
            if (packCount > 3)
            {
                Console.WriteLine(traveled.ToString("F10"));
            }
            else
            {
                Console.WriteLine(ansList.Min().ToString("F10"));
            }
            Console.ReadKey();
        }
        

    }
}
