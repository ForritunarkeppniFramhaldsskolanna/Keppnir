using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_kóði
{
    class Basic
    {

        public class Example
        {
            public static void Main()
            {
                int tala1 = Convert.ToInt32(Console.ReadLine()) ;
                List<int> arr = new List<int>();
                string[] arr1 = new string[tala1];
                string stafur;
                int tala3;
                for (int i = 0; i < tala1; i++)
                {
                    String value = Console.ReadLine();
                    Char delimiter = ' ';
                    String[] substrings = value.Split(delimiter);
                    int a = 0;
                    foreach (var substring in substrings)
                    {
                        arr1[a] = substring;
                        a++;
                    }
                    tala3 = 0;
                    stafur = arr1[1];
                    arr.Add(Convert.ToInt32(stafur));
                    if (arr1[tala3] == "A")
                    {
                        
                        Console.Write(arr.Min() + " " + arr.Max() + " " + arr.Average().ToString("f2"));
                        Console.WriteLine();
                    }
                    
                    if (arr1[tala3] == "R")
                    {
                        for (int c = 0; c < arr.Count; c++)
                        {
                            if (c == arr.Count)
                            {
                                arr.Remove(c);
                                break;
                                
                            }
                            if (arr[c] == Convert.ToInt32(stafur))
                            {
                                arr.Remove(c);
                            }
                        }
                        Console.Write(arr.Min() + " " + arr.Max() + " " + arr.Average().ToString("f2"));
                    }
                    tala3 = tala3 + 2;
                    if (arr.Count == 0)
                    {
                        Console.WriteLine("-1 -1 -1");
                    }
                    


                }
            }

        }

    }
    
}
