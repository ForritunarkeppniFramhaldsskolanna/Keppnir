logic = {
    "OG": "x and y",
    "EDA": "x or y",
    "EKKI": "not x"
    }
variables = {}
n = int(input())
for i in range(n):
    ops = input().split()
    if ops[0] == "INNTAK":
        x = ops[1]
        truth = ops[2]
        if truth == "SATT":
            variables[ops[1]] = True
        else:
            variables[ops[1]] = False
    elif ops[0] == "UTTAK":
        if variables[ops[1]] == True:
            print("{} {}".format(ops[1], "SATT"))
        else:
            print("{} {}".format(ops[1], "OSATT"))
    elif ops[0] == "EKKI":
        x = variables[ops[1]]
        y = ops[2]
        variables[y] = eval(logic["EKKI"])
    else:
        x = variables[ops[1]]
        y = variables[ops[2]]
        zname = ops[3]
        z = eval(logic[ops[0]])
        variables[zname] = z
