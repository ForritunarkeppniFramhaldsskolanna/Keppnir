using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_kóði
{
    class Basic
    {

        public static void Main()
        {
            string talaN1 = null;
            double count = 0;
            double answer = 0;

            talaN1 = Console.ReadLine(); 
            count = Convert.ToDouble(talaN1);
            if (count > 0)
            {
                while (count != 0)
              {
                answer = answer + count;
                count--;

              }

            }
            else
            {
                while (count != 2)
                {
                    answer = answer + count;
                    count++;
                }
            }
            
            Console.WriteLine(answer);
            Console.Read();
        }

    }

}