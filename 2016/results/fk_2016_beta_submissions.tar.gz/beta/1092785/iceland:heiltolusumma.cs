using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            long input = Convert.ToInt64(Console.ReadLine());
            long ans;
            if (input % 2 != 0)
            {
                
            }
            if (input >= 1)
            {
                ans = input*(input + 1)/2;
            }
            else
            {
                input = input * -1;
                ans = (input * (input + 1)/2) * -1 +1;
            }
            Console.WriteLine(ans);
        }
    }
}
