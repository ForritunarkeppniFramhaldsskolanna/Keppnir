talaX, talaK = input().split()
talaN = input().split()
talaN = list(map(int,talaN))
replacement = talaX
if talaN == 2:
    for index in range(int(talaK) + 1):
        talaN[0],talaN[1] = talaN[1],talaN[0]
    print (talaN[0], talaN[1])
