s = input()

out = ""
i = 0
for x in range(len(s) - 1, -1, -1):
    if s[x] == "<":
        i += 1
    elif i > 0:
        i -= 1
        pass
    else:
        out += s[x]
print(out[::-1])