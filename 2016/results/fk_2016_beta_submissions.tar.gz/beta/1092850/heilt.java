import java.util.Scanner;

public class heilt
{
  public static void main(String[] args)
  {
    
    Scanner scan = new Scanner(System.in);
    
    long n = scan.nextLong();
    
    long dist = Math.abs(n-1) + 1;
    
    long summa = dist * (n+1);
    
    
    
    
    System.out.println(summa/(2));
    
    
    
    scan.close();
    
    
  } 
}