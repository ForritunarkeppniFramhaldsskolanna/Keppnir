def palindrome(x):
    return str(x) == str(x)[::-1]
palindromes = set()
for k in range(1,60):
    maxNumber = 2**k
    for x in range(maxNumber, 1, -1):
        if palindrome(x):
            print('%s %s' % (k, x))
            break
