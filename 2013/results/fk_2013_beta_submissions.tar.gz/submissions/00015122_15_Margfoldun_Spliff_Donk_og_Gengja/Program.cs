﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace d15
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int c = 0;

            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());

            if (a * b == c)
            {
                Console.WriteLine("True");
            }
            else if (a * b != c)
            {
                Console.WriteLine("False");
            }
        }
    }
}
