﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni16Sqrt
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tilvik; i++)
            {
                string tolurMedBili = Console.ReadLine();
                string[] splitted = tolurMedBili.Split(' ');
                string svar = null;
                long n = Convert.ToInt32(splitted[0]);
                long skipti = Convert.ToInt32(splitted[1]);
                double a = 5 * n;
                double b = 5;
                for (int k = 0; k < skipti; k++)
                {
                    if (a >= b)
                    {
                            a = a - b;
                            b = b + 10;
                    }
                    else
                    {
                        a = a * 100;
                        string breyttur = null;
                        string bstring = Convert.ToString(b);
                        char[] tolurnar = bstring.ToCharArray();
                        for (int y = 0; y < tolurnar.Length; y++)
                        {
                            breyttur += tolurnar[y];
                            if (y == tolurnar.Length - 2)
                            {
                                breyttur += '0';
                            }
                        }
                        b = Convert.ToInt64(breyttur);
                    }
                }
                Console.WriteLine(b);

            }
            Console.ReadLine();
        }
    }
}
