/*
Nafn skr�ar: FH9.cs
Forritari: Hallgr�mur Dav�� Egilsson
*/
using System;
class FH9
{
	static void Main()
	{
        int T = Convert.ToInt32(Console.ReadLine());
        string lina = "";
        int N;
        bool o1 = false;
        bool x1 = false;
        int teljari = 0;
        //int xSamtals = 0;
        //int oSamtals = 0;

        for (int t = 0; t < T; t++)
        {
            N = Convert.ToInt32(Console.ReadLine());

            for (int n = 0; n < N; n++)
            {
                lina += Console.ReadLine();
            }

            //Console.WriteLine("lina:"+lina);

            //Checka � l�nu
            for (int x = 0; x < lina.Length; x += N)
            {
                //Checka � O
                for(int i=0;i<N-1;i++)
                {
                    if ((lina[x+i] == 'O') && (lina[x + (i+1)] == 'O'))
                        teljari++;
                }
                if (teljari == N - 1)
                {
                    //Console.WriteLine("Checka � l�nu, Checka � X");
                    o1 = true;
                }
                teljari = 0;

                //Checka � X
                for (int i = 0; i < N - 1; i++)
                {
                    if ((lina[x + i] == 'X') && (lina[x + (i + 1)] == 'X'))
                        teljari++;
                }
                if (teljari == N - 1)
                {
                    //Console.WriteLine("Checka � l�nu, Checka � X");
                    x1 = true;
                }
                teljari = 0;
            }

            //Checka � d�lki
            for (int x = 0; x < N; x += 1)
            {
                //Checka � O
                for (int i = 1; i < lina.Length-N; i += N)
                {
                    if( (lina[x+i-1] == 'O') && (lina[(x+i)+N-1] == 'O') )
                        teljari++;
                    //Console.WriteLine("X! x"+x+"x+i-1:" + (x + i-1) + " ((x+i)+N-1)" + ((x + i) + N-1));   
                }
                if (teljari == N - 1)
                {
                    //Console.WriteLine("Checka � d�lki, Checka � O");
                    o1 = true;
                }
                teljari = 0;

                //Checka � O
                for (int i = 1; i < lina.Length - N; i += N)
                {
                    if ((lina[x + i - 1] == 'X') && (lina[(x + i) + N - 1] == 'X'))
                        teljari++;
                    //Console.WriteLine("O! x" + x + "x+i-1:" + (x + i - 1) + " ((x+i)+N-1)" + ((x + i) + N - 1));
                }
                if (teljari == N - 1)
                {
                    //Console.WriteLine("Checka � d�lki, Checka � X");
                    x1 = true;
                }
                teljari = 0;
            }

            //Checka � sk�1 O
            for (int x = 0; x < lina.Length-1; x += (N+1))
            {
                //Checka � O
                if ((lina[x] == 'O') && (lina[(x + (N + 1))] == 'O'))
                {
                    teljari++;
                }
            }
            if (teljari == N - 1)
            {
                //Console.WriteLine("Checka � sk�1 O");
                o1 = true;
            }
            teljari = 0;

            //Checka � sk�1 X
            for (int x = 0; x < lina.Length - 1; x += (N + 1))
            {
                //Checka � X
                if ((lina[x] == 'X') && (lina[(x + (N + 1))] == 'X'))
                {
                    teljari++;
                }
            }
            if (teljari == N - 1)
            {
                //Console.WriteLine("Checka � sk�1 X");
                x1 = true;
            }
            teljari = 0;

            //Checka � sk�2 O
            for (int x = N-1; x < lina.Length - 1; x += (N - 1))
            {
                //Checka � O
                if ((lina[x] == 'O') && (lina[(x + (N - 1))] == 'O'))
                {
                    teljari++;
                }
            }
            if (teljari == N - 1)
            {
                //Console.WriteLine("Checka � sk�2 O");
                o1 = true;
            }
            teljari = 0;

            //Checka � sk�2 X
            for (int x = N - 1; x < lina.Length - 1; x += (N - 1))
            {
                //Checka � X
                if ((lina[x] == 'X') && (lina[(x + (N - 1))] == 'X'))
                {
                    teljari++;
                }
            }
            if (teljari == N - 1)
            {
                //Console.WriteLine("Checka � sk�2 X");
                x1 = true;
            }
            teljari = 0;

            /*for (int n = 0; n < lina.Length; n++)
            {
                if (lina[n] == 'O')
                    oSamtals++;
                if (lina[n] == 'X')
                    xSamtals++;
            }*/
            //Console.WriteLine("oSamtals:" + oSamtals + "xSamtals" + xSamtals);

            /*if ((oSamtals > xSamtals) || (oSamtals < xSamtals - 2))
            {
                Console.WriteLine("Error");
            }
            else
            {*/
                if ((x1 == true) && (o1 == false))
                    Console.WriteLine("X won");
                if ((x1 == false) && (o1 == true))
                    Console.WriteLine("O won");
                if (((x1 == true) && (o1 == true)))
                    Console.WriteLine("Error");
                if ((x1 == false) && (o1 == false))
                    Console.WriteLine("Neither won");
            //}
            //Console.WriteLine("x1:" + x1 + "  o1:" + o1);


            x1 = false;
            o1 = false;
            lina = "";
            //oSamtals = 0;
            //xSamtals = 0;
        }
	}
}