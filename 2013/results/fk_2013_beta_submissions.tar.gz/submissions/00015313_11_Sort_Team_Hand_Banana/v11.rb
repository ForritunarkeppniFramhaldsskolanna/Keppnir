fjd = gets.chomp.to_i
outcome = []

(1..fjd).each do |x|
  arr1 = []
  arr2 = []
  arr1 = gets.chomp.split(' ').map(&:to_i)
  arr2 = gets.chomp.split(' ').map(&:to_i)
  if arr1.sort == arr2
    outcome << "Accepted"
  else
    outcome << "Wrong Answer"
  end
end

puts outcome