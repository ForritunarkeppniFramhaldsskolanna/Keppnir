﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sort_V11
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < oft; i++)
            {
                string[] temp = Console.ReadLine().Split();
                int[] listi1 = new int[temp.Length];
                for (int c = 0; c < temp.Length; c++)
                {
                    listi1[c] = int.Parse(temp[c]);
                }
                string[] temp2 = Console.ReadLine().Split();
                int[] listi2 = new int[temp2.Length];
                for (int c = 0; c < temp2.Length; c++)
                {
                    listi2[c] = int.Parse(temp2[c]);
                }
                Array.Sort(listi1);
                int stig = 0;
                if (listi1.Length == listi2.Length)
                {
                    for (int c = 0; c < listi1.Length; c++)
                    {
                        if (listi1[c] == listi2[c])
                        {
                            stig++;
                        }
                    }
                }
                if (stig == listi1.Length)
                {
                    Console.WriteLine("Accepted");
                }
                else
                {
                    Console.WriteLine("Wrong Answer");
                }
            }
        }
    }
}
