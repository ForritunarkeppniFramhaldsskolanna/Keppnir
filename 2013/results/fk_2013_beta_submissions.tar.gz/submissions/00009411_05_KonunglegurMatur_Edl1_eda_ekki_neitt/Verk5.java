import java.util.Scanner;

public class Verk5
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
     int t = sc.nextInt();
     
     
     for( int i=0; i<t; i++)
     {
       int n = sc.nextInt();
       int ax = sc.nextInt();
       int ay = sc.nextInt();
       int bx = sc.nextInt();
       int by = sc.nextInt();
       
       if( ax-bx<=1 && ay-by<=1 && ax-bx>=-1 && ay-by>=-1)
         System.out.println("Same");
       
      else if ( ax-bx ==2 && ay-by == 1)
         System.out.println("Same");
       
        else if ( ax-bx ==2 && ay-by == -1)
         System.out.println("Same");
         
          else if ( ax-bx ==-2 && ay-by == 1)
         System.out.println("Same");
     
         else if ( ax-bx ==-2 && ay-by == -1)
         System.out.println("Same");
         
             else if ( ax-bx ==1 && ay-by == 2)
         System.out.println("Same");
       
         else if ( ax-bx ==1 && ay-by == -2)
         System.out.println("Same");
         
           else if ( ax-bx ==-1 && ay-by == 2)
         System.out.println("Same");
      
         else if ( ax-bx ==-1 && ay-by == -2)
         System.out.println("Same");
         
         else System.out.println("Queen");
       
     }
  }
}