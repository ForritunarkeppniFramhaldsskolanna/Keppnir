fjd = gets.chomp.to_i

outcome = []

(1..fjd).each do |z|
  inn = gets.chomp.gsub(/[^0-9]/, ' ').squeeze(" ").strip
  teljari = 0
  inn = inn.split(' ').reverse
  (inn.length+1).times do |f|
    if teljari != (inn.length)
      outcome << "[#{inn[f]}]->"
    else
      outcome << "NULL"
    end
    teljari += 1
  end
  
end

(outcome.length).times do |d|
  if outcome[d] == "NULL"
    puts outcome[d]
  else
    print outcome[d]
  end
end
