﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace pascal
{
    class Program
    {

        static void Main(string[] args)
        {

            UInt64 input = Convert.ToUInt64(Console.ReadLine());
            BigInteger n = new BigInteger();
            BigInteger y = new BigInteger();
            BigInteger x = new BigInteger();
            n = Convert.ToUInt64(input);
            for (y = 0; y <= n-1; y++)
            {
                BigInteger c = 1;
                
                for (x = 0; x <= y; x++)
                {
                    if (c % 2 == 0)
                    {
                        Console.Write(".");
                    }
                    else if(c % 2 != 0)
                    {
                        Console.Write("#");
                    }
                    c = c*(y - x) / (x + 1);
                }
                Console.WriteLine();
            }
        }
        
    }
}
