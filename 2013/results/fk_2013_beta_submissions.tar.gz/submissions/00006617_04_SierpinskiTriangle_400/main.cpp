#include <iostream>
using namespace std;
int main()
{
int n;
int x;

cin >> n;
for(int i=0;i<n;i++)
{
x=1;
for(int k=0;k<=i;k++)
{
    if(x%2==0)
    {
    cout << ".";
    }
    else
    {
    cout << "#";
    }
x = x * (i - k) / (k + 1);
}
cout << endl;
}
return 0;
}
