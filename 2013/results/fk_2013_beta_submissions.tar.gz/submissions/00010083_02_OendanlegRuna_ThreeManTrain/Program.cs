﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oendanelg_runa_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int o = 0; o < oft; o++)
            {
                string[] temp = Console.ReadLine().Split();
                int i = int.Parse(temp[0]);
                int j = int.Parse(temp[1]);
                int teljari = 0;
                for (int u = i; u <= j; u++)
                {
                    teljari++;
                }
                string tala = Console.ReadLine();
                char[] tala2 = new char[teljari];
                int counter = 0;
                int counter2 = 1;
                for (int c = 1; c < j+1; c++)
                {
                    if (counter < tala.Length)
                    {
                        if (c >= i)
                        {
                            tala2[counter2-1] = tala[counter];
                            counter++;
                            counter2++;
                        }
                        else
                        {
                            tala2[0] = tala[counter];
                            counter++;
                        }
                        
                    }
                    else
                    {
                        counter = 0;
                        if (c >= i)
                        {
                            tala2[counter2-1] = tala[counter];
                            counter++;
                            counter2++;
                        }
                        else
                        {
                            tala2[0] = tala[counter];
                            counter++;
                        }
                    }
                }
                for (int x = 0; x <= tala2.Length-1; x++)
                {
                    Console.Write(tala2[x]);
                }
                Console.Write("\n");
            }
            
        }
    }
}
