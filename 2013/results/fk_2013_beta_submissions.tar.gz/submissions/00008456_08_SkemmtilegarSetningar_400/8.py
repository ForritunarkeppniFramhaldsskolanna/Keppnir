#!/usr/bin/python
from sys import stdin, stdout, stderr
for j in range(int(stdin.readline())):
	s = stdin.readline().split()
	ret = True
	for i in range(len(s) - 1):
		if s[i][-1].upper() != s[i+1][0].upper():
			ret = False
	if ret: print"Fun"
	else: print "Boring"
