﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace breytunafn
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < oft; i++)
            {
                string breyta = Console.ReadLine().ToLower();
                if (breyta=="")
                {
                    Console.WriteLine("Invalid");
                }
                else if(breyta == "_")
	            {
                    Console.WriteLine("Valid");
	            }
                else if (Regex.IsMatch(breyta, @"[\%\/\\\&\?\,\'\;\:\!\-\=\*\@]+"))
                {
                    Console.WriteLine("invalid");
                }
                else if (char.IsDigit(breyta[0]) != false || breyta.Contains(' ') || breyta.Contains('!') || breyta.Contains('=') || breyta.Contains('-') || breyta.Contains('!') || breyta == null || breyta.Contains('*') || breyta.Contains('+') || breyta.Contains('/') || breyta.Contains('.') || breyta.Contains(',') || breyta.Contains(':') || breyta.Contains(';'))
                {
                    Console.WriteLine("Invalid");
                }

                else if(Regex.IsMatch(breyta, @"[a-zA-Z0-9]*$"))
                {
                    Console.WriteLine("Valid");
                }
            }
        }
    }
}
