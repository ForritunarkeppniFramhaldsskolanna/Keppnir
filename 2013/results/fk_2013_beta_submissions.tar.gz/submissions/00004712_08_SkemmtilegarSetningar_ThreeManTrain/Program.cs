﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verk8
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < T; i++)
            {

                string texti = Console.ReadLine().ToLower() ;
                string[] ord = texti.Split(' ');
                char last = ' ';
                string temp;
                bool fun = false;
                for (int ii = 0; ii < ord.Length; ii++)
                {
                    temp = ord[ii];
                    char tester = temp[0];
                    if (last == tester)
                    {
                        Console.WriteLine("Fun");
                        fun = true;
                        break;
                    }
                    last = temp[temp.Length - 1];
                    
                }
                if (fun == false)
                {
                    Console.WriteLine("Boring");
                }
            }
        }
    }
}
