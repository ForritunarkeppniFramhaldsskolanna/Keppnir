﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Verkefni18
{
    class Program
    {
        static void Main(string[] args)
        {
            int Y = 0;
            int tala = 0;

            Console.WriteLine("Hvad a gera detta oft?");
            tala = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tala; i++)
			{
                int count = 0;

                Console.WriteLine("Hvada ar?");
                Y = Convert.ToInt32(Console.ReadLine());

                
                for (int year = Y; year <= Y; year++)
                {
                    
                    for (int month = 1; month <= 12; month++)
                    {
                      
                        DateTime test_date = new DateTime(year, month, 13);

                        
                        if (test_date.DayOfWeek == DayOfWeek.Friday)
                        {
                            count++;
                        }
                    }
                }

                    Console.WriteLine(count);
            }
           
        }
    }
}
