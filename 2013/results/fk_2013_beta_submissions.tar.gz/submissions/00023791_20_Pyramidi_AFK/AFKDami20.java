import java.util.Scanner;

class AFKDami20 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		for (int i = 0; i < n; i++) {
			int a = scan.nextInt();
			int s = 0;
			while (true) {
				if ((a-s)>(-1)) {
					a -= s;
					s++;
				}
				else {
					System.out.println((s-1) + " " + a);
					break;
				}
			}
		}
	}
}