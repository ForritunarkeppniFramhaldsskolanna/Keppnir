﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class10 {
        static void Main() {
            int tests = Convert.ToInt32(Console.ReadLine());
            for (int test = 0; test < tests; test++) {
                int n = Convert.ToInt32(Console.ReadLine());
                string runa = "";
                for (int i = 1; i <= n; i++) {
                    runa += i;
                }
                int[] fjoldi = new int[10];
                for (int i = 0; i < runa.Length; i++) {
                    fjoldi[runa[i]-48]++;
                }
                string result = "";
                foreach (int x in fjoldi) result +=x+" ";
                Console.WriteLine(result.Substring(0, result.Length-1));
            }
        }
    }
}
