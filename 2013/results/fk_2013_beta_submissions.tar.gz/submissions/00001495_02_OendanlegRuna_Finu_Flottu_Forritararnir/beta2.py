test = input()


for n in range(int(test)):
    iogj = input()
    tala = input()

    for n in range(len(iogj)):
        if iogj[n] == ' ':
            i = int(iogj[:n])
            j = int(iogj[n:])

    tala = str(tala)

    ofur_tala = (tala*j)

    breyta = ofur_tala[i-1:j]

    print(breyta)

