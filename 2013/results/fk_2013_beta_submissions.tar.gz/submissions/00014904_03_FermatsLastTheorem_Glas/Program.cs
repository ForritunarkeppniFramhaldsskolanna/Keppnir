﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int profunarnumer = 0; profunarnumer < fjoldiProfunartilvika; profunarnumer++)
            {
                string veldisvisir = Console.ReadLine();

                Console.WriteLine("no solutions when n = {0}", veldisvisir);
            }
        }
    }
}
