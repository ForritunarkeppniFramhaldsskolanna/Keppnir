﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiSetninga = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < fjoldiSetninga; i++)
            {
                string setning = Console.ReadLine();
                setning = setning.ToLower();
                string[] ord = setning.Split(' ');

                bool fun = false;

                for (int j = 0; j < ord.Length - 1; j++)
                {
                    char sidasti = ord[j][ord[j].Length - 1];
                    char fyrsti = ord[j + 1][0];

                    if (sidasti != fyrsti)
                    {
                        fun = false;
                        break;
                    }

                    else if (sidasti == fyrsti)
                        fun = true;
                }

                if (fun)
                    Console.WriteLine("Fun");
                else
                    Console.WriteLine("Boring");
            }
        }
    }
}
