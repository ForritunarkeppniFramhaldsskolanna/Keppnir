#include <iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;

    for(int i=0;i<t;i++)
    {
        string nafn;
        cin >> nafn;

        double weight;
        cin >> weight;

        cout << nafn << " competes in ";

        if(weight<60)
        {
            cout << "lightweight" << endl;
        }
        if((weight>=60)&(weight<=90))
        {
            cout << "middleweight" << endl;
        }
        if(weight>90)
        {
            cout << "heavyweight" << endl;
        }
    }
    return 0;
}
