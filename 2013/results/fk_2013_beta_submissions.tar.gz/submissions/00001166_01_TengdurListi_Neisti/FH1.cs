/*
Nafn skr�ar: FH1.cs
Forritari: Hallgr�mur Dav�� Egilsson
*/
using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
class FH1
{
	static void Main()
	{
        int T = Convert.ToInt32(Console.ReadLine());
        string rS = @"\d+";
        string lina = "";
        List<int> listi = new List<int>();


        for (int t = 0; t < T; t++)
        {
            string L = Console.ReadLine();
            MatchCollection matches = Regex.Matches(L, rS);

            for (int x = 0; x < matches.Count; x++)
            {
                listi.Add(Convert.ToInt32(matches[x].Value));
            }
            //foreach (var a in listi) Console.Write(a);

            listi.Reverse();

            for (int y = 0; y < listi.Count; y++)
            {
                lina += "[" + listi[y] + "]->";
            }
            lina += "NULL";
            Console.WriteLine(lina);
            listi.Clear();
            lina = "";
        }
	}
}