﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_14
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int profunarnumer = 0; profunarnumer < fjoldiProfunartilvika; profunarnumer++)
            {
                int endatala = Convert.ToInt32(Console.ReadLine());
                string strengur = "";

                for (int i = 1; i <= endatala; i++)
                    strengur += i;

                int[] teljarar = new int[10];

                for (int i = 0; i < strengur.Length; i++)
                {
                    int tala = (int)Char.GetNumericValue(strengur[i]);

                    teljarar[tala]++;
                }

                string skil = "";

                for (int tal = 0; tal < teljarar.Length; tal++)
                    skil += teljarar[tal] + " ";

                skil = skil.TrimEnd();

                Console.WriteLine(skil);
            }
        }
    }
}
