﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sort
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] fylki;
            string[] fylki2;

            bool keyra = true;

            int tilvik = Convert.ToInt32(Console.ReadLine());
            if (tilvik >= 1 && tilvik <= 1000)
            {
                for (int i = 0; i < tilvik; i++)
                {
                    fylki = Console.ReadLine().Split(' ');
                    int[] mfylki = new int[fylki.Length];
                    for (int s = 0; s < fylki.Length; s++)
                    {
                        mfylki[s] = Convert.ToInt32(fylki[s]);
                    }
                    Array.Sort(mfylki);
                    fylki2 = Console.ReadLine().Split(' ');
                    int teljari = 0;
                    if (mfylki.Length == fylki2.Length)
                    {
                        keyra = true;
                        do
                        {
                            if (mfylki[teljari].ToString() == fylki2[teljari])
                            {

                            }
                            else
                            {
                                keyra = false;
                            }
                            teljari++;
                        } while (keyra && teljari != fylki.Length);
                    }
                    else
                    {
                        keyra = false;
                    }
                    if (keyra)
                    {
                        Console.WriteLine("Accepted");
                    }
                    else
                    {
                        Console.WriteLine("Wrong Answer");
                    }
                }
            }
        }
    }
}
