#!/usr/bin/python
from sys import stdin, stdout, stderr
for i in range(int(stdin.readline())):
	num = int(stdin.readline())
	a = [0,0,0,0,0,0,0,0,0,0]
	for i in xrange(1, num+1):
		incr = 1
		while(i):
			a[i%10] += incr
			i /= 10
	for i in a:
		print i,
	print
