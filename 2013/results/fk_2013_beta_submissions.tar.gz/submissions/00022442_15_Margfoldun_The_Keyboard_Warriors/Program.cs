﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace v15
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = 0;
            int a, b, c;
            string tmp;
            char ws = Convert.ToChar(char.ConvertFromUtf32(0x00000020));
            T = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < T; i++)
            {
                a = 0;
                b = 0;
                c = 0;
                tmp = "";

                tmp = Console.ReadLine();
                a = Convert.ToInt32(tmp.Split(ws)[0]);
                b = Convert.ToInt32(tmp.Split(ws)[1]);
                c = Convert.ToInt32(tmp.Split(ws)[2]);
                if (a * b == c)
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");
                }
            }
        }
    }
}
