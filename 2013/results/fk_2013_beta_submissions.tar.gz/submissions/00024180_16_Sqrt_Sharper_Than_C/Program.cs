﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni16
{
    class Program
    {
        static void Main(string[] args)
        {
            int profunartilvik = Convert.ToInt32(Console.ReadLine());

            for (int z = 0; z < profunartilvik; z++)
            {
                string iAndN = Convert.ToString(Console.ReadLine());
                string[] arrayTemp = iAndN.Split(new char[] { ' ' }, 2);
                ulong n = Convert.ToUInt32(arrayTemp[0]);
                decimal a = 5 * n;
                decimal b = 5;
                long i = Convert.ToInt32(arrayTemp[1]);
                for (int g = 0; g < i; g++)
                {
                    if (a >= b)
                    {
                        a = a - b;
                        b = b + 10;
                    }
                    else
                    {
                        a = a * 100;
                        string tempString = b.ToString();
                        string tempString2 = tempString.Substring(tempString.Length - 1, 1);
                        tempString = tempString.Remove(tempString.Length - 1);
                        string tempString3 = tempString + "0" + tempString2;
                        b = Convert.ToDecimal(tempString3);
                    }
                }
                Console.WriteLine(b.ToString());
            }

        }


    }
}
