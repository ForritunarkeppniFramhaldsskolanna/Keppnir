﻿using System;
using System.Collections;

class V1
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        string[] ret = new string[loops];

        for (int LL = 0; LL < loops; LL++)
        {

            string[] input = Console.ReadLine().Split('-');               
            string inn="";
            
            foreach (string s in input)
            {
                inn += s;
            }
            input = inn.Split('>');

            for (int A = 0; A < input.Length; A++)
            {
                if ((input[(input.Length) - (A+1)]) != "NULL")
                {
                    ret[LL] += input[(input.Length) - (A+1)];

                    ret[LL] += "->";
                }
               


            }
          ret[LL] += "NULL";
        }

        foreach (string s in ret)
        {

            Console.WriteLine(s);
        }
    }
}


