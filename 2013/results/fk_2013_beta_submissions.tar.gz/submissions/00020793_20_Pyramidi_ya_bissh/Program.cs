﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ForKeppnieh
{
    class Program
    {
        static bool isperfect(int a) 
        {
            bool result = false;
            Regex r = new Regex(@"^(\1.|^.)+$");
            if (r.IsMatch("".PadLeft(a)))
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return (result);
        }
        static void Main(string[] args)
        {            
            int intak = Convert.ToInt32(Console.ReadLine());
            int mismunur = intak;            
            if (isperfect(intak))
            {
                
            }
            else
            {
                while (!isperfect(intak))
                {
                    intak--;//leitar af næstu tölu fyrir neðan
                }
            }
            double utkomab = Math.Sqrt((intak * 2));
            Console.Write(utkomab.ToString("# "));
            Console.Write(mismunur%intak);// Finnur út hvað eru margir auka
        }
    }
}
