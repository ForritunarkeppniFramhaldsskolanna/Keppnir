﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeMafiaVerkefni8
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < tilvik; i++)
            {
                string settning = Console.ReadLine();
                settning.ToLower();
                char[] settningarray = settning.ToCharArray();
                bool fun = true;
                for (int j = 0; j < settningarray.Length; j++)
                {
                    if (settningarray[j] == ' ')
                    {
                        if (settningarray[j - 1] != settningarray[j + 1])
                        {
                            fun = false;
                        }
                    }
                }
                if (fun == true)
                {
                    Console.WriteLine("Fun");
                }
                else
                {
                    Console.WriteLine("Boring");
                }
            }
            
            Console.ReadKey();
        }
    }
}
