public class verkefni13 {
  public static void main(String[] args) {
    
    for ( int i = 0; i < Integer.parseInt(args[0]); i++ ) {
      if ( fylgirReglum(args[1+i]) ) System.out.println("Valid");
      else System.out.println("Invalid"); }
    
  }
    
  public static boolean fylgirReglum( String a ) {
    
    a = a.toLowerCase();
    if ( a.length() == 0 ) return false;
    if ( Character.isDigit(a.charAt(0)) ) return false;
    
    boolean ekkiVilla = true;
    for ( int i = 0; i < a.length(); i++ ) {
      if ( Character.toString(a.charAt(i)).matches("!") ) return false;
      if ( !( Character.toString(a.charAt(i)).matches("[a-z]+") || Character.toString(a.charAt(i)).matches("[0-9]+") || Character.toString(a.charAt(i)).matches("_")) ) {
        ekkiVilla = false;
        break;
      }
    }
    return ekkiVilla;
  }
}
