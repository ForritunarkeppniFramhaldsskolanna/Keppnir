fjd = gets.chomp.to_i
gaman = []
(1..fjd).each do |x|
  arr =  []
  ord = gets.chomp
  ord.split(' ').each do |y|
    arr << y
  end
  
  a = arr[-2].match(/.\b/)
  b = arr[-1].match(/^./)
  
  if a.to_s == b.to_s
    gaman << "Fun"
  else
    gaman << "Boring"     
  end
end

gaman.each do |x|
  puts x
end

