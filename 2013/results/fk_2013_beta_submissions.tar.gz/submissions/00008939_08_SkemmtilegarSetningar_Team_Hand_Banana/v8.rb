fjd = gets.chomp.to_i
gaman = []
ord = "nada"      
funmeter = 0
(1..fjd).each do |x|
  arr =  []
  ord = gets.chomp
  ord.split(' ').each do |y|
    arr << y
  end
  funmeter = 0
  
    fjd = arr.length
    
    (fjd-1).times do |z|   
      a = arr[z].match(/.\z/)
      b = arr[z+1].match(/^./)
    if a.to_s.downcase != b.to_s.downcase
      funmeter += 0
    elsif a.to_s.downcase == b.to_s.downcase
      funmeter += 1   
    end
    
    if funmeter == fjd-1
      ord = "Fun"
    else
      ord = "Boring"
    end
    
    end
  gaman << ord
end
puts gaman
