﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace verk16
{
    class Program
    {
        static void Main(string[] args)
        {
            int t = Convert.ToInt32(Console.ReadLine());
            BigInteger a = new BigInteger();
            BigInteger b = new BigInteger();
            string tempb;
            string tempa;
            for (int x = 0; x < t; x++)
            {
                string[] golf = Console.ReadLine().Split();
                int n = int.Parse(golf[0]);
                int i = int.Parse(golf[1]);
                a = Convert.ToUInt64(5 * n);
                b = 5;
                for (int u = 0; u < i; u++)
                {
                    if (a >= b)
                    {
                        a = a - b;
                        b = b + 10;
                    }
                    else
                    {
                        tempa = Convert.ToString(a);
                        tempa = tempa + "00";
                        a = BigInteger.Parse(tempa);
                        tempb = Convert.ToString(b);
                        char y = tempb[tempb.Length-1];
                        tempb = tempb.Remove(tempb.Length - 1);
                        tempb = tempb + "0";
                        tempb = tempb + y;
                        b = BigInteger.Parse(tempb);
                    }
                }
                Console.WriteLine(b);
            }
        }
    }
}
