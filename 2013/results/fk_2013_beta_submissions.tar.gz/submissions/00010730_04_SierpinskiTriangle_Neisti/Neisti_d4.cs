﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class7 {
        static void Main() {
            int n = Convert.ToInt32(Console.ReadLine());
            int[] line = new int[100];
            line[0] = 1;
            int[] line2 = new int[100];
            line2[0] = 1;
            Console.WriteLine("#");
            for (int i = 2; i <= n; i++) {
                for (int j = 1; j < i; j++) {
                    line2[j] = line[j] + line[j - 1];
                }
                Array.Copy(line2, line, i);
                for (int j = 0; j < i; j++) {
                    if (line[j] % 2 == 0) Console.Write('.');
                    else Console.Write('#');
                }
                Console.WriteLine();
            }
        }
    }
}
