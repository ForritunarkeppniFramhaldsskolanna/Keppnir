﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weightlifting
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int t = 0; t < tilvik; t++)
            {
                string name = Console.ReadLine();
                double weight = Convert.ToDouble(Console.ReadLine());
                if (weight < 60)
                {
                    Console.WriteLine("{0} competes in lightweight",name);
                }
                else if (weight >= 60 && weight <= 90)
                {
                    Console.WriteLine("{0} competes in middleweight", name);
                }
                else if (weight > 90)
                {
                    Console.WriteLine("{0} competes in heavyweight", name);
                }
            }
        }
    }
}
