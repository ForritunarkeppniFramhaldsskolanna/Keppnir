﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FH_D3
{
    class Program
    {
        static void Main(string[] args)
        {
            Double prof = Convert.ToDouble(Console.ReadLine());
            

            for (int i = 0; prof > i; i++)
            {
               
                int k = Convert.ToInt32(Console.ReadLine());
                if (k > 2)
                {
                    Console.WriteLine("no solution when n = " + k);
                }
               

            }


        }
    }
}
