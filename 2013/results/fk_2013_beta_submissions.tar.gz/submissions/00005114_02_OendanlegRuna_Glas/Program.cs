﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < fjoldiProfunartilvika; i++)
            {
                string takmarkarStrengur = Console.ReadLine();
                string[] takmarkarFylki = takmarkarStrengur.Split(' ');

                int byrjun = Convert.ToInt32(takmarkarFylki[0]);
                int endir = Convert.ToInt32(takmarkarFylki[1]);

                string toluStrengur = Console.ReadLine();

                while (endir > toluStrengur.Length)
                    toluStrengur += toluStrengur;

                Console.WriteLine(toluStrengur.Substring(byrjun - 1, endir - byrjun + 1));
            }
        }
    }
}
