#!/usr/bin/python
from sys import stdin, stdout, stderr
for k in range(int(stdin.readline())):
	x, o = False,False
	n = int(stdin.readline())
	a = []
	s = str()
	for i in range(n):
		t = stdin.readline().strip()
		if not '.' in t:
			if not 'X' in t:
				o = True
			elif not 'O' in t:
				x = True
		s += t
		a.append(t)
	for i in range(n):
		t = s[i::n]
		if not '.' in t:
			if not 'X' in t:
				o = True
			elif not 'O' in t:
				x = True
	t = ""
	for i in range(n):
		t+= a[i][n-(i+1)]
	if not '.' in t:
		if not 'X' in t:
			o = True
		elif not 'O' in t:
			x = True
	t = ""
	h = 0
	for i in range(n):
		t += a[i][i]
	if not '.' in t:
		if not 'X' in t:
			o = True
		elif not 'O' in t:
			x = True
	if o and x:
		print "Error"
	elif o:
		print "O won"
	elif x:
		print "X won"
	else:
		print "Neither won"
		stderr.write("x=" + repr(x) + "; o=" + repr(o))
