fjd = gets.chomp.to_i
arr = []
(1..fjd).each do |x|
  var = gets.chomp
  
  if var.match(/^[a-zA-Z_][a-zA-Z0-9_]*$/)
    arr << "Valid"
  else
    arr << "Invalid"
  end  
end

puts arr
