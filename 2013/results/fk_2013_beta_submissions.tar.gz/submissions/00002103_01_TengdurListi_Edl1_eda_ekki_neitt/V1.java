import java.util.Scanner;

public class V1
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
    int T=sc.nextInt();
    String[] a = new String[T];
    for (int i=0; i<T; i++)
    {
      a[i]=sc.next();
      System.out.println(snua(a[i]));
    }
  }
  
  public static String snua(String a)
  {
    int s = a.length();
    int f = (s-4)/5;
    String b = "";
    for (int i=s-1; i>=0; i--)
    {
      if (a.charAt(i)=='[')
      {
        b=b+"[";
        int k=1;
        while (a.charAt(i+k)!=']')
        {
          b=b+a.charAt(i+k);
          k++;
        }
        b=b+"]->";
      }
    }
    b = b + "NULL";
    return b;
  }
}