import java.util.Scanner;
import java.util.Arrays;

public class V19
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
    int T = sc.nextInt();
    for (int i=0; i<T; i++)
    {
      int stysti = 0;
      int lengsti = 0;
      int l = sc.nextInt();
      int n = sc.nextInt();
      int[] a = new int[n];
      for (int j=0; j<n; j++)
        a[j]=sc.nextInt();
      Arrays.sort(a);
      if (l-a[0]<a[n-1])
        lengsti = a[n-1];
      else
        lengsti = l-a[0];
      double x = 0;
      for (int k=0; k<n; k++)
      {
        if (a[k]>l/2.0)
        {
          if (1-a[k]<a[k-1])
            stysti=l-a[k];
          else
            stysti=a[k-1];
          break;
        }
        
      }
      
      
      System.out.println(stysti + " " + lengsti);
      
    }
  }
}