﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verk_2
{
    class Program
    {
        static int findPos(int begin, int length)
        {
            int difference = 0;
            
            while (begin > length)
            {
                begin -= length;
                difference += length;
            }
            
            return difference;
        }

        static char arraySeat(string Array, int length, int iteration)
        {
            while (iteration > (length - 1))
            {
                iteration -= length;
            }

            return Array[iteration];
        }

        static void Main(string[] args)
        {
            int rounds = 0;
            int i , j = 0;
            string number = "";
            int numLength = 0;
            //string strLoops = new string[2];
            int[] loops = new int[2];
            string input= "";
            rounds = Convert.ToInt32(Console.ReadLine());

            while (rounds > 0)
            {
                //rounds = Convert.ToInt32(Console.ReadLine());
                input = Console.ReadLine();
                string[] strLoops = input.Split(' ');
                loops[0] = Convert.ToInt32(strLoops[0]);
                loops[1] = Convert.ToInt32(strLoops[1]);
                number = Console.ReadLine();
                numLength = number.Length;
                //Console.WriteLine("number is " + number);
                i = loops[0];
                i -= findPos(loops[0], numLength);

                j = loops[1];
                j -= findPos(loops[0], numLength);
                //Console.WriteLine("0 is " + loops[0] + " 1 is " + loops[1]);
                while (i <= j)
                {
                    Console.Write(arraySeat(number, numLength, (i-1)));

                    ++i;
                }
                Console.WriteLine();
                --rounds;
                //Console.ReadKey();
            }
        }
    }
}
