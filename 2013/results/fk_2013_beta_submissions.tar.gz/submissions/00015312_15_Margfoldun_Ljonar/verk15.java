public class verk15
{
  public static void main(String[] args)
  {
    for (int i=1; i<args.length; i = i+3)
    {
      int a = Integer.parseInt(args[i]);
      int b = Integer.parseInt(args[i+1]);
      int c = Integer.parseInt(args[i+2]);
      if (a*b == c)
        System.out.println("True");
      else System.out.println("False");
  }
}
}