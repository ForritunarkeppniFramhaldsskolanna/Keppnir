﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace d15
{
    class Program
    {
        static void Main(string[] args)
        {
            int Profunartilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < Profunartilvik; i++)
            {
                string tölur = Console.ReadLine();
                int a = int.Parse(tölur.Split(' ')[0]);
                int b = int.Parse(tölur.Split(' ')[1]);
                int c = int.Parse(tölur.Split(' ')[2]);                
                if (c==(a*b))
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");
                }
            }            
        }
    }
}
