﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace V20
{
    class Program
    {
        static void Main(string[] args)
        {
            int reikningur = 1;
           int profun;
           int fjoldi;
           int utundan = 0;
           int haed = 0;
        
            profun = Convert.ToInt32( Console.ReadLine());

          for (int i = 0; i < profun; i++)
          {
              reikningur = 1;
              haed = 0;
              utundan = 0;
              
              fjoldi = Convert.ToInt32(Console.ReadLine());
              do
              {
              if (fjoldi >= reikningur)
              {
                  fjoldi = fjoldi - reikningur;
                  haed++;
                  reikningur++;


              }
              if (fjoldi < reikningur)
              {
                  utundan = fjoldi;
              }
              

              } while (fjoldi >= reikningur);

              Console.WriteLine(haed + " " + utundan);
              

          }
            
        }
    }
}
