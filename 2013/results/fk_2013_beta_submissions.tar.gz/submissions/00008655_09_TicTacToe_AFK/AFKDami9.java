import java.util.Scanner;

class AFKDami9 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = 0, p = scan.nextInt();
		String winX = "", winO = "";
		boolean boolX = false, boolO = false;
		for (int i = 0; i < p; i++) {
			while (true) {
				n = scan.nextInt();
				if (n >= 3) {
					for (int b = 0; b < n; b++) {
						winX += "X";
						winO += "O";
					}
					break;
				}
			}
			System.out.println(winX + ":" + winO + ":" + n);
			char[][] nF = new char[n][n];
				for (int a = 0; a <= n; a++) {
					String lol = scan.nextLine();
					String test = "";
					if (lol.length() == n) {
						nF[a-1] = lol.toCharArray();
					}
				}
				String test = "";
				for (int b = 0; b < n; b++) {
					for (int c = 0; c < n; c++) {
						test += ("" + nF[b][c]); 
					}
					if (test.equalsIgnoreCase(winX)) {
						boolX = true;
					}
					if (test.equalsIgnoreCase(winO)) {
						boolO = true;
					}
					test = "";
					for (int d = 0; d < n; d++) {
						test += ("" + nF[d][b]);
					}
					if (test.equalsIgnoreCase(winX)) {
						boolX = true;
					}
					if (test.equalsIgnoreCase(winO)) {
						boolO = true;
					}
				}
				String test1 = "", test2 = "";
				int s = 0;
				for (int e = 0; e < n; e++) {
					test1 += nF[e][s];
					test2 += nF[e][(n-(s+1))];
					s++;
				}
				
				if (test1.equalsIgnoreCase(winX)) {
					boolX = true;
				}
				if (test1.equalsIgnoreCase(winO)) {
					boolO = true;
				}
				if (test2.equalsIgnoreCase(winX)) {
					boolX = true;					
				}
				if (test2.equalsIgnoreCase(winO)) {
					boolO = true;
				}
				//--------------------
				if (boolX&&boolO == true) {
					System.out.println("Error");
				}
				else if (boolX) {
					System.out.println("X won");
				}
				else if (boolO) {
					System.out.println("O won");
				}
				else {
					System.out.println("Neither won");
				}
				boolX = false;
				boolO = false;
				winX = "";
				winO = "";
		}
	}
}