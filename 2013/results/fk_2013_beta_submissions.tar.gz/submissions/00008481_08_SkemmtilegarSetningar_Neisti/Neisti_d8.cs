﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class4 {
        static void Main() {
            int tests = Convert.ToInt32(Console.ReadLine());

            for (int test = 0; test < tests; test++) {
                string[] s = Console.ReadLine().ToLower().Split(' ');
                Boolean fun = true;
                for (int i = 0; i < s.Length-1; i++) {
                    if (s[i][s[i].Length - 1] != s[i + 1][0]) fun = false;
                }
                if (fun) Console.WriteLine("Fun");
                else Console.WriteLine("Boring");
            }
        }
    }
}
