using System;
using System.Collections.Generic;
using System.Text;
using System.Numerics;


class V1
{
    static void Main(string[] args)
    {
        long loops = Convert.ToInt32(Console.ReadLine());
        for (int AA = 0; AA < loops; AA++)
        {
            string[] inn = Console.ReadLine().Split();
            BigInteger n = BigInteger.Parse(inn[0]);
            BigInteger b = 5;
            int i = Convert.ToInt32(inn[1]);
            BigInteger a = 5 * n;

            for (int f = 0; f < i; f++)
            {
                if (a >= b)
                {
                    a = a - b;
                    b = b + 10;

                }
                else
                {
                    a *= 100;
                    string bb = Convert.ToString(b);
                    bb = bb.Insert(bb.Length - 1, "0");
                    b = BigInteger.Parse(bb);

                }
            }
            Console.WriteLine(b);
        }
    }
}