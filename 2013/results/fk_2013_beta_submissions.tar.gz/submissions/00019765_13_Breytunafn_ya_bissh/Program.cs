﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace d13
{
    class Program
    {
        static bool Name(string a)
        {
            Regex pattern = new Regex(@"^[a-zA-Z0-9_]+$");
            bool result = true;
            char[] nafnarray = a.ToCharArray();
            if (Char.IsDigit(nafnarray[0]))
            {
                result = false;
            }
            else if (a == "")
            {
                result = false;
            }
            else if(!pattern.IsMatch(a))
            {
               result =false;
            }
            return result;

        }
        static void Main(string[] args)
        {
            int Profun = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < Profun; i++)
            {
                string nafn = Console.ReadLine();
                if (nafn != "")
                {
                    if (Name(nafn) == false)
                    {
                        Console.WriteLine("Invalid");
                    }
                    else
                    {
                        Console.WriteLine("Valid");
                    }
                }    
            }
        }
    }
}
