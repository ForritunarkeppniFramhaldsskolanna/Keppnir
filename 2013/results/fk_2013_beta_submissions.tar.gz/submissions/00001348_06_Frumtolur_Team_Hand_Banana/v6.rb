require 'prime'

prim = []
outcome = []

fjoldi = gets.chomp.to_i

(1..fjoldi).each do
  tala = gets.chomp.to_i
  prim = Prime.first tala
  outcome << prim[-1]
end

puts outcome