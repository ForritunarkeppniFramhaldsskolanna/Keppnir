﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
       
        static void Main(string[] args)
        {
            string Number = Console.ReadLine();
            int x = -1;
            x = Convert.ToInt32(Number);
            double th = 0;
            string[] nafn = new string[x];
            string[] þyngd = new string[x];
            for (int i = 0; i < x; i++)
            {
                nafn[i] = Console.ReadLine();
                þyngd[i] = Console.ReadLine();
                th = Convert.ToDouble(þyngd[i]);
                
            
                String weight = "";

                if (th < 60) {
                    weight = "lightweight";
                }
                else if (th > 90)
                {
                    weight = "heavyweight";
                }
                else
                {
                    weight = "middleweight";
                }
                Console.WriteLine(nafn[i] + " competes in " + weight); 
            }

        }
    }
}

