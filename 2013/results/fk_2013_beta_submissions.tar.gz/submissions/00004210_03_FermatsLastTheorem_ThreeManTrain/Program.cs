﻿using System;
public class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt16(Console.ReadLine());
            for (int i = 0; i < T; i++)
            {
                int n = Convert.ToInt32(Console.ReadLine());
                if (n > 2)
                {
                    Console.WriteLine("no solutions when n = " + n);
                }
            }
        }
    }
