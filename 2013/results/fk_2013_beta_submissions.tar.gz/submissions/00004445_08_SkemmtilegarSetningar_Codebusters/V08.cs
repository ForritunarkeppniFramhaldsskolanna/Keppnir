using System;

class Program
{
    static void Main(string[] args)
    {
        int T = Convert.ToInt32(Console.ReadLine());

        for (int x = 0; x < T; x++)
        {
            string setning = Console.ReadLine();

            string[] split = setning.ToLower().Split(' ');

            bool fun = true;

            for (int k = 0; k < split.Length-1; k++)
            {
                if ((split[k])[split[k].Length-1] != (split[k + 1])[0])
                    fun = false;

            }

            if (fun == false)
                Console.WriteLine("Boring");
            else
                Console.WriteLine("Fun");
        }
    }
}