﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verkefni_14
{
    class Program
    {
        static void Main(string[] args)
        {

            int numberOfTests;
            int number;
            
            numberOfTests = Convert.ToInt16(Console.ReadLine());
            //Main loop
            for (int i = 0; i < numberOfTests; i++)
            {
               
                number = Convert.ToInt16(Console.ReadLine());
                int[] mainArray = new int[number];
                mainArray = returnNumbers(number);

                for (int z = 0; z < mainArray.Length; z++)
                {
                    if (z + 1 <  mainArray.Length)
                    {
                      Console.Write(mainArray[z] + " ");
                    }
                    else
                    {

                        Console.Write(mainArray[z]);
                    }
                } 
               
                    Console.Write("\n");
                
            }
            Console.WriteLine("\n");
          
        }

        public static int[] returnNumbers(int number)
        {
            string numbers = generateNumber(number);
            int[] howManyNumbers = new int[10];

            for (int i = 1; i < numbers.Length + 1; i++)
            {
                for (int z = 0; z < howManyNumbers.Length; z++)
                {
                    if (numbers[i - 1].ToString() == z.ToString())
                    {
                        howManyNumbers[z]++;   
                    }   
                }
            }
            return howManyNumbers;
        }

        public static string generateNumber( int size )
        {
            string number = null;

            for (int i = 1; i < size + 1; i++)
            {
                number += i.ToString();
            }
           
            return number;
        }//generateNumber ends     
    }
}
