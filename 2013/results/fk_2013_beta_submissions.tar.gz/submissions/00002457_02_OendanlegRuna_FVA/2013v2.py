def parse(segment, number):
    segment = segment.split()
    lower = int(segment[0])-1
    upper = int(segment[1])
    total = ""
    if(not len(number) <= 100):
        return "ups"
    done = False
    while(not done):        
        total += number
        if(len(total) >= upper):
            done = True  
    return str(total)[lower:upper]
        

x = raw_input()
x = int(x)
segment = []
number = []
if(x >= 1 and x <= 100):            
    for i in range(x):
        segment.append(raw_input())
        number.append(raw_input())
    for i in range(x):
        print parse(segment[i], number[i])
else:
    print "Rangur fjoldi profunartilvika."
