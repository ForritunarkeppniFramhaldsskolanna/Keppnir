﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class2 {
        static void Main(string[] args) {
            int tests = Convert.ToInt32(Console.ReadLine());

            for (int test = 0; test < tests; test++) {
                string[] input = Console.ReadLine().Split(' ');
                int Q = stepsQ(getInt(input[1]), getInt(input[2]), getInt(input[3]), getInt(input[4]));
                int K = stepsK(getInt(input[1]), getInt(input[2]), getInt(input[3]), getInt(input[4]));
                if (Q < K) Console.WriteLine("Queen");
                else if (Q == K) Console.WriteLine("Same");
            }
        }

        static int getInt(string s) {
            return Convert.ToInt32(s);
        }

        static int stepsQ(int x1, int y1, int x2, int y2) {
            if (x1 == x2 && y1 == y2) return 0;
            int x = Math.Abs(x2 - x1), y = Math.Abs(y2 - y1);
            if (x1 == x2 || y1 == y2 || x == y) return 1;
            else return 2;
        }

        static int stepsK(int x1, int y1, int x2, int y2) {
            int x = Math.Abs(x2 - x1), y = Math.Abs(y2 - y1);
            if (x > y) return x;
            else return y;
        }
    }
}
