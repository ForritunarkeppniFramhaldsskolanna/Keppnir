﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni2Runa
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < tilvik; i++)
            {
                string tolur = Console.ReadLine();
                string[] tala = tolur.Split(' ');
                int tala1 = Convert.ToInt32(tala[0]);
                int tala2 = Convert.ToInt32(tala[1]);

                string talan = Console.ReadLine();
                do
                {
                int numerstafa = talan.Length;
                talan = talan + talan;
                } while (talan.Length < tala2);
                string lokatala = null;
                for (int k = 0; k < tala2 - tala1 + 1; k++)
                {
                    lokatala += (talan[tala1 + k - 1]);
                }
                Console.WriteLine(Convert.ToInt32(lokatala));
            }
            Console.ReadLine();
        }
    }
}
