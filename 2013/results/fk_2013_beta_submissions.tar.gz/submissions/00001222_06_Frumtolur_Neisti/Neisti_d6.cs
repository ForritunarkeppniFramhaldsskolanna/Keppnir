﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Program {
        static void Main(string[] args) {
            int tests = Convert.ToInt32(Console.ReadLine());

            int[] primes = new int[1000];
            primes[0] = 2;
            for (int i = 1, j = 3; i < 1000; j += 2) {
                if (isPrime(j)) {
                    primes[i] = j;
                    i++;
                }
            }

            for (int test = 0; test < tests; test++) {
                Console.WriteLine(primes[Convert.ToInt32(Console.ReadLine())-1]);

            }
        }

        static Boolean isPrime(int n) {
            for (int i = 3; i * i <= n; i++) {
                if (n % i == 0) return false;
            }
            return true;
        }
    }
}
