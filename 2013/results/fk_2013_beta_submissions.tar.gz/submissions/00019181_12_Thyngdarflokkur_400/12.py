#!/usr/bin/python
from sys import stdin, stdout, stderr
for i in range(int(stdin.readline())):
	name = stdin.readline().strip()
	weight = float(stdin.readline())
	stdout.write("competes in ")
	if weight < 60:
		print "lightweight"
	elif weight > 90:
		print "heavyweight"
	else:
		print "middleweight"
