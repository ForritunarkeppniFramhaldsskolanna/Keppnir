﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int staerdSkammhlidar = Convert.ToInt32(Console.ReadLine());

            int[][] thrihyrningur = new int[staerdSkammhlidar][];

            for (int radarnumer = 0; radarnumer < staerdSkammhlidar; radarnumer++)
            {
                int[] rod = new int[radarnumer + 1];

                for (int dalkanumer = 0; dalkanumer <= radarnumer; dalkanumer++)
                {
                    int gildi = 0;

                    if (dalkanumer == 0 || dalkanumer == radarnumer)
                    {
                        gildi = 1;
                        Console.Write("#");
                    }
                    else
                    {
                        gildi = thrihyrningur[radarnumer - 1][dalkanumer - 1] + thrihyrningur[radarnumer - 1][dalkanumer];

                        if (gildi % 2 == 0)
                            Console.Write(".");
                        else
                            Console.Write("#");
                    }

                    rod[dalkanumer] = gildi;
                }

                thrihyrningur[radarnumer] = rod;

                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
