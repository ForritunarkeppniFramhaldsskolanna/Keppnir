﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeMafiaVerkefni11
{
    class Program
    {
        static void Main(string[] args)
        {
            int runTime = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < runTime; i++)
            {
                bool flag = true;

                string input = Console.ReadLine();
                string[] tempArray = input.Split(' ');

                List<int> numbers1 = new List<int>();
                foreach (var item in tempArray)
                    numbers1.Add(Convert.ToInt32(item));

                numbers1.Sort();

                input = Console.ReadLine();
                tempArray = input.Split(' ');

                List<int> numbers2 = new List<int>();
                foreach (var item in tempArray)
                    numbers2.Add(Convert.ToInt32(item));

                for (int x = 0; x < numbers1.Count; x++)
                {
                    if (numbers1[x] != numbers2[x])
                        flag = false;
                }

                if (flag == false)
                    Console.WriteLine("Wrong Answer");

                else
                    Console.WriteLine("Accepted");


            }
            Console.ReadKey();
        }
    }
}
