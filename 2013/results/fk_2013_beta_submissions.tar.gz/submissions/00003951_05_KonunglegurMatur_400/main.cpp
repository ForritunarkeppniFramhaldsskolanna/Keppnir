#include <iostream>

using namespace std;

int main()
{
    int t;
    int a;
    int b;
    int c;
    int d;
    int e;
    cin >> t;
    for(int i=0; i<t; i++)
    {
        cin >> a >> b >> c >> d >> e;

        if ((((b==d) | (b-d==1) | (d-b==1)) & ((c==e) | (c-e==1) | (e-c==1)))
             | (((c-e==1) & (b-d==2)) | ((c-e==2) & (b-d==1)) | ((e-c==1) & (b-d==2)) | ((e-c==2) & (b-d==1))
             | ((c-e==1) & (d-b==2)) | ((c-e==2) & (d-b==1)) | ((e-c==1) & (d-b==2)) | ((e-c==2) & (d-b==1))))
        {
            cout << "Same" << endl;
        }
        else
            {
                cout << "Queen" << endl;
            }
    }
    return 0;
}
