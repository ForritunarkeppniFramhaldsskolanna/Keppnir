﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace furgleblurp_d12
{
    class furgleblurp_d12
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < T; i++)
            {
                string name = Console.ReadLine();
                double weight = Convert.ToDouble(Console.ReadLine());
                string cat = null;
                if (weight<60)
                {
                    cat = "lightweight";
                    Console.WriteLine(name + " competes in " + cat);
                }
                else if (weight>=60&&weight<=90)
                {
                    cat = "middleweight";
                    Console.WriteLine(name + " competes in " + cat);
                }
                else if (weight>90)
                {
                    cat = "heavyweight";
                    Console.WriteLine(name + " competes in " + cat);
                }
            }
            Console.ReadLine();
        }
    }
}
