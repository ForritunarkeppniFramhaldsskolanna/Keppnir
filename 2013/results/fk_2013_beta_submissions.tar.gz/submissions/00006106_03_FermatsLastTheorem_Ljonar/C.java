public class C
{
  public static void main(String[] args)
  {
    int T = Integer.parseInt(args[0]);
    for(int i = 1; i<=T; i++)
    {
      long n = Long.parseLong(args[i]);
      System.out.println("no solutions when n = " + n);
      
  }
  }
}