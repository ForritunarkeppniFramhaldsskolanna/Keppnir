﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni14Samliggjandi
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tilvik; i++)
            {
                int count0 = 0;
                int count1 = 0;
                int count2 = 0;
                int count3 = 0;
                int count4 = 0;
                int count5 = 0;
                int count6 = 0;
                int count7 = 0;
                int count8 = 0;
                int count9 = 0;
                string runan = null;
                int teljauppi = Convert.ToInt32(Console.ReadLine());
                for (int k = 1; k < teljauppi + 1; k++)
                {
                    runan += Convert.ToString(k);
                }
                char[] a = runan.ToCharArray();
                foreach (var item in a)
                {
                    if (item == '0')
                        count0++;
                    else if (item == '1')
                        count1++;
                    else if (item == '2')
                        count2++;
                    else if (item == '3')
                        count3++;
                    else if (item == '4')
                        count4++;
                    else if (item == '5')
                        count5++;
                    else if (item == '6')
                        count6++;
                    else if (item == '7')
                        count7++;
                    else if (item == '8')
                        count8++;
                    else if (item == '9')
                        count9++;


                }
                Console.WriteLine(count0 + " " + count1 + " " + count2 + " " + count3 + " " + count4 + " " + count5 + " " + count6 + " " + count7 + " " + count8 + " " + count9);
            }
            Console.ReadLine();
        }
    }
}
