﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verk_11
{
    class Program
    {
        static int[] name(string input)
        {
            int length = 0;
            string[] text = new string[1000];
            text = input.Split(' ');
            length = text.Length;
            int[] array = new int[length];

            for (int i = 0; i < length; ++i)
            {
                array[i] = Convert.ToInt32(text[i]);
            }

            return array;
        }

        static void Main(string[] args)
        {
            int rounds = 0;
            //string input = "";
            int[] nsort = new int[1000];
            int[] ysort = new int[1000];

            rounds = Convert.ToInt32(Console.ReadLine());

            while (rounds > 0)
            {
                bool yes = true;
                nsort = name(Console.ReadLine());
                ysort = name(Console.ReadLine());

                if (nsort.Length != ysort.Length)
                {
                    yes = false;
                    Console.WriteLine("Wrong Answer");
                }
                else
                {
                    Array.Sort(nsort);

                    for (int i = 0; i < nsort.Length; ++i)
                    {
                        if (nsort[i] != ysort[i])
                        {
                            Console.WriteLine("Wrong Answer");
                            yes = false;
                            break;
                        }
                    }
                }
                if (yes)
                {
                    Console.WriteLine("Accepted");
                }
                /*
                foreach (var item in nsort)
                {
                    Console.Write(item.ToString() + " ");
                    if ()
                    {
                    }
                }
                */
                
                

                --rounds;
            }
            //Console.ReadKey();
        }
    }
}
