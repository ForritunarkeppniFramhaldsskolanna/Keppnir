﻿using System;
using System.Collections;

class V1
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        string[] ret = new string[loops];
        for (int AAA=0;AAA<loops; AAA++)
        {
            string[] input = (Console.ReadLine()).Split(' ');
            int[] realin = new int[5];
            for (int A = 0; A < 5; A++)
            {
                realin[A] = Convert.ToInt32(input[A]);
            }

            if ((realin[1] > realin[0]) || (realin[2] > realin[0]) || (realin[3] > realin[0]) || (realin[4] > realin[0]))
            {
                ret[AAA] = "impossible";
            }

            else
            {
                if ((Math.Abs(realin[1] - realin[3]) < 2) && (Math.Abs(realin[2] - realin[4]) < 2))
                {
                    ret[AAA] = "Same";
                }

                else
                {
                    ret[AAA] = "Queen";
                }
            }
        }
        foreach (string s in ret)
        {
            Console.WriteLine(s);

        }
    }
}


