def foo(n):
    tolur = n.split()
    n = long(tolur[0])
    i = long(tolur[1])
    if(n > 1 and n <= 10000 and i >= 1 and i <= 1000):
        a = 5*n
        b = 5
        while(i > 0):
            if(a >= b):
                a -= b
                b += 10
            else:
                newa = str(a) + "00"
                newb = str(b)
                if(len(newb)>1):
                    newb = newb[:-1]+"0"+newb[-1]
                a = long(newa)
                b = long(newb)
            i-=1
        print b
    return True
        
            
        

T = int(raw_input())
numbers = []

if(T>=1 and T<=100):
    for i in range(T):
        numbers.append(raw_input())

    for i in range(T):
        foo(numbers[i])
