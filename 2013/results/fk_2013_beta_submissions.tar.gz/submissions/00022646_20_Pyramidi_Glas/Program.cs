﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_20
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int numerPofunartilviks = 0; numerPofunartilviks < fjoldiProfunartilvika; numerPofunartilviks++)
            {
                int fjoldiKeppanda = Convert.ToInt32(Console.ReadLine());

                int y = 0,
                    i = 1;
                int counter = 0;

                for (; y <= fjoldiKeppanda; i++)
                {
                    counter++;
                    y += i;

                    if (y + i + 1 > fjoldiKeppanda)
                        break;
                }

                Console.WriteLine("{0} {1}", counter, fjoldiKeppanda - y);
            }
        }
    }
}
