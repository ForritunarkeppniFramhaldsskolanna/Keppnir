﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class12 {
        static void Main() {
            int tests = Convert.ToInt32(Console.ReadLine());
            for (int test = 0; test < tests; test++) {
                int year = Convert.ToInt32(Console.ReadLine());
                year %= 400;
                int offset = 0;
                for (int i = year-1; i >= 0; i--) {
                    if (isLeapyear(i)) offset += 2;
                    else offset+=1;
                }
                offset %= 7;
                int[] list = {3, 0, 3, 2, 3, 2, 3, 3, 2, 3, 2, 3};
                if (isLeapyear(year)) list[1] = 1; 
                int result = 0;
                for (int i = 0; i < 12; i++) {
                    if (offset % 7 == 1) result++;
                    offset += list[i];
                }
                Console.WriteLine(result);
            }
        }
        static Boolean isLeapyear(int y) {
            return (y % 4==0&&(y%100!=0||y%400==0));
        }
    }
}
