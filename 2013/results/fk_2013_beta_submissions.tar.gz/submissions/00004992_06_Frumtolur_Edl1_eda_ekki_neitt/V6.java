import java.util.Scanner;

public class V6
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
    int t = sc.nextInt();
    for (int i=0; i<t; i++)
    {
      int b = sc.nextInt();
      System.out.println(prime(b));
    }
  }
  
  public static int prime(int b)
  {
    int i=1;
    int f=1;
    while (i<=b)
    {
      int k=0;
      for (int j=1; j<f; j++)
      {
        if (f%j==0)
          k++;
      }
      if (k==1)
        i++;
      f++;
    }
    return f-1;
  }
}