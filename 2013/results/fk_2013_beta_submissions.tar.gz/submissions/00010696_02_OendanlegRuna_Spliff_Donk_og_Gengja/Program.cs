﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace d2
{
    class Program
    {
        static void Main(string[] args)
        {
            

            
            string runaString = Console.ReadLine();

            int t = Convert.ToInt32(Console.ReadLine());
            int i = Convert.ToInt32(Console.ReadLine());
            int j = Convert.ToInt32(Console.ReadLine());
            
            
           

            for (int iss = 0; iss <= t; iss++)
            {

                runaString = runaString+runaString;
                
                   
            }


            string runaStringEitthvad = runaString.Substring(i-1, ((j-i)+1));
            
         
               /* for (int irr = 0; irr <= (j - i); irr++)
                {
                    runaArray[irr] = runaString[irr];
                }*/
                Console.WriteLine(runaStringEitthvad);
            
            
            



        }
    }
}
