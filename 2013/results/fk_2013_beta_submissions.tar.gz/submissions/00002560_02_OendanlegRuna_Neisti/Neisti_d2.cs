﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class1 {
        static void Main(string[] args) {
            int tests = Convert.ToInt32(Console.ReadLine());

            for (int test = 0; test < tests; test++) {
                string n = Console.ReadLine();
                string[] index = n.Split(' ');
                string s = Console.ReadLine();
                for (int i = Convert.ToInt32(index[0]); i <= Convert.ToInt32(index[1]); i++) {
                    Console.Write(s[(i-1) % s.Length]);
                }
                Console.WriteLine();
            }
        }
    }
}
