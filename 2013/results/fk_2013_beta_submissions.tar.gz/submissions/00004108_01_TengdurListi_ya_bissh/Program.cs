﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace D6_yabissh
{
    class Program
    {
        public static bool isprime(int n)
        {
            bool result = true;
            for (int i = 2; i < (n - 1); i++)
            {
                if (n % i == 0)
                {
                    result = false;
                }
            }
            return result;
        }
        static void Main(string[] args)
        {
            int fjöldi = int.Parse(Console.ReadLine());
            int[] Primes = new int[fjöldi];
            int teljari = 0, posibpri = 2;
            for (int i = 0; i < fjöldi; i++)
            {
                Primes[i] = int.Parse(Console.ReadLine());
                while (teljari != Primes[i])
                {
                    if (isprime(posibpri))
                    {
                        teljari++;
                        
                    }
                    posibpri++;

                }
                Console.WriteLine((posibpri-1).ToString());
            }                   
            

            
            
            

        }
    }
}
