fjd = gets.chomp.to_i
tala = []
outcome = []

(1..fjd).each do |x|
  tala = gets.chomp.to_i  
  
    dict = Hash[
      0, 0,
      1, 0,
      2, 0,
      3, 0,
      4, 0,
      5, 0,
      6, 0, 
      7, 0,
      8, 0,
      9, 0
      ]    
  
  (1..tala).each do |z|
    arr = []
    arr = z.to_s.split('').map(&:to_i)
    arr.each do |i|
      dict[i] += 1
    end    
  end  
  10.times do |o|
    outcome << dict[o]
  end
end
moh = 0
meh = 10
fjd.times do
  (moh...meh).each do |u|
    print outcome[u]
    if u != meh-1
      print " "
    end
  end
  puts ""
  moh = meh
  meh += 10
end
