﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace v14
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = 0;

            int pt = 0;

            int[] op = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            string s = "";

            T = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < T; i++)
            {
                op = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                s = "";
                pt = Convert.ToInt32(Console.ReadLine());
                for (int o = 1; o <= pt; o++)
                {
                    s += o.ToString();
                }
                foreach (char c in s)
                {
                    op[c-48]++;
                }
                foreach (int g in op)
                {
                    Console.Write(g + " ");
                }
                for (int u = 0; u < 10; u++)
                {
                    op[u] = 0;
                }
                Console.WriteLine();
            }
        }
    }
}
