﻿using System;


    class V2
    {
        static void Main()
        {
            int loops=Convert.ToInt32(Console.ReadLine());
            string[] ret = new string[loops];

            for (int IA = 0; IA < loops; IA++)
            {
                string[] stringinput = Console.ReadLine().Split(' ');
                int[] input = new int[2];
                input[0]=Convert.ToInt32(stringinput[0]);
                input[1]=Convert.ToInt32(stringinput[1]);
                string N = Console.ReadLine();
                string skil="";
                for (int i = 0; i <= Math.Abs(input[0] - input[1]); i++)
                {
                    skil += N[((input[0]-1) + i) % (N.Length)];
                }
                ret[IA] = skil;
            }

            foreach (string s in ret)
            {
                Console.WriteLine(s);
            }
        }
    }

