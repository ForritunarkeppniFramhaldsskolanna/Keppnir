#!/usr/bin/python
from sys import stdin, stdout
n = int(stdin.readline())
for i in range(n):
	stdout.write("no solution when n = " + stdin.readline())

