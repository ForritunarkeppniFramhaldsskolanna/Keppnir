﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oendanleg_Runa
{
    class Program
    {
        static void Main(string[] args)
        {
           int tilvik = Convert.ToInt32(Console.ReadLine());
           for (int i = 0; i < tilvik; i++)
           {
                    // -------------- Declaring ------------------- //
                    string theBigText = "";
                    string outputText = "";
                    
                    string temptexti = Console.ReadLine();
                    string[] tempFylki = temptexti.Split(' ');
                    int[] bendar = new int[2];
                    
               
                    // les in bendla
                    for (int a = 0; a < tempFylki.Count(); a++)
                    {
                        bendar[a] = Convert.ToInt32(tempFylki[a]);
                    }
                    int bilAMilliBenda = (bendar[1] - bendar[0]);

                    string parturAfTexta = Console.ReadLine();

                    double tala = bilAMilliBenda / parturAfTexta.Count();
                    if (tala < 5)
                    {
                        tala = 6;
                    }
                    
                    // Setur inn þrefaldan textga í string
                    for (int a = 0; a < Math.Ceiling(tala)*2; a++)
                    {
                        theBigText += parturAfTexta;
                    }
                    
                    // notar modulus sem byrjanda
                    int modulusGaurinn = bendar[0] % parturAfTexta.Count();
                    for (int m = modulusGaurinn+parturAfTexta.Count() - 1; m < bilAMilliBenda+modulusGaurinn+parturAfTexta.Count(); m++)
                    {
                        outputText += theBigText[m];
                    }
                    Console.WriteLine(outputText);
           }
           Console.ReadLine();
        }
    }
}
