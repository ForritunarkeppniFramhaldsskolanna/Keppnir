def foo(n):
    runa = ""
    for i in range(1,n+1):
        runa += str(i)
        
    count = []
    for i in range(10):
        count.append(0)
        for digit in runa:
            if(str(digit) == str(i)):
                count[i]+=1
    prenta = ""
    for digit in count:
        prenta += str(digit)+" "
    return prenta
        
        

T = int(raw_input())
number = []

if(T>=1 and T<=20):
    for i in range(T):
        number.append(int(raw_input()))

    for i in range(T):
        if (number[i]>=1 and number[i] <= 10000):
            print foo(number[i])
