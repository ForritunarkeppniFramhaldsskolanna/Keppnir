﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace furgleblurp_d1
{
    class furgleblurp_d1
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            List<int> list=new List<int>();
            for (int i = 0; i < (T-1); i++)
            {
                int a = Convert.ToInt32(Console.ReadLine());
                list.Add(a);
            }
            list.Reverse();
            for (int i = 0; i < list.Count; i++)
            {
                Console.Write(list[i]+" ");
            }
            Console.Write("NULL");
        }
    }
}
