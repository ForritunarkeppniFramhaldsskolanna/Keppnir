﻿using System;
using System.Collections.Generic;
using System.Text;


class Class1
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        string[] ret = new string[loops];
        for (int AA = 0; AA < loops; AA++)
        {
            int N = Convert.ToInt32(Console.ReadLine());
            {
                int i=0;
                int floors=1;
               while ((i+1)<=N)
                {
                   i+=1;
                       N-=i;
                   floors+=1;
                }
               ret[AA] += (floors-1);
               ret[AA] += " ";
                    ret[AA]+=N;
            }
        }
        foreach (string s in ret)
        {
            Console.WriteLine(s);
        }
    }

}