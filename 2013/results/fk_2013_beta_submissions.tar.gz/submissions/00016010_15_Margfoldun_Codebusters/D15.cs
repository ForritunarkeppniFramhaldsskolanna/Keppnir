using System;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());

            for (int x = 0; x < T; x++)
            {
                string inntak = Console.ReadLine();
                string[] split = inntak.Split(' ');

                int[] tolur = new int[3];

                for (int i = 0; i < 3; i++)
                    tolur[i] = Convert.ToInt32(split[i]);

                if ((tolur[0] * tolur[1]) == tolur[2])
                    Console.WriteLine("True");
                else
                    Console.WriteLine("False");
            }
        }

    }
}