﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SortNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int t = 0; t < tilvik; t++)
            {
                int[] Tolur = ReadInAndSeperateOnSpace();
                int[] Svar = ReadInAndSeperateOnSpace();
                bool WrongAnswer = false;

                Array.Sort(Tolur);
                if (Svar.Count() == Tolur.Count())
                {
                    for (int i = 0; i < Tolur.Count(); i++)
                    {
                        if (Tolur[i] != Svar[i])
                        {
                            WrongAnswer = true;
                            break;
                        }
                    }
                    if (WrongAnswer)
                    {
                        Console.WriteLine("Wrong Answer");
                    }
                    else
                    {
                        Console.WriteLine("Accepted");
                    }
                }
                else
                {
                    Console.WriteLine("Wrong Answer");
                }
                
            }

        }

        static int[] ReadInAndSeperateOnSpace()
        {
            string texti = Console.ReadLine();
            string[] tempArray = texti.Split(' ');
            int[] returnArray = new int[tempArray.Count()];
            for (int i = 0; i < tempArray.Count(); i++)
            {
                returnArray[i] = Convert.ToInt32(tempArray[i]);
            }
            return returnArray;
        }
    }
}
