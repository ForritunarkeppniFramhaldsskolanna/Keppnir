﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeMafiaVerkefni20
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < tilvik; i++)
            {
                int fjoldi = Convert.ToInt32(Console.ReadLine());
                int hruga = 1, afgangur = 0;
                while (fjoldi - hruga >= 0)
                {
                    fjoldi = fjoldi - hruga;
                    hruga++;
                }
                afgangur = fjoldi;
                Console.Write(hruga-1);
                Console.WriteLine(" " +afgangur);
                
            }
            Console.ReadKey();
        }
    }
}
