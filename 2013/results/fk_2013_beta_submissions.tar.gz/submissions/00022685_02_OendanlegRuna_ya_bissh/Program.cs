﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ÓendaLeg_runa
{
    class Program
    {
        static void Main(string[] args)
        {
            string bill = "";

            string oendaleg_runna = "";
            
            int teljari = 0;

            teljari = Convert.ToInt32(Console.ReadLine());
            if (teljari >= 1 && teljari <= 100)
            {
                for (int i = 0; i < teljari; i++)
                {
                    string[] tolur = Console.ReadLine().Split(' ');
                    int tala_1 = Convert.ToInt32(tolur[0]);
                    int tala_2 = Convert.ToInt32(tolur[1]);
                    int teljari2 = tala_2 - tala_1;
                    int teljari3 = 0;
                    if (tala_2 >= tala_1 && tala_1 >= 1 && tala_2 >= 1 && tala_1 <= Math.Pow(10, 9) && tala_2 <= Math.Pow(10, 9)&& (tala_2 - tala_1)< Math.Pow(10,4))
                    {
                        string val = Console.ReadLine();
                        int talan = (tala_2 / val.Length)+5;
                        oendaleg_runna = "";
                        bill = "";
                        for (int s = 0; s < talan; s++)
                        {
                            oendaleg_runna += val;
                        }
                        do
                        {
                            bill += oendaleg_runna[(tala_1 + teljari3-1)];
                            teljari2++;
                            teljari3++;

                        } while ((tala_2 - tala_1) >= teljari3);
                    }
                    Console.WriteLine(bill);
                }
            }
        }
    }
}
