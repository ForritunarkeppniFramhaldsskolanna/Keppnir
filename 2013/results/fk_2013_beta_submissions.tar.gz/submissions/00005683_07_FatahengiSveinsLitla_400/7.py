#!/usr/bin/python
from sys import stdin, stdout, stderr

ans = [0,1,2,9,44,265,1854,14833, 133496]
for j in range(int(stdin.readline())):
	i = int(stdin.readline())
	print ans[i-1]
