import java.util.Scanner;
import java.io.*;
import java.lang.*;

public class V8
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    int tilvik = input.nextInt();
    String strengur = input.nextLine();
    for(int i = 0; i < tilvik; i++)
    {
      int tala = 0;
      int tala2 = 0;
      strengur = input.nextLine();
      for (int j = 0; j < strengur.length(); j++)
      {
        if(strengur.charAt(j) == ' ')
        {
          char stafur = strengur.charAt(j-1);
          char stafur2 = strengur.charAt(j+1);
          char stor = Character.toUpperCase(stafur);
          char stor2 = Character.toUpperCase(stafur2);
          if(stor == stor2)
          {
            tala2++;
          }
          tala++;
        }
      }
      if (tala == tala2 && tala != 0 && tala2 != 0)
        System.out.println("Fun");
      else
        System.out.println("Boring");
    }
  }
}