﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oendanelg_runa_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int o = 0; o < oft; o++)
            {
                string[] temp = Console.ReadLine().Split();
                int i = int.Parse(temp[0]);
                int j = int.Parse(temp[1]);
                int teljari = 0;
                for (int u = i; u <= j; u++)
                {
                    teljari++;
                }
                string tala = Console.ReadLine();
                char[] tala2 = new char[j+1];
                int counter = 0;
                for (int c = 1; c < j+1; c++)
                {
                    if (counter < tala.Length)
                    {
                        tala2[c] = tala[counter];
                        counter++;
                    }
                    else
                    {
                        counter = 0;
                        tala2[c] = tala[counter];
                        counter++;
                    }
                }
                for (int x = i; x <= j; x++)
                {
                    Console.Write(tala2[x]);
                }
                
                /*int teljari2 = 0;
                teljari2 = teljari % tala.Length;
                int counter = 1;
                if (i < tala2.Length && i != 1)
                {
                    counter = i;
                }
                if (i == 1)
                {
                    teljari -= 1;
                }
                for (int x = 0; x < teljari + 1; x++)
                {
                    if (counter <= tala2.Length)
                    {
                        Console.Write(tala2[counter - 1]);
                        counter++;
                    }
                    else
                    {
                        counter = 1;
                    }
                }*/
                Console.Write("\n");
            }
            
        }
    }
}
