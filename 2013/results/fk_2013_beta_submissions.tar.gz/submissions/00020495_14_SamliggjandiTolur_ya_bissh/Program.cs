﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Samliggjandi_tölur
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = Convert.ToInt32(Console.ReadLine());
            if (teljari >= 1 && teljari <=20)
            {
                for (int s = 0; s < teljari; s++)
                {
                    int tilvik = Convert.ToInt32(Console.ReadLine());
                    string strengur = "";
                    for (int i = 0; i < tilvik; i++)
                    {
                        strengur += (i + 1);
                    }
                    int[] tiustafir = new int[10];

                    for (int i = 0; i < strengur.Length; i++)
                    {
                        switch (strengur[i])
                        {
                            case '0':
                                {
                                    tiustafir[0]++;
                                    break;
                                }
                            case '1':
                                {
                                    tiustafir[1]++;
                                    break;
                                }
                            case '2':
                                {
                                    tiustafir[2]++;
                                    break;
                                }
                            case '3':
                                {
                                    tiustafir[3]++;
                                    break;
                                }
                            case '4':
                                {
                                    tiustafir[4]++;
                                    break;
                                }
                            case '5':
                                {
                                    tiustafir[5]++;
                                    break;
                                }
                            case '6':
                                {
                                    tiustafir[6]++;
                                    break;
                                }
                            case '7':
                                {
                                    tiustafir[7]++;
                                    break;
                                }
                            case '8':
                                {
                                    tiustafir[8]++;
                                    break;
                                }
                            case '9':
                                {
                                    tiustafir[9]++;
                                    break;
                                }
                            default:
                                break;
                        }
                    }
                    Console.WriteLine(tiustafir[0].ToString()+" " + tiustafir[1].ToString()+ " " + tiustafir[2].ToString()+ " " + tiustafir[3].ToString() + " " + tiustafir[4].ToString()+" " + tiustafir[5].ToString()+" " + tiustafir[6].ToString()+" " + tiustafir[7].ToString()+" " + tiustafir[8].ToString()+" " + tiustafir[9].ToString());
                }  
            }
        }
    }
}
