﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_6
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program().Run();
        }

        void Run()
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < fjoldiProfunartilvika; i++)
            {
                int frumtolunumer = Convert.ToInt32(Console.ReadLine());

                int count = 0,
                    tala = 0;

                while (count < frumtolunumer)
                {
                    tala++;

                    if (erFrumtala(tala))
                        count++;
                }

                if (count == frumtolunumer)
                    Console.WriteLine(tala);
            }
        }

        public bool erFrumtala(int tala)
        {
            if ((tala & 1) == 0)
                return (tala == 2) ? true : false;

            for (int i = 3; (i * i) <= tala; i += 2)
            {
                if ((tala % i) == 0)
                    return false;
            }
            return tala != 1;
        }
    }
}
