﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tolur_V14
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int x = 0; x < oft; x++)
            {
                int total = Convert.ToInt32(Console.ReadLine());
                string tala = "";
                int[] nr = new int[10];
                int counter = 1;
                for (int i = 0; i < total; i++)
                {
                    tala += Convert.ToString(counter);
                    counter++;
                }
                for (int f = 0; f < tala.Length; f++)
                {
                    for (int c = 0; c < 10; c++)
                    {
                        int temp = int.Parse(Convert.ToString(tala[f]));
                        if (temp == c)
                            nr[c]++;

                    }
                }
                for (int o = 0; o < 9; o++)
                {
                    if ((o+1) == 9)
                        Console.Write(nr[o]);
                    else
                        Console.Write(nr[o] + " ");
                }

                Console.Write("\n");

            }
        }
    }
}
