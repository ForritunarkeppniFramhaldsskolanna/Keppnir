#!/usr/bin/python
from sys import stdin, stdout
n = int(stdin.readline())
for i in range(n):
	l = stdin.readline().strip().split('->')
	for k in range(len(l)):
		l[k] = l[k].strip('[]')
	l = l[:-1]
	l = l[::-1]
	for s in l:
		stdout.write('[' + s + ']->')
	print('NULL')
	
