﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeMafiaVerkefni13
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < tilvik; i++)
            {
                string settning = Console.ReadLine().ToLower();
                char[] settningarray = settning.ToCharArray();
                bool valid = true;
                if (settning == "" || char.IsDigit(settningarray[0]))
                {
                    valid = false;
                }
                else
                {
                    for (int j = 0; j < settningarray.Length; j++)
                    {
                        if (settningarray[j] == '_' || char.IsLetterOrDigit(settningarray[j]))
                        {

                        }
                        else
                        {
                            valid = false;
                        }
                    }
                }
                if (valid == true)
                {
                    Console.WriteLine("Valid");
                }
                else if (valid == false)
                {
                    Console.WriteLine("Invalid");
                }
                else
                {
                    Console.WriteLine("Villa");
                }
                {

                }
            }
            Console.ReadKey();
        }
    }
}
