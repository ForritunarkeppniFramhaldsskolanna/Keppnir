﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verk3
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            int n;
            for (int i = 0; i < T; i++)
            {
                n = Convert.ToInt32(Console.ReadLine());
                if (n > 2)
                {
                    Console.WriteLine("no solutions when n = " + n);
                }
            }
        }
    }
}
