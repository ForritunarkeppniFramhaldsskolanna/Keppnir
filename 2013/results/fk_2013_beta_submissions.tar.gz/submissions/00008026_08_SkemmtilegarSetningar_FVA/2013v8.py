def compare(sentence):
    words = sentence.split()
    for i in range(len(words)):
        if(i>0):
            first = words[i-1][-1]
            last = words[i][0]
            if(first != last):
                return "Boring"
    return "Fun"

T = int(raw_input())
sentence = []

if(T >= 1 and T <= 100):
    for i in range(T):
        sentence.append(raw_input())
    for i in range(T):
        print compare(sentence[i])
    
       
