﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < fjoldiProfunartilvika; i++)
            {
                string listi = Console.ReadLine();

                string[] seperators = { "->" };
                string[] stok = listi.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
                string[] stok2 = new string[stok.Length - 1];

                Array.Copy(stok, stok2, stok.Length - 1);

                Array.Reverse(stok2);

                List<string> stok3 = new List<string>();
                stok3.AddRange(stok2);
                stok3.Add("NULL");

                for (int stak = 0; stak < stok3.Count; stak++)
                {
                    Console.Write("{0}", stok3[stak]);

                    if (stak != stok3.Count - 1)
                        Console.Write("->");
                }

                Console.WriteLine();
            }
        }
    }
}
