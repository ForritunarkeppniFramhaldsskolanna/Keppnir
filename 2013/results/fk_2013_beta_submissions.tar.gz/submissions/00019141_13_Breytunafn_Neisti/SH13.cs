/*
Nafn skr�ar: SH13.cs
Forritari: Hallgr�mur Dav�� Egilsson
*/
using System;
using System.Text.RegularExpressions;
class SH13
{
	static void Main()
	{
        int T = Convert.ToInt32(Console.ReadLine());
        string r = @"^([a-z,0-9,A-Z,_])+\z";
        string lina;

        for (int t = 0; t < T; t++)
        {
            lina = Console.ReadLine();

            if (Regex.IsMatch(lina, r))
            {
                Console.WriteLine("Valid");
            }
            else
            {
                Console.WriteLine("Invalid");
            }
        }
	}
}