﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pascal
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string input = Console.ReadLine();

            int n = Convert.ToInt32(input);


            for (int y = 0; y < n; y++)
            {
                int c = 1;
                for (int x = 0; x <= y; x++)
                {
                    if (c % 2 == 0)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("#");
                    }
                    c = c * (y - x) / (x + 1);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
