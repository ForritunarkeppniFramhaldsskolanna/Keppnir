import java.util.Scanner;

public class Verk20
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
      int k = sc.nextInt();
    
      int [] X = new int[k];
      
      for(int i = 0; i<k; i++)
      {X[i]=sc.nextInt();
      }
      
      int n=0;
      for( int j=0; j<k; j++)
      {
     
     for( int i=1; i<=X[j]; i++)
      {if( X[j]>=((i*(i+1)/2)))
        n=i;
      else break;
      }
     int a =0;
      if (n ==1&& X[j]==2)
         a = 1;
      
     else a = X[j]%(((n+1)*n)/2);
      
      System.out.println( n + " " + a);
  }
}
}