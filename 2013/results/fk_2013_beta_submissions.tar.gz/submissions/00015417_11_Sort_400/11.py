#!/usr/bin/python
from sys import stdin, stdout, stderr
for i in range(int(stdin.readline())):
	c = map(int, stdin.readline().split());c.sort()
	p = map(int, stdin.readline().split())
	if p == c:
		print "Accepted"
	else:
		print "Wrong answer"
	
