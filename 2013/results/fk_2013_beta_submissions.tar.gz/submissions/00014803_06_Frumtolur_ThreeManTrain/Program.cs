﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace primeNumsReal
{
    class Program
    {
        static void Main(string[] args)
        {
            int yourInteger = Int32.Parse(Console.ReadLine());
            for (int x = 0; x < yourInteger; x++)
            {     
            int[] tolur = new int[101];
            int counter = 1;
            for (int i = 2; i <= 541; i = i + 1)
            {
                if (PrimeTool.IsPrime(i))
                {
                    tolur[counter] = i;
                    counter++;
                }
            }

            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(tolur[y]);

            }
        }
    }

    public static class PrimeTool
    {
        public static bool IsPrime(int candidate)
        {
            // Test whether the parameter is a prime number.
            if ((candidate & 1) == 0)
            {
                if (candidate == 2)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            // Note:
            // ... This version was changed to test the square.
            // ... Original version tested against the square root.
            // ... Also we exclude 1 at the end.
            for (int i = 3; (i * i) <= candidate; i += 2)
            {
                if ((candidate % i) == 0)
                {
                    return false;
                }
            }
            return candidate != 1;
        }
    }
}
