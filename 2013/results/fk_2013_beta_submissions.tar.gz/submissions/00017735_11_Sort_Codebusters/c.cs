﻿using System;
using System.Collections.Generic;
using System.Text;


public static class sort
{
    public static int[] size(string[] a)
    {
        int[] ret=new int[a.Length];
        for (int A = 0; A < a.Length; A++)
        {
            ret[A] = Convert.ToInt32(a[A]);
        }

        for (int A = 0; A < ret.Length; A++)
        {
            int temp = 0;
            for (int B = 0; B < ret.Length-1; B++)
            {
                if (ret[B] > ret[B + 1])
                {
                    temp = ret[B];
                    ret[B] = ret[B + 1];
                    ret[B + 1] = temp;
                }
            }
        }
        return (ret);

    }
}
class v11
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        string[] ret = new string[loops];
        for (int AA = 0; AA < loops; AA++)
        {
            string[] input = Console.ReadLine().Split();
            string[] test = Console.ReadLine().Split();
            int[] answer = sort.size(input);

            int[] tester = new int[test.Length];
            for (int A = 0; A < test.Length; A++)
            {
                tester[A] = Convert.ToInt32(test[A]);
            }
            bool goone = true;
            if (answer.Length == tester.Length)
            {
                for (int A = 0; A < answer.Length; A++)
                {
                    if (tester[A] == answer[A])
                    {

                    }
                    else { goone = false; }
                }
            }
            else
            { goone = false; }

            switch (goone)
            {
                case true: { ret[AA] = "Accepted"; break; }
                case false: { ret[AA] = "Wrong Answer"; break; }
            }


        }
        foreach (string s in ret)
        {
            Console.WriteLine(s);
        }
    }

}