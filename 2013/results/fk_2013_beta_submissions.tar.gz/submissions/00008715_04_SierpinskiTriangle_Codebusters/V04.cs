using System;

class Program
{

    public static int C(int n, int k)
    {
        int n1 = 1;
        int k1 = 1;
        int kn = 1;

        for (int i = 1; i < n+1; i++)
            n1 = n1 * i;

        for (int i = 1; i < k+1; i++)
            k1 = k1 * i;

        for (int i = 1; i < (n-k+1); i++)
            kn = kn * i;

        int svar = n1/(k1*kn);

        return svar;
    }

    static void Main(string[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            for (int k = 0; k < i+1; k++)
            {
                if (C(i, k) % 2 == 0)
                    Console.Write(".");
                else
                    Console.Write("#");
            }

            if (i != (n - 1))
                Console.Write("\n");
        }

    }
}