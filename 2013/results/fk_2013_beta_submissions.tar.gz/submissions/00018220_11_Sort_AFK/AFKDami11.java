import java.util.Scanner;

class AFKDami11 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		scan.nextLine();
		for (int n = 0; n < a; n++) {
			String runa1 = scan.nextLine();
			String[] runa1split = runa1.split(" ");
			String runa2 = scan.nextLine();
			String[] runa2split = runa2.split(" ");
			int[] runa1tolur = new int[runa1split.length];
			for (int i = 0; i < runa1tolur.length; i++) {
				runa1tolur[i] = Integer.parseInt(runa1split[i]);
			}
			runa1tolur = radaTolum(runa1tolur);
			for (int b = 0; b < runa1tolur.length; b++) {
				runa1split[b] = "" + runa1tolur[b];
			}
			boolean accept = true;
			
			for (int i = 0; i < runa1split.length; i++) {
				if (!(runa1split[i].equals(runa2split[i]))) {
					accept = false;
				}
			}
			if (accept) {
				System.out.println("Accepted");
			}
			else {
				System.out.println("Wrong Answer");
			}
		}
	}
	
	public static int[] radaTolum(int[] n){
		for (int i = 0; i < n.length; i++) {
			int temp;
			for (int s = 0; s < n.length; s++) {
				if (((i>s)&&(n[i]<n[s])||((i<s)&&(n[i]>n[s])))) {
					temp = n[i];
					n[i] = n[s];
					n[s] = temp;
				}
			}
		}
		return n;
	}
}