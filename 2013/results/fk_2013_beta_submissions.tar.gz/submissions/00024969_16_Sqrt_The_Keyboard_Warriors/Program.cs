﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace v16
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = 0;

            BigInteger a, b = 5;

            int n,i;

            string tmp = "";
            char ws = Convert.ToChar(char.ConvertFromUtf32(0x00000020));
            T = Convert.ToInt32(Console.ReadLine());            
            for (int o = 0; o < T; o++)
            {
                tmp = Console.ReadLine();

                n = Convert.ToInt32(tmp.Split(ws)[0]);
                i = Convert.ToInt32(tmp.Split(ws)[1]);
                a = 5 * (ulong)n;
                b = 5;
                for (int p = 0; p < i; p++)
                {
                    if(a >= b)
                    {
                        a = a - b;
                        b = b + 10;
                    }
                    else
                    {
                        tmp = "";
                        a *= 100;
                        tmp = b.ToString();
                        tmp = tmp.Insert(tmp.Count() - 1, "0");
                        b = BigInteger.Parse(tmp);
                    }
                }
                Console.WriteLine(b);
            }
        }
    }
}
