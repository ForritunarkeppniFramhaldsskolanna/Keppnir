﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verk15
{
    class Program
    {
        static void Main(string[] args)
        {
            int t = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < t; i++)
            {
            string[] golf = Console.ReadLine().Split();
            int a = int.Parse(golf[0]);
            int b = int.Parse(golf[1]);
            int c = int.Parse(golf[2]);
            if (a*b == c)
            {
                Console.WriteLine("True");
            }
            else
            {
                Console.WriteLine("False");
            }
            }
        }
    }
}
