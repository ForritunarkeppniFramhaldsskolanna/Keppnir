﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Glas_d_16
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int profunarnumer = 0; profunarnumer < fjoldiProfunartilvika; profunarnumer++)
            {
                string inntak = Console.ReadLine();

                string[] inntaksfylki = inntak.Split(' ');

                int n = Convert.ToInt32(inntaksfylki[0]),
                    i = Convert.ToInt32(inntaksfylki[1]);
                BigInteger a = 5 * n,
                           b = 5;

                for (int j = 0; j < i; j++)
                {
                    if (a >= b)
                    {
                        a = a - b;
                        b = b + 10;
                    }
                    else
                    {
                        string A = a.ToString() + "00";
                        a = BigInteger.Parse(A);

                        string B = b.ToString();
                        string b1 = B.Substring(0, B.Length - 1);
                        string b2 = B.Substring(B.Length - 1);
                        B = b1 + "0" + b2;

                        b = BigInteger.Parse(B);
                    }
                }

                Console.WriteLine(b);
            }
        }
    }
}
