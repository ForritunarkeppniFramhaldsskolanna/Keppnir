﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeMafiaVerkefni9
{
    class Program
    {
        static void Main(string[] args)
        {
            int runTime = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < runTime; i++)
            {
                char player1 = 'X'; char player2 = 'O';
                int gridSize = Convert.ToInt32(Console.ReadLine());
                int xCordinate = gridSize; int yCordinate = gridSize;
                char[,] grid = new char[xCordinate, yCordinate];

                for (int y = 0; y < yCordinate; y++)
                {
                    string input = Console.ReadLine().ToUpper();
                    int xCord, yCord;
                    for (int x = 0; x < xCordinate; x++)
                    {
                        xCord = x; yCord = y;
                        grid[xCord, yCord] = input[x];
                    }
                }

                bool xWon = false, oWon = false;
                int xWin = 0, oWin = 0;

                for (int checkColumns = 0; checkColumns < yCordinate; checkColumns++)
                {
                    xWin = 0; oWin = 0;

                    for (int checkRows = 0; checkRows < xCordinate; checkRows++)
                    {
                        if ((grid[checkRows, checkColumns] == player1))
                        {
                            oWin = 0;
                            xWin++;
                            if (xWin == gridSize)
                                xWon = true;
                        }
                        else if ((grid[checkRows, checkColumns] == player2))
                        {
                            xWin = 0;
                            oWin++;
                            if (oWin == gridSize)
                                oWon = true;
                        }
                        else
                        {
                            xWin = 0; oWin = 0;
                        }
                    }
                }

                for (int checkRows = 0; checkRows < xCordinate; checkRows++)
                {
                    xWin = 0; oWin = 0;

                    for (int checkColumns = 0; checkColumns < yCordinate; checkColumns++)
                    {
                        if ((grid[checkRows, checkColumns] == player1))
                        {
                            oWin = 0;
                            xWin++;
                            if (xWin == gridSize)
                                xWon = true;
                        }
                        else if ((grid[checkRows, checkColumns] == player2))
                        {
                            xWin = 0;
                            oWin++;
                            if (oWin == gridSize)
                                oWon = true;
                        }
                        else
                        {
                            xWin = 0; oWin = 0;
                        }
                    }
                }
                for (int checkDiagonal = 0; checkDiagonal < gridSize; checkDiagonal++)
                {
                    if ((grid[checkDiagonal, checkDiagonal] == player1))
                    {
                        oWin = 0;
                        xWin++;
                        if (xWin == gridSize)
                            xWon = true;
                    }
                    else if ((grid[checkDiagonal, checkDiagonal] == player2))
                    {
                        xWin = 0;
                        oWin++;
                        if (oWin == gridSize)
                            oWon = true;
                    }
                    else
                    {
                        xWin = 0; oWin = 0;
                    }
                }

                if (xWon == true && oWon == true)
                    Console.WriteLine("Error");
                else if (xWon == true)
                    Console.WriteLine("X won");
                else if (oWon == true)
                    Console.WriteLine("O won");
                else
                    Console.WriteLine("Neither won");



            }
            Console.ReadKey();
        }
    }
}
