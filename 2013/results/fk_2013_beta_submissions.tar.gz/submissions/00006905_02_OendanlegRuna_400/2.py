#!/usr/bin/python
from sys import stdin, stdout, stderr
for i in range(int(stdin.readline())):
	i,j = map(int, stdin.readline().strip().split())
	i -= 1
	f = j-i
	p = stdin.readline().strip()
	i = i % len(p)
	print "i =", i
	if 1 < i:
		p = p[i:] + p[:i]
	while(len(p) < f):
		p += p
	print(p[:f])
