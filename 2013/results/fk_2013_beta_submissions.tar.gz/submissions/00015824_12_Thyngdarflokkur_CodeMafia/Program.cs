﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni12Þyng
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tilvik; i++)
            {
                string name = Console.ReadLine();
                double weight = 0;
                weight = Convert.ToDouble(Console.ReadLine());
                double light = 60;
                double mid = 90;

                string weightslot = null;
                if (weight < light)
                {
                    weightslot = "lightweight";
                }
                else if (weight >= light && weight <= mid)
                {
                    weightslot = "middleweight";
                }
                else if (weight > mid)
                {
                    weightslot = "heavyweight";
                }
                else
                {
                    Console.WriteLine("Someting wrong");
                }
                Console.WriteLine(name + " competes in " + weightslot);
            }
            Console.ReadLine();
        }
    }
}
