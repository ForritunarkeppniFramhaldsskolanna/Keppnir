fjd = gets.chomp.to_i
outcome = []
(1..fjd).each do |x|
  n, i = gets.chomp.split(' ')
  
  a = 5 * n.to_i
  b = 5
  
  (1..i.to_i).each do |z|
    if a >= b.to_i
      a -= b.to_i
      b += 10
    else
      a *= 100
      c = b.to_s.split('')
      c.insert(-2, '0')
      string = ""
      c.each do |f|
        string << f
      end
      b = string.to_i
    end
  end
  outcome << b
end

puts outcome
