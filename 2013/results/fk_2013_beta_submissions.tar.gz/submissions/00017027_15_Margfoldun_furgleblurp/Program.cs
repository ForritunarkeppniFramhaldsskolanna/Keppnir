﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace furgleblurp_Margfoldun
{
    class Program
    {
        static void Main(string[] args)
        {
            int keyrsla = 0;
            int tala1 = 0;
            int tala2 = 0;
            int svar = 0;

            keyrsla = Convert.ToInt32(Console.ReadLine());     
    
            for (int i = 0; i < keyrsla; i++)
            {
                tala1 = Convert.ToInt32(Console.ReadLine());
                tala2 = Convert.ToInt32(Console.ReadLine());
                svar = Convert.ToInt32(Console.ReadLine());
                if (tala1 * tala2 == svar)
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");  
                }
            }
            Console.ReadLine();          
        }
    }
}
