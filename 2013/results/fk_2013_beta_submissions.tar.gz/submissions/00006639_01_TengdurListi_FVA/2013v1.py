def prentalista(listi):
    text = ""
    for i in range(len(listi)):
        text+="["+str(listi[i])+"]->"
    text+="NULL"
    return text

T = raw_input()
listi = []                    
for i in range(int(T)):
    listi.append(raw_input())
    listi[i] = listi[i].replace("[","").replace("]->"," ").replace("NULL","")
    listi[i] = listi[i].split()
    listi[i].reverse()

for i in range(int(T)):
    print prentalista(listi[i])
