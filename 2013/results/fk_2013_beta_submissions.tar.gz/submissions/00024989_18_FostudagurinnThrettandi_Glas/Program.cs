﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_18
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int profunarnumer = 0; profunarnumer < fjoldiProfunartilvika; profunarnumer++)
            {
                int ar = Convert.ToInt32(Console.ReadLine());

                while (ar > 9999)
                    ar -= 2000;

                int counter = 0;

                for (int i = 1; i <= 12; i++)
                {
                    DateTime dagsetning = new DateTime(ar, i, 1);

                    if (dagsetning.DayOfWeek == DayOfWeek.Sunday)
                        counter++;
                }

                Console.WriteLine(counter);
            }
        }
    }
}