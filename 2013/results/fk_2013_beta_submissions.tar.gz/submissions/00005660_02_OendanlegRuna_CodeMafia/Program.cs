﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni2Runa
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < tilvik; i++)
            {
                string tolur = Console.ReadLine();
                string[] tala = tolur.Split(' ');
                int tala1 = Convert.ToInt32(tala[0]);
                int tala2 = Convert.ToInt32(tala[1]);

                string talan = Console.ReadLine();
                int mmmhmmmm = tala2 - tala1;
                int lengd = talan.Length;
                string lokastring = null;
                while (tala1 > lengd)
                {
                    tala1 = tala1 - lengd;
                }
                string mhm2 = talan;
                while (mhm2.Length < mmmhmmmm + tala1)
                {
                    mhm2 = mhm2 + talan;
                }
                for (int k = 0; k < mmmhmmmm + 1; k++)
                {
                    lokastring += mhm2[tala1 + k - 1];
                }
                Console.WriteLine(lokastring);
            }
            Console.ReadLine();
        }
    }
}
