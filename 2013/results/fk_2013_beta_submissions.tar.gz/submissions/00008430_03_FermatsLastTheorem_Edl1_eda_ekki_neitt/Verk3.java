import java.util.Scanner;

public class Verk3
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
      
      int t = sc.nextInt();
      
     
     for( int i=0; i<t; i++)
       
     {
      String a = sc.next();
       System.out.println("no solutions when n = " +  a);
     }

  }
}