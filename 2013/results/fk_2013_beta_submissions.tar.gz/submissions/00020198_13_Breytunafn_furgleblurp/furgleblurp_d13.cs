﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace furgleblurp_d13
{
    class furgleblurp_d13
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            string word = null;
            int teljari = 0;
            for (int i = 0; i < T; i++)
            {
                word = Console.ReadLine();
                foreach (char c in word)
                {
                    if (c == '!' || c == '"' || c == '#' || c == '$' || c == '%' || c == '&' || c == '/' || c == '(' || c == ')' || c == '=' || c == '-' || c == '?' || c == '+' || c == '*' || c == '`' || c == '´' || c == '^' || c == '.' || c == ':' || c == ',' || c == ';' || c == '<' || c == ' ' || c == '>' || c == '|' || c == '@')
                    {
                        teljari++;
                    }
                }
                if (Char.IsNumber(word[0]))
                {
                    teljari++;
                }
                if (teljari<=0)
                {
                    Console.WriteLine("Valid");
                }
                else if(teljari>=1)
                {
                    Console.WriteLine("Invalid");
                }
                teljari = 0;
            }
            Console.ReadLine();
        }
    }
}
