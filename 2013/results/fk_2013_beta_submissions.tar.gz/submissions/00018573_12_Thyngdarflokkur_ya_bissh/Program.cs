﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Þyngdarflokkur
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = 0;

            teljari = Convert.ToInt32(Console.ReadLine());
            if (teljari >= 1 && teljari <= 100)
            {
                for (int i = 0; i < teljari; i++)
                {
                    string nafn = Console.ReadLine();
                    double þyngd = Convert.ToDouble(Console.ReadLine());
                    if (þyngd < 60 && þyngd >0)
                    {
                        Console.WriteLine(nafn + " competes in lightweight");
                    }
                    else if (þyngd >= 60 && þyngd <= 90)
                    {
                        Console.WriteLine(nafn + " competes in middleweight");
                    }
                    else if (þyngd > 90)
                    {
                        Console.WriteLine(nafn + " competes in heavyweight");
                    }
                }
            }
        }
    }
}
