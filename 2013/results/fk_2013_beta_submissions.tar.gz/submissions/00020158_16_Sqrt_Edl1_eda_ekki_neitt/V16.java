import java.util.Scanner;

public class V16
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    int inn = input.nextInt();
    for(int i = 0; i < inn; i++)
    {
      int n = input.nextInt();
      long a = 5*n;
      long b = 5;
      long x = 0;
      int milli = input.nextInt();
      for(int j = 0; j < milli; j++)
      {
        if(a >= b)
        {
          a = a-b;
          b = b+10;
        }
        else
        {
          x = (b%10);
          a = a*100;
          b = ((b-x)*10 + x);
        }
      }
      System.out.println(b);
    }
  }
}