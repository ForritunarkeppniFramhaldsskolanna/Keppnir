def finnaprime(n):
    n += 1
    if(n >= 2 and n <= 101):
        i = 0
        a = 0
        while(i != n):
            a+= 1
            if(erprime(a)):
                i+= 1
        return a
    else:
        return "Nope"
        

def erprime(n):
    if n in (2,3):
        return True
    if not n%2:
        return False        
    if any(n%x == 0 for x in xrange(3, int(n**0.5)+1, 2)):     
        return False   
    return True 
        

T = int(raw_input())
n = []
for i in range(T):
    n.append(int(raw_input()))

for i in range(T):
    print finnaprime(n[i])
