﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Human_Pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = Convert.ToInt32(Console.ReadLine());
            for (int t = 0; t < tilvik; t++)
            {
                int tala = Convert.ToInt32(Console.ReadLine());
                int[] storage = GetExtra(tala); // index 0 = menn eftir. index 1 = Linur
                Console.WriteLine(storage[1] + "   " + storage[0]);
            }
            Console.ReadLine();'
        }
        static int[] GetExtra(int tala)
        {
            int teljari = 0;
            int a = 1;
            int MennEftir = tala;
            do
            {
                MennEftir = MennEftir - a;
                a++;
                teljari++;
            } while (MennEftir >= a);
            return new int[2] {MennEftir, teljari};
        }
    }
}
