﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verkefni11
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            for (int x = 0; x < T; x++)
            {
                string s = Console.ReadLine();
                string t = Console.ReadLine();
                string[] s1 = s.Split(' ');
                string[] t1 = t.Split(' ');
                int[] i1 = new int[s1.Length];
                int[] i2 = new int[t1.Length];
                for (int y = 0; y < s1.Length; y++)
                {
                    i1[y] = Convert.ToInt32(s1[y]);
                    i2[y] = Convert.ToInt32(t1[y]);
                }
                Array.Sort(i1);                
                int g = 0;
                for (int y = 0; y < i1.Length; y++)
                {
                    if (i1[y] == i2[y])
                    {
                        g++;
                    }
                }
                if (g == s1.Length)
                {
                    Console.WriteLine("Accepted");
                }
                else
                {
                    Console.WriteLine("Wrong Answer");
                }
            }
        }
    }
}
