﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Verkefni9
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());

            for (int x = 0; x < T; x++)
            {
                int n = Convert.ToInt32(Console.ReadLine());
                int p = n*n;
                char[] w = new char[p];
                int g = 0;
                if(n >= 3)
                {
                    string[] s = new string[n];
                    
                    for (int y = 0; y < n; y++)
                    {
                        s[y] = Console.ReadLine();
                        char[] c = s[y].ToCharArray();
                        for (int z = 0; z < n; z++)
                        {
                            w[g] = c[z];
                            g++;
                        }
                    }
                    
                }
                int[] k = new int[2];
                int[] i = new int[2];    
                // lárétt
                for (int y = 0; y < p; y++)
                {
                    if (w[y] == 'X')
                    {
                        i[0]++;
                        i[1] = 0;
                        if (i[0] == n)
                        {
                            k[0] = 1;
                        }
                    }
                    else if (w[y] == 'O')
                    {
                        i[1]++;
                        i[0] = 0;
                        if (i[0] == n)
                        {
                            k[1] = 1;
                        }
                    }
                    else if (w[y] == '.')
                    {
                        i[0] = 0;
                        i[1] = 0;
                    }
                    if (y % n == 0 && y != 0)
                    {
                        i[1] = 0;
                        i[0] = 0;
                    }
                }
                g = n;
                int l = 0;
                // lóðrétt
                while(l < n && g < p)
                {
                    if (w[l] == w[g] && w[l] == 'X')
                    {
                        g = g + n;
                        if (g == l + n * n)
                        {
                            k[0] = 1;
                            l++;
                            g = l + n;
                        }
                    }
                    else if (w[l] == w[g] && w[l] == 'O')
                    {
                        g = g + n;
                        if (g == l + n * n)
                        {
                            k[1] = 1;
                            l++;
                            g = l + n;
                        }
                    }
                    else
                    {
                        l++;
                        g = l + n;
                    }
                }
                // ská
                int[] w1 = new int[n];
                int[] w2 = new int[n];
                g = 0;
                l = 1;
                
                for (int y = 0; y < n; y++)
                {
                    w1[y] = w[g];
                    g = g + n + l;
                }
                int b = 0;
                g = 0;
                while(b == 0)
                {
                    if(w1[0] != w1[g])
                    {
                        b = 1;
                    }
                    else
                    {
                        g++;
                        if(g == n)
                        {
                            if(w1[0] == 'X')
                            {
                                k[0] = 1;
                            }
                            else if (w1[0] == 'O')
                            {
                                k[1] = 1;
                            }
                            b = 1;
                        }
                    }
                }
                g = 0;
                b = 0;
                while (b == 0)
                {
                    if (w2[0] != w2[g])
                    {
                        b = 1;
                    }
                    else
                    {
                        g++;
                        if (g == n)
                        {
                            if (w2[0] == 'X')
                            {
                                k[0] = 1;
                            }
                            else if (w2[0] == 'O')
                            {
                                k[1] = 1;
                            }
                            b = 1;
                        }
                    }
                }
                g = n-1;
                l = n-1;
                for (int y = 0; y < n; y++)
                {
                    w2[y] = w[g];
                    g = g + l;
                    l--;
                }
                if(k[0] == 1 && k[1] == 1)
                {
                    Console.WriteLine("Error");
                }
                else if (k[0] == 1)
                {
                    Console.WriteLine("X won");
                }
                else if (k[1] == 1)
                {
                    Console.WriteLine("O won");
                }
                else
                {
                    Console.WriteLine("Neither won");
                }
            }
        }
    }
}
