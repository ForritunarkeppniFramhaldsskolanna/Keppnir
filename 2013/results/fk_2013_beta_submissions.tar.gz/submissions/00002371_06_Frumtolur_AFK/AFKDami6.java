import java.util.Scanner;

class AFKDami6 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		boolean prim = true;
		int number, inntak, x, run, runTest = 0;
		run = scan.nextInt();
		for (int s = 0; s < run; s++) {
			inntak = scan.nextInt();
			for (number = 2; number > 0 ; number++) {
				x = (int) Math.sqrt(number);
				for (int i=2; i <= (x); i++) {
					if (number%i == 0) {
						prim = false;
						break;
					} 
					else {
						prim = true;
					}
				}
				if (prim == true) {
					if (runTest == (inntak - 1)) {
						System.out.println(number);
						runTest = 0;
						break;
					}
					else {
						runTest++;
					}
				}
			}
		}
	}
}