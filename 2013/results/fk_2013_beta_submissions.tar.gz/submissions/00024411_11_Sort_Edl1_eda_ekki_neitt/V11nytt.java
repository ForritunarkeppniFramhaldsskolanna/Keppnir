import java.util.Scanner;
import java.util.Arrays;

public class V11nytt
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
    int T=sc.nextInt();
    for (int i=0; i<T; i++)
    {
      String r1=sc.nextLine();
      if (i==0)
        r1=sc.nextLine();
      String r2=sc.nextLine();
      
      int lengd = 0;
      for (int r=0; r<r1.length(); r++)
      {
        if (r1.charAt(r)==' ')
          lengd++;
      }
      String[] a = new String[lengd+1];
      int c=0;
      for (int j=0; j<lengd; j++)
      {
        if (j!=0)
          c=c+1;
        String C="";
        while (r1.charAt(c)!=' ')
        {
          C=C+r1.charAt(c);
          c++;
        }
        a[j]=C;
      }
      int c1 =r1.length()-1;
      String c2 = "";
      while (r1.charAt(c1)!=' ')
      {
        c2 = r1.charAt(c1) + c2;
        c1--;
      }
      a[lengd]=c2;
      Arrays.sort(a);
      String B = "";
      for (int k=0; k<a.length; k++)
      {
        B=B + a[k];
        if (k!=a.length-1)
          B=B+" ";
      }
      if (B.equals(r2))
        System.out.println("Accepted");
      else
        System.out.println("Wrong Answer");
    }
  }
  
  
  
}