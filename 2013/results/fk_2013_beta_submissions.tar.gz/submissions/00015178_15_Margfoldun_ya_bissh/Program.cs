﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace d15
{
    class Program
    {
        static void Main(string[] args)
        {
            int Profunartilvik = int.Parse(Console.ReadLine());
            for (int i = 0; i < Profunartilvik; i++)
            {
                string tölur = Console.ReadLine();
                int a = Convert.ToInt32(tölur[0]);
                int b = Convert.ToInt32(tölur[2]);
                int c = Convert.ToInt32(tölur[4]);
                if (c==a*b)
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");
                }
            }            
        }
    }
}
