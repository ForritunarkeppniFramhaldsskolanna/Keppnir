﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_15
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int profunarnumer = 0; profunarnumer < fjoldiProfunartilvika; profunarnumer++)
            {
                string daemi = Console.ReadLine();
                string[] strengjafylki = daemi.Split(' ');
                int[] tolufylki = new int[strengjafylki.Length];

                for (int strengjanumer = 0; strengjanumer < strengjafylki.Length; strengjanumer++)
                    tolufylki[strengjanumer] = Convert.ToInt32(strengjafylki[strengjanumer]);

                int a = tolufylki[0],
                    b = tolufylki[1],
                    c = tolufylki[2];

                if (a * b == c)
                    Console.WriteLine("True");
                else
                    Console.WriteLine("False");
            }
        }
    }
}
