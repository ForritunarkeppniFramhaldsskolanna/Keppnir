﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            for (int p = 0; p < oft; p++)
            {
                int total = Convert.ToInt32(Console.ReadLine());
                int pyratotal = 0, x = 1, teljari = 0;
                while(pyratotal < total){
                    if ((pyratotal + x) > total)
                    {
                        break;
                    }
                    else
                    {
                        pyratotal += x;
                        x++;
                        teljari++;
                    }
                }
                Console.WriteLine(teljari + " " + (total-pyratotal));
            }
        }
    }
}
