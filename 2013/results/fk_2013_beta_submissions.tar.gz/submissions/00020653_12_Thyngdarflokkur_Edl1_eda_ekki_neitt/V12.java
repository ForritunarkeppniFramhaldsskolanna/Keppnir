import java.util.Scanner;

public class V12
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    
    int T = sc.nextInt();
    for (int i=0; i<T; i++)
    {
      String name = sc.nextLine();
      if (i==0)
        name = sc.nextLine();
      String a=sc.nextLine();
      double A=Double.parseDouble(a);
      if (A<60)
        System.out.println(name + " competes in lightweight");
      else if (A<=90)
        System.out.println(name + " competes in middleweight");
      else
        System.out.println(name + " competes in heavyweight");
    }
  }
}