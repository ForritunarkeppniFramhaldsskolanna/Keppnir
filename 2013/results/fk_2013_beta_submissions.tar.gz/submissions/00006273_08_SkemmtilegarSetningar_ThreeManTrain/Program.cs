﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace funBoring
{
    class Program
    {
        static void Main(string[] args)
        {
            int oft = Convert.ToInt32(Console.ReadLine());
            string tempord = null;
            for (int i = 0; i < oft; i++)
            {
                string ord = Console.ReadLine().ToLower();
                string[] words = ord.Split(' ');
                foreach (string word in words)
                {
                    if (tempord != null && tempord[tempord.Length-1] == word[0])
                    {
                        Console.WriteLine("Fun");
                        tempord = null;
                        break;
                    }
                    else if (tempord != null && tempord[tempord.Length - 1] != word[0])
                    {
                        Console.WriteLine("Boring");
                        tempord = null;
                        break;
                    }
                    tempord = word;
                }
            }
        }
    }
}
