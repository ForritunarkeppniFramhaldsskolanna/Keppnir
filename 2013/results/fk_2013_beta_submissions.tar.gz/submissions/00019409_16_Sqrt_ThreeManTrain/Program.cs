﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace verk16
{
    class Program
    {
        static void Main(string[] args)
        {
            int t = Convert.ToInt32(Console.ReadLine());
            decimal a, b;
            for (int x = 0; x < t; x++)
            {
                string[] golf = Console.ReadLine().Split();
                int n = int.Parse(golf[0]);
                int i = int.Parse(golf[1]);
                a = Convert.ToUInt64(5 * n);
                b = 5;
                for (int u = 0; u < i; u++)
                {
                    if (a >= b)
                    {
                        a = a - b;
                        b = b + 10;
                    }
                    else
                    {
                        string tempa = Convert.ToString(a);
                        tempa = tempa + "00";
                        a = Convert.ToDecimal(tempa);
                        string tempb = Convert.ToString(b);
                        char y = tempb[tempb.Length-1];
                        tempb = tempb.Remove(tempb.Length - 1);
                        tempb = tempb + "0";
                        tempb = tempb + y;
                        b = Convert.ToDecimal(tempb);
                    }
                }
                Console.WriteLine(b);
            }
        }
    }
}
