﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pascal
{
    class Program
    {

        static void Main(string[] args)
        {
            
            int input = Convert.ToInt32(Console.ReadLine());

            long n = input;


            for (int y = 0; y <= n; y++)
            {
                long c = 1;
                for (int x = 0; x <= y; x++)
                {
                    if (c % 2 == 0)
                    {
                        Console.Write(".");
                    }
                    else if(c % 2 != 0)
                    {
                        Console.Write("#");
                    }
                    c = c*(y - x) / (x + 1);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
        
    }
}
