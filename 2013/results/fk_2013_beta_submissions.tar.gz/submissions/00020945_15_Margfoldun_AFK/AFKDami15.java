import java.util.Scanner;

class AFKDami15 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();
		scan.nextLine();
		for (int a = 0; a < i; a++) {
			String readLine = scan.nextLine();
			String[] lineSplit = readLine.split(" ");
			int[] tolur = new int[3];
			for (int b = 0; b < lineSplit.length; b++) {
				tolur[b] = Integer.parseInt(lineSplit[b]);
			}
			
			if ((tolur[0]*tolur[1])==tolur[2]) {
				System.out.println("True");
			}
			else {
				System.out.println("False");
			}
		}
	}
}