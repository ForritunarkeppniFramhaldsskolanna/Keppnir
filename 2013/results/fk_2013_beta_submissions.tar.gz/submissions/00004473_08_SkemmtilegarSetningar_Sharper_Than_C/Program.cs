﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Verkefni_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfTests;
            string testSentance;


            numberOfTests = Convert.ToInt16(Console.ReadLine());

            

            for (int i = 0; i < numberOfTests; i++)
            {

                testSentance = Console.ReadLine();

                if (checkIfFun(testSentance.ToLower()) )
                {
                    Console.WriteLine("Fun");

                }
                else
                {
                    Console.WriteLine("Boring");
                }
            }

            //Stoppari
         
        }

        public static Boolean checkIfFun(string sentance)
        {
            int counter = 0;

            List<bool> isAllTrueList = new List<bool>();
            for (int i = 0; i < sentance.Length; i++)
            {
               

               if(sentance[i] == ' ')
               {
                   counter++;
                   if (sentance[i - 1] == sentance[i + 1])
                   {
                       isAllTrueList.Add(true);
                   }
                   else
                   {
                       isAllTrueList.Add(false);
                   }
                   

               }
              


            }//for endar
            

            for (int i = 0; i < isAllTrueList.Count; i++)
            {
                if (isAllTrueList[i] == false)
                {
                    return false;

                }
            }
            return true;
            
        }

        
    }
}
