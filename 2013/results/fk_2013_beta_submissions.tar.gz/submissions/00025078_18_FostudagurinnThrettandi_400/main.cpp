#include <iostream>

using namespace std;

int main()
{
   int t;
   int year;
   int passed;
   int leapyears;

   cin >> t;
   for(int i=0; i< t; i++)
    {cin >> year;
    int acc=0;
    leapyears=((year-1)-(year-1)%4)/4-((year-1)-(year-1)%100)/100;
    passed=year-1+leapyears;
    if((year%4==0) & (year%100!=0))
    {
     if((passed+6)%7==0)
     {
         acc=acc+1;
     }
     //feb
     if((passed+2)%7==0)
     {
         acc=acc+1;
     }
     //may
     if((passed+3)%7==0)
     {
         acc=acc+1;
     }
     //april
     if((passed+6)%7==0)
     {
         acc=acc+1;
     }
     //may
     if((passed+1)%7==0)
     {
         acc=acc+1;
     }
     //june
     if((passed+4)%7==0)
     {
         acc=acc+1;
     }
     //july
     if((passed+6)%7==0)
     {
         acc=acc+1;
     }
     //august
     if((passed+2)%7==0)
     {
         acc=acc+1;
     }
     //sept
     if((passed+5)%7==0)
     {
         acc=acc+1;
     }
     //okt
     if((passed)%7==0)
     {
         acc=acc+1;
     }
     //nov
     if((passed+3)%7==0)
     {
         acc=acc+1;
     }

     //des
     if((passed+5)%7==0)
     {
         acc=acc+1;
     }
    }
    else
        {
     if((passed+6)%7==0)
     {
         acc=acc+1;
     }
     //feb
     if((passed+2)%7==0)
     {
         acc=acc+1;
     }
     //march
     if((passed+2)%7==0)
     {
         acc=acc+1;
     }
     //april
     if((passed+5)%7==0)
     {
         acc=acc+1;
     }
     //may
     if((passed)%7==0)
     {
         acc=acc+1;
     }
     //june
     if((passed+3)%7==0)
     {
         acc=acc+1;
     }
     //july
     if((passed+5)%7==0)
     {
         acc=acc+1;
     }
     //august
     if((passed+1)%7==0)
     {
         acc=acc+1;
     }
     //sept
     if((passed+4)%7==0)
     {
         acc=acc+1;
     }
     //okt
     if((passed+6)%7==0)
     {
         acc=acc+1;
     }
     //nov
     if((passed+2)%7==0)
     {
         acc=acc+1;
     }
     //des
     if((passed+4)%7==0)
     {
         acc=acc+1;
     }
        }
        cout<< acc <<endl;
    }return 0;
}
