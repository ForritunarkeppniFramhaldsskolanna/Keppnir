/*
Nafn skr�ar: SH1.cs
Forritari: Hallgr�mur Dav�� Egilsson
*/
using System;
using System.Collections.Generic;
using System.Linq;
class SH1
{
	static void Main()
    {
        int T = Convert.ToInt32(Console.ReadLine());
        string lina1;
        string lina2;
        List<int> listi = new List<int>();
        List<int> listi2 = new List<int>();
        bool satt = true;
        //bool satt2 = true;

        for (int t = 0; t < T; t++)
        {
            lina1 = Console.ReadLine();

            foreach (string s in lina1.Split(' '))
                listi.Add(Convert.ToInt32(s));

            lina2 = Console.ReadLine();

            foreach (string s in lina2.Split(' '))
                listi2.Add(Convert.ToInt32(s));


            /*//foreach (int i in listi2) Console.WriteLine(i);
            for (int i = 0; i < listi2.Count-1; i++)
            {
              //  Console.WriteLine("i:" + i + " (i+1):" + (i + 1));
                if (listi2[i] > listi2[i + 1])
                {
                //    Console.WriteLine("!!!!");
                    satt2 = false;
                  //  Console.WriteLine("satt2:" + satt2);
                }
            }*/

            listi.Sort();
            //listi2.Sort();

            if (!listi.SequenceEqual(listi2))
                satt = false;


            /*if ((satt == true) && (satt2 == true))
                Console.WriteLine("Accepted");
            if ((satt == false) && (satt2 == true))
                Console.WriteLine("Wrong Answer");
            if ((satt == false) && (satt2 == false))
                Console.WriteLine("Wrong Answer");
            if ((satt == true) && (satt2 == false))
                Console.WriteLine("Wrong Answer");*/

            if (satt == true)
                Console.WriteLine("Accepted");
            else
            {
                Console.WriteLine("Wrong Answer");

                //foreach (int i in listi) Console.WriteLine(i);
                //Console.WriteLine();
                //foreach (int i in listi2) Console.WriteLine(i);
            }

            satt = true;
            //satt2 = true;
            listi.Clear();
            listi2.Clear();

        }



	}

    public static int[] ConvertToInt32(string[] s) //Breytir string[] fylki � int[] fylki.
    {
        int[] f = new int[s.Length];
        int i = 0;

        foreach (string a in s)
        {
            f[i] = Int32.Parse(a);
            i++;
        }

        return f;
    }
}