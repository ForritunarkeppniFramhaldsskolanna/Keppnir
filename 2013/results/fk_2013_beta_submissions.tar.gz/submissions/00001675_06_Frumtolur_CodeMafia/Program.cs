﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Verkefni6Frumtolur
{
    class Program
    {
        static void Main(string[] args)
        {
            int tilvik = 0;
            tilvik = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tilvik; i++)
            {
                int primtalaNumer = Convert.ToInt32(Console.ReadLine());
                int count = 1;
                int ble = 0;
                while (count <= primtalaNumer)
                {
                    ble++;
                    bool isPrime = true;
                    for (long j = 2; j < ble; j++)
                    {
                        if (ble % j == 0)
                        {
                            isPrime = false;
                            break;
                        }
                    }
                    if (isPrime == true && ble != 1)
                    {
                        count++;
                    }
                }
                Console.WriteLine(ble);
            }
            Console.ReadLine();
        }
    }
}
