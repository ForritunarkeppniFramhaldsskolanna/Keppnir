fjd = gets.chomp.to_i
outcome = []
(1..fjd).each do |x|  
  arr = gets.chomp.split(' ').map(&:to_i)
  
  if arr[0]*arr[1] == arr[2]
    outcome << "True"
  else
    outcome << "False"
  end  
end

puts outcome