﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace d13
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int t = Convert.ToInt32(Console.ReadLine());
            for (int timesToDo = 0; timesToDo < t; timesToDo++)
            {

                bool firstRun = true;
                string input = Console.ReadLine();
                
               

                for (int i = 0; i < input.Length; i++)
                {
                    if (Char.IsDigit(input[0]) == false)
                    {

                        Regex r = new Regex("^[a-zA-Z0-9/_]*$");
                            if (r.IsMatch(input)) 
                            {
                            Console.WriteLine("Valid");
                            break;
                            }
                            else if (r.IsMatch(input) == false)
                            {
                                Console.WriteLine("Invalid");
                                break;
                            }
                        
                    }
                    else if (firstRun == true)
                    {
                        if (Char.IsDigit(input[0]) == true)
                        {
                            Console.WriteLine("Invalid");
                            
                            break;
                        }
                        else
                        {
                            
                            break;
                        }
                    }
                    firstRun = false;
                }
            }
        }
    }
}
