﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glas_d_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int fjoldiProfunartilvika = Convert.ToInt32(Console.ReadLine());

            for (int numerProfunartilviks = 0; numerProfunartilviks < fjoldiProfunartilvika; numerProfunartilviks++)
            {
                string strengjalisti = Console.ReadLine();

                string[] strengjafylki = strengjalisti.Split(' ');

                int[] tolufylki = new int[strengjafylki.Length];

                for (int strengjanumer = 0; strengjanumer < strengjafylki.Length; strengjanumer++)
                    tolufylki[strengjanumer] = Convert.ToInt32(strengjafylki[strengjanumer]);

                Array.Sort(tolufylki);

                strengjalisti = "";

                for (int i = 0; i < tolufylki.Length; i++)
                    strengjalisti += tolufylki[i] + " ";

                strengjalisti = strengjalisti.TrimEnd();

                string radadurStrengjalisti = Console.ReadLine();

                if (strengjalisti == radadurStrengjalisti)
                    Console.WriteLine("Accepted");
                else
                    Console.WriteLine("Wrong Answer");
            }
        }
    }
}
