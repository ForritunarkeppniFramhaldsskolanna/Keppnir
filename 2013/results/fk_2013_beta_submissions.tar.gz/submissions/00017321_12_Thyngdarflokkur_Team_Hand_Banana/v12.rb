fjd = gets.chomp.to_i
outcome = []
(1..fjd).each do
  name = gets.chomp
  weight = gets.chomp.to_f
  
  if weight >= 0 && weight < 60 
    outcome << "#{name} competes in lightweight"    
  elsif weight >= 60 && weight <= 90
    outcome << "#{name} competes in middleweight"       
  elsif weight > 90
    outcome << "#{name} competes in heavyweight"       
  end
  
end

puts outcome