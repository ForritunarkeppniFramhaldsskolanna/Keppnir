﻿using System;
using System.Collections.Generic;
using System.Text;

public static class artal
{
    public static int dagar(int ar)
    {
        if (((ar % 4==0) && (ar % 100 != 0)) || ((ar % 400==0)))
        {
            return(366);
        }
        else
        {
            return (365);
        }
    }
}

class v111
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        int[] ret = new int[loops];
        for (int AA = 0; AA < loops; AA++)
        {
            int N = Convert.ToInt32(Console.ReadLine());
            int dagafjold = 0;

                dagafjold -= 365;
                for (int a = 0; a <= Math.Abs(N - 2013); a++)
                {
                    dagafjold += artal.dagar(2013 + (a * Math.Sign(N - 2013)));
                
                }
                
              

                int trett = 0;
                dagafjold += 14;
                    if (dagafjold % 7 ==5)
                   {trett++;}

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    if (artal.dagar(N) == 365)
                    { dagafjold += 28; }
                    else
                    {dagafjold += 29 ;}
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 30;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 30;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 30;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 30;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 30;
                    if (dagafjold % 7 == 5)
                    { trett++; }

                    dagafjold += 31;
                    if (dagafjold % 7 == 5)
                    { trett++; }
                    Console.WriteLine(trett);
                

        }
    }

}
//1. er þriðjudagur (3.)