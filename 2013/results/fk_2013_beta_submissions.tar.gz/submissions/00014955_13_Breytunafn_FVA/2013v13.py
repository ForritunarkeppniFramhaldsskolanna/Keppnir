def isvalid(string):
    if(len(string)>0):
        if (string[0] not in "0123456789"):
            for letter in string:
                if (letter not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789"):
                    return False
        else:
            return False
        return True
    return False

T = int(raw_input())
strings = []

if(T>=1 and T<=100):
    for i in range(T):
        strings.append(raw_input())
    for i in range(T):
        if(isvalid(strings[i])):
           print "Valid"
        else:
           print "Invalid"
        
            
