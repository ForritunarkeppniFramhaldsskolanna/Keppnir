﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1 {
    class Class5 {
        static void Main() {
            int tests = Convert.ToInt32(Console.ReadLine());
            for (int test = 0; test < tests; test++) {
                string n = Console.ReadLine();
                Console.WriteLine("no solutions when n = " + n);
            }
        }
    }
}
