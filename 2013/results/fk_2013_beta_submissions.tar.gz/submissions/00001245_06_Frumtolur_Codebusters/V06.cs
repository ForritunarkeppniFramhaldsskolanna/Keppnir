using System;

class Program
{
    static void Main(string[] args)
    {
        int T = Convert.ToInt32(Console.ReadLine());

        for(int x = 0; x < T; x++)
        {
            int n = Convert.ToInt32(Console.ReadLine());

            int count = 0;
            int tala = 1;
            
            do
            {
                tala++;

                bool frumtala = true;

                for(int k = 2; k < tala; k++)
                {
                    if(tala % k == 0)
                        frumtala = false;
                }

                if(frumtala == true)
                    count++;
            }
            while(count != n);

            Console.WriteLine(tala);
        }
    }
}
