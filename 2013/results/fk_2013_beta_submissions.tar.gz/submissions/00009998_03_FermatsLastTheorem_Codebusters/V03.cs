using System;

    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
	
            for (int x = 0; x < T; x++)
            {
                int n = Convert.ToInt32(Console.ReadLine());
                if ((n > 1))
                    Console.WriteLine("no solutions when n = " + n);
            }
        }
    }