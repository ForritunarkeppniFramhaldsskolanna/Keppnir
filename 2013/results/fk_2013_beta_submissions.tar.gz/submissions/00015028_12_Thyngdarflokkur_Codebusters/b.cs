﻿using System;
using System.Collections.Generic;
using System.Text;


    class Program
    {
        static void Main(string[] args)
        {
            int loops = Convert.ToInt32(Console.ReadLine());
            string[] ret = new string[loops];
            for (int AA = 0; AA < loops; AA++)
            {
                string name = Console.ReadLine();
                double weight = Convert.ToDouble(Console.ReadLine());

                if (weight < 60)
                {
                    ret[AA] = name + " competes in lightweight";

                }
                else
                {
                    if ((weight >= 60) && (weight <= 90))
                    {
                        ret[AA] = name + " competes in middleweight";

                    }

                    else
                    {

                            ret[AA] = name + " competes in heavyweight";
                    }
                }
            }

            foreach (string s in ret)
            {
                Console.WriteLine(s);
            }
        }
    }

