﻿using System;
using System.Collections.Generic;
using System.Text;


class v11
{
    static void Main()
    {
        int loops = Convert.ToInt32(Console.ReadLine());
        string[] ret = new string[loops];
        for (int AA = 0; AA < loops; AA++)
        {
            string breyta = Console.ReadLine();
            bool valid = true;
            string validletters="qwertyuiopasdfghjklzxcvbnm1234567890_QWERTYUIOPASDFGHJKLZXCVBNM";
            string cannotbeginwith = "0123456789";

            for (int a = 0; a < breyta.Length; a++)
            {
                bool legal = false;
                for (int b = 0; b < validletters.Length; b++)
                {

                    if (breyta[a]==validletters[b])
                    {
                        legal = true;
                    }
                }
                if (legal == false)
                {
                    valid = false;
                }
            }



               bool  start = true;
               for (int b = 0; b < cannotbeginwith.Length; b++)
                {

                    if (breyta[0] == cannotbeginwith[b])
                    {
                        start = false;
                    }
                }
                if (start == false)
                {
                    valid = false;
                }
            


        if (valid == true)
        {
            ret[AA]="Valid";
        }
        else
        {
            ret[AA] = "Invalid";
        }


}

        
        foreach (string s in ret)
        {
            Console.WriteLine(s);
        }
    }

}