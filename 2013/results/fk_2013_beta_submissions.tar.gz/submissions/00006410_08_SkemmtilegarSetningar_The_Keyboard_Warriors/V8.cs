﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace V8
{
    class Program
    {
        static void Main(string[] args)

        {
    
            string setning;
            string a = ""; 
            string b = "";
            int amount;
            
            
            

            amount = Convert.ToInt32( Console.ReadLine());
            if (amount >= 1 && amount <= 100)
            {
                bool satt = true;

                for (int s = 0; s < amount; s++)
                {
                    
                    setning = Console.ReadLine().ToLower(); ;
                    for (int i = 0; i < setning.Length; i++)
                    {
                        if (setning[i].ToString() == " ")
                        {
                            i--;
                            a = setning[i].ToString();
                            i++;
                            i++;
                            b = setning[i].ToString();
                            i--;
                            if (a != b)
                            {
                                satt = false;
                            }
                        }

                        
                    }
                    if (satt == true)
                        {
                            Console.WriteLine("Fun");
                            
                        }
                    else if (satt == false)
                    {
                        Console.WriteLine("Boring");
                        satt = true;
                    }


                    
                    
                    
                }
}
            else if (amount > 100 || amount < 1)
            {
                Console.WriteLine("Error");
            }
        }
    }
}
