﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkemmtilegarSetningar
{
    class Program
    {
        static void Main(string[] args)
        {
            int teljari = 0;

            teljari = Convert.ToInt32(Console.ReadLine());
            if (teljari <= 100 && teljari >= 1)
            {
                for (int i = 0; i < teljari; i++)
                {
                    bool fun_boring = false;
                    string lina = Console.ReadLine();
                    string[] ord;
                    char endastafur = ' ';
                    char byrjunarstafur = ' ';
                    string bord = "";
                    string cord = "";

                    ord = lina.Split(' ');
                    for (int s = 0; s < ord.Length; s++)
                    {
                        try
                        {
                            if ((s + 1) < ord.Length)
                            {
                                bord = ord[s];
                                cord = ord[s + 1];
                                byrjunarstafur = cord[0];
                                endastafur = bord[bord.Length - 1];
                                if (char.ToUpper(byrjunarstafur) == char.ToUpper(endastafur))
                                {
                                    fun_boring = true;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.ToString()); ;
                        }
                    }
                    if (fun_boring)
                    {
                        Console.WriteLine("Fun");
                    }
                    else
                    {
                        Console.WriteLine("Boring");
                    }



                }
            }
        }
    }
}
